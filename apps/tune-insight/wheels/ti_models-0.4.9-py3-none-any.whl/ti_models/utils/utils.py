import sys
from io import BytesIO
from typing import Optional, Union
import struct
import logging
from torch import cuda, device as torch_device
from packaging.version import Version


class SerializableMixin:
    @classmethod
    def is_serialization_compatible(cls, version: Version) -> bool:
        """
        Check if the given version is compatible for serialization with the current class version.
        Returns True if compatible, False otherwise.
        Compatible if major version matches and minor version is equal or higher.
        """
        return version.major == cls.version.major and cls.version.minor >= version.minor


class PrettyPrinter:
    """
    Base class providing pretty-printing functionality for derived classes.
    """

    @staticmethod
    def indent(text: str) -> str:
        indent = " " * 4
        return "\n".join(f"{indent}{line}" for line in text.splitlines())


def get_device(device: Optional[Union[str, torch_device]] = None) -> torch_device:
    device = device or (cuda.is_available() and "cuda") or "cpu"

    return torch_device(device)


def get_logger() -> logging.Logger:
    logger = logging.getLogger("timodel_logger")
    logger.setLevel(logging.DEBUG)

    if not logger.hasHandlers():
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter("[%(asctime)s] - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger


##################################################
###           Serialization tools              ###
##################################################


BYTE_ORDER = "little"


def append_marshaled_block(buffer: BytesIO, block: bytes, byteorder: str) -> None:
    buffer.write(len(block).to_bytes(8, byteorder, signed=False))
    buffer.write(block)


def marshal_string_data(buffer: BytesIO, string: str, byteorder: str) -> None:
    """Marshals a string into a bytearray."""

    string_bytes = bytearray(string.encode())
    string_size_bytes = len(string_bytes)

    buffer.write(string_size_bytes.to_bytes(8, byteorder, signed=False))
    buffer.write(string_bytes)


def marshal_float(buffer: BytesIO, value: float, byteorder: str) -> None:
    """
    Marshals a float value into the buffer, by converting float to IEEE 754
    binary representation.
    """
    [d] = struct.unpack(">Q", struct.pack(">d", value))
    buffer.write(int(d).to_bytes(8, byteorder, signed=False))


def unmarshal_float(f: BytesIO, byteorder: str) -> float:
    """
    Unmarshals a float value from the buffer, by converting IEEE 754 binary
    representation to float.
    """
    d = int.from_bytes(f.read(8), byteorder, signed=False)
    return struct.unpack(">d", struct.pack(">Q", d))[0]


def marshal_bool(buffer: BytesIO, value: bool, byteorder: str) -> None:
    """Marshals a boolean value into the buffer."""
    buffer.write(int(value).to_bytes(1, byteorder, signed=False))


def unmarshal_bool(f: BytesIO, byteorder: str) -> bool:
    """Unmarshals a boolean value from the buffer."""
    return bool(int.from_bytes(f.read(1), byteorder, signed=False))


def unmarshal_size(f: BytesIO, byteorder) -> int:
    """Unmarshals a size value from the binary data."""

    size = int.from_bytes(f.read(8), byteorder, signed=False)
    return size


def unmarshal_string(f: BytesIO, byteorder) -> str:
    """Unmarshals a string from the binary data."""
    size = unmarshal_size(f, byteorder)
    value = f.read(size).decode()
    return value


def unmarshal_block(f: BytesIO, byteorder) -> bytes:
    """Unmarshals a block from the binary data."""
    size = unmarshal_size(f, byteorder)
    block = f.read(size)
    return block
