from typing import Optional, Dict
from torchmetrics import Metric, MeanMetric, Accuracy, F1Score, AUROC

from ti_models.utils.utils import get_device
from ti_models.trainer.ti_loss import LossType


METRIC_NAMES = {
    "loss": "Average loss",
    "accuracy": "Accuracy",
    "f1": "F1-Score",
    "auroc": "AUROC",
}


class Metrics:
    """
    Collection of metrics from torchmetrics used to calculate the performance of a model in training and evaluation.

    Attributes:
        n_classes (Optional[int]): The number of classes for the metrics.
        metrics (Dict[str, Metric]): Dictionary of metrics compatible with the model.
    """

    def __init__(
        self,
        n_classes: Optional[int] = None,
        loss_type: Optional[LossType] = None,
        device: Optional[str] = None,
        metrics: Optional[Dict[str, Metric]] = None,
    ):
        """
        Init the metrics for a TIModel.

        Args:
            n_classes (Optional[int]): The number of classes for the metrics. Defaults to None.
            loss_type (Optional[LossType]): The type of loss function (binary, multiclass, regression). Defaults to None.
            device (Optional[str]): The device to move the metrics to. Defaults to None.
            metrics (Optional[Dict[str, Metric]]): Dictionary of metrics compatible with the model. Defaults to None.
        """
        if n_classes is None and loss_type == LossType.MULTICLASS:
            raise ValueError(
                "n_classes must be provided for multiclass loss functions."
            )

        self.n_classes = n_classes

        self.metrics = metrics

        if self.metrics is None:
            device = get_device(device)
            self._init_default_metrics(loss_type, device)
        else:
            if loss_type is not None:
                self._validate_metrics_setup(loss_type)
            if device is not None:
                self._adapt_metrics_to_device(device)

    def __eq__(self, value):
        if not isinstance(value, Metrics):
            return False

        return self.n_classes == value.n_classes and frozenset(
            self.metrics.items()
        ) == frozenset(value.metrics.items())

    def __hash__(self):
        return hash((self.n_classes, frozenset(self.metrics.items())))

    def _init_default_metrics(self, loss_type: LossType, device: str):
        """
        Initialize the metrics dictionary.
        """
        self.metrics = {}
        self.metrics["loss"] = MeanMetric().to(device)

        if loss_type == LossType.BINARY:
            self.metrics["accuracy"] = Accuracy(task="binary").to(device)
            self.metrics["f1"] = F1Score(task="binary").to(device)
            self.metrics["auroc"] = AUROC(task="binary").to(device)

        elif loss_type == LossType.MULTICLASS:
            self.metrics["accuracy"] = Accuracy(
                num_classes=self.n_classes, task="multiclass", top_k=1
            ).to(device)
            self.metrics["f1"] = F1Score(
                num_classes=self.n_classes,
                task="multiclass",
                average="macro",
                top_k=1,
            ).to(device)
            self.metrics["auroc"] = AUROC(
                num_classes=self.n_classes, task="multiclass", average="macro"
            ).to(device)

    def _validate_metrics_setup(self, loss_type: Optional[LossType] = None):
        for metric in self.metrics.values():
            if loss_type == LossType.BINARY:
                if hasattr(metric, "task") and metric.task != "binary":
                    raise ValueError(
                        f"Metric '{type(metric).__name__}' is not compatible with binary loss type."
                    )
            elif loss_type == LossType.MULTICLASS:
                if hasattr(metric, "task") and metric.task != "multiclass":
                    raise ValueError(
                        f"Metric '{type(metric).__name__}' is not compatible with multiclass loss type."
                    )

    def _adapt_metrics_to_device(self, device: str):
        for metric in self.metrics.values():
            metric.to(device)

    def update(self, loss_value, preds, targets):
        """
        Update the metrics with the current batch results.

        Args:
            loss_value (float): The computed loss value for the current batch.
            preds (torch.Tensor): Predictions from the model.
            targets (torch.Tensor): Ground truth labels.
        """
        self.metrics["loss"].update(loss_value.detach())

        for name, metric in self.metrics.items():
            if name == "loss":
                continue
            metric.update(preds, targets)

    def reset(self):
        """
        Reset the metrics to their initial state.
        """
        for metric in self.metrics.values():
            metric.reset()

    def get_results(self) -> Dict[str, float]:
        """
        Get the results of the metrics.

        Returns:
            Dict[str, float]: A dictionary containing the computed metric results.
        """
        if self.metrics is None:
            raise ValueError("Metrics have not been set up. Call setup_metrics first.")

        return {name: metric.compute().item() for name, metric in self.metrics.items()}


def get_printable_metric_results(
    metric_results: Dict[str, float], n_samples: Optional[int] = None
) -> str:
    """
    Get  a formatted string from metric results for logging.

    Returns:
        str: A formatted string containing the metric results.
    """
    log_parts = []

    for key, value in metric_results.items():
        label = METRIC_NAMES.get(key, key.capitalize())
        if key == "accuracy":
            accuracy_str = f"{value * 100:.2f}%"
            if n_samples is not None:
                accuracy_str += f" ({n_samples} samples)"
            log_parts.append(f"{label}: {accuracy_str}")
        else:
            log_parts.append(f"{label}: {value:.6f}")

    metrics_str = ", ".join(log_parts)

    return metrics_str
