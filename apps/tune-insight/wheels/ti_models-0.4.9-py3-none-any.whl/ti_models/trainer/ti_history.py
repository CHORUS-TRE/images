from io import BytesIO
from typing import Optional, List, Dict, Tuple
from datetime import datetime, timezone
from enum import IntEnum

from ti_models.utils.utils import (
    PrettyPrinter,
    BYTE_ORDER,
    marshal_float,
    unmarshal_float,
    marshal_string_data,
    unmarshal_string,
)


class HistoryPointType(IntEnum):
    TRAINING = 1
    EVALUATION = 2
    AGGREGATION = 3


class HistoryPoint:
    """Class to represent a single point (training or evaluation) in the history."""

    def __init__(
        self,
        point_type: HistoryPointType,
        time: datetime,
        results: Dict[str, float],
    ):
        self.point_type = point_type
        self.time = time
        self.results = results

    def __eq__(self, value):
        if not isinstance(value, HistoryPoint):
            return False
        return (
            self.point_type == value.point_type
            and self.time == value.time
            and self.results == value.results
        )

    def __hash__(self):
        return hash((self.point_type, self.time, frozenset(self.results.items())))

    def __str__(self) -> str:
        class_name = self.__class__.__name__

        results_str = (
            "\n"
            + PrettyPrinter.indent(
                ",\n".join(f"{k}: {v}" for k, v in self.results.items())
            )
            + "\n"
        )

        fields = [
            f"type={self.point_type.value}({self.point_type.name})",
            f"time={self.time}",
            f"results=[{results_str if self.results else ''}]",
        ]

        fields_str = ",\n".join(f"{field}" for field in fields)
        return f"{class_name}(\n{PrettyPrinter.indent(fields_str)}\n)"


class TIHistory:
    """Class to keep track of the history of a TITrainer.

    Attributes:
        history_points (List[HistoryPoint]): A list of history points.
    """

    def __init__(self, history_points: Optional[List[HistoryPoint]] = None):
        """
        Init the history of a TIModel.

        Args:
            history_points (Optional[List[HistoryPoint]]): A list of history points.
                Defaults to an empty list.
        """

        self.history_points = history_points or []

    def __eq__(self, value):
        if not isinstance(value, TIHistory):
            return False
        return self.history_points == value.history_points

    def __hash__(self):
        return hash(tuple(self.history_points))

    def __str__(self) -> str:
        class_name = self.__class__.__name__
        n_points = len(self.history_points)

        fields = [f"n_points={n_points}"]

        if n_points > 0:
            fields.append(f"last_result={self.history_points[-1]}")

        fields_str = ",\n".join(f"{field}" for field in fields)
        return f"{class_name}(\n{PrettyPrinter.indent(fields_str)}\n)"

    def add_history_point(
        self,
        point_type: HistoryPointType,
        results: Dict[str, float],
    ):
        """
        Add a history point to the history.

        Args:
            point_type (HistoryPointType): The type of the history point.
            results (Optional[Dict[str, float]]): The results to add.
        """
        # "timezone aware" current time
        current_time = datetime.now(timezone.utc).astimezone()
        self.history_points.append(
            HistoryPoint(
                point_type=point_type,
                time=current_time,
                results=results,
            )
        )

    def get_curve(
        self, metric_name: str, point_type: Optional[HistoryPointType] = None
    ) -> List[Tuple[datetime, HistoryPointType, float]]:
        """
        Get the curve of a specific metric from the history, including timestamps.

        Args:
            metric_name (str): The name of the metric to get the curve for.
            point_type (Optional[HistoryPointType]): The type of points to include in the curve. If None, include all types. Defaults to None.

        Returns:
            List[Tuple[datetime, HistoryPointType, float]]: A list of tuples containing the timestamp, point type, and metric value.
        """
        curve = []
        for point in self.history_points:
            if point_type is not None and point.point_type != point_type:
                continue
            curve.append(
                (point.time, point.point_type, point.results.get(metric_name, None))
            )
        return curve

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Marshal the TIHistory to a binary format.

        Args:
            byteorder (str): The byte order to use for serialization. Defaults to BYTE_ORDER.

        Returns:
            bytes: The serialized TIHistory.
        """
        buffer = BytesIO()

        n_points = len(self.history_points)
        buffer.write(n_points.to_bytes(4, byteorder, signed=False))

        for point in self.history_points:
            buffer.write(int(point.point_type).to_bytes(1, byteorder, signed=False))

            timestamp = int(point.time.timestamp())
            buffer.write(timestamp.to_bytes(8, byteorder, signed=False))

            n_results = len(point.results)
            buffer.write(n_results.to_bytes(4, byteorder, signed=False))

            for key, value in point.results.items():
                marshal_string_data(key, buffer, byteorder)
                marshal_float(buffer, value, byteorder=byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(cls, data: bytes, byteorder: str = BYTE_ORDER) -> "TIHistory":
        """
        Deserialize binary data to a TIHistory object.

        Args:
            data (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for serialization. Defaults to BYTE_ORDER.
        Returns:
            TIHistory: The unmarshaled TIHistory object.
        """
        f = BytesIO(data)

        n_points = int.from_bytes(f.read(4), byteorder, signed=False)
        history_points: List[HistoryPoint] = []

        for _ in range(n_points):
            point_type_value = int.from_bytes(f.read(1), byteorder, signed=False)
            point_type = HistoryPointType(point_type_value)

            timestamp = int.from_bytes(f.read(8), byteorder, signed=False)
            time = datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone()

            n_results = int.from_bytes(f.read(4), byteorder, signed=False)
            results: Dict[str, float] = {}

            for _ in range(n_results):
                key = unmarshal_string(f, byteorder)
                value = unmarshal_float(f, byteorder=byteorder)
                results[key] = value

            history_points.append(
                HistoryPoint(
                    point_type=point_type,
                    time=time,
                    results=results,
                )
            )

        return cls(history_points=history_points)
