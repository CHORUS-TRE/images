from io import BytesIO
from typing import Optional
from enum import IntEnum
import torch
from torch.nn import CrossEntropyLoss, NLLLoss, BCELoss, BCEWithLogitsLoss
from torch.nn.modules.loss import _Loss

from ti_models.utils.utils import BYTE_ORDER, marshal_string_data


class LossType(IntEnum):
    BINARY = 1
    MULTICLASS = 2
    REGRESSION = 3


class TILoss:
    """
    Base class for TI loss functions that wraps pytorch loss functions and can be serialized and deserialized.

    Attributes:
        loss_func (_Loss): The loss function to be used.
        loss_type (LossType): The type of loss function (binary, multiclass, regression).
    """

    def __init__(
        self,
        loss_func: _Loss,
        loss_type: Optional[LossType] = None,
    ):
        """
        Args:
            loss_func (_Loss): The loss function to be used.
            loss_type (LossType, optional): The type of loss function. Defaults to None.
        """

        # Ensure loss_func is a subclass of _Loss if it is not None
        if loss_func is not None and not isinstance(loss_func, _Loss):
            raise ValueError("The loss attribute must be a subclass of _Loss")

        self.loss_func = loss_func

        self.loss_type = loss_type
        if loss_type is None:
            self.loss_type = infer_loss_type_from_func(loss_func)

    def __call__(self, *args, **kwargs):
        """
        Call the loss function with the provided arguments.

        Args:
            *args: Positional arguments for the loss function.
            **kwargs: Keyword arguments for the loss function.

        Returns:
            The computed loss value.
        """
        return self.loss_func(*args, **kwargs)

    def __str__(self) -> str:
        return f"TILoss(type={self.loss_type.value}({self.loss_type.name}), loss_func={self.loss_func.__class__.__name__})"

    def __eq__(self, other: object) -> bool:
        """
        Check if this TILoss instance is equal to another TILoss instance.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the TILoss instances are equal, False otherwise.
        """
        if not isinstance(other, TILoss):
            return False

        return (
            # pylint: disable=unidiomatic-typecheck
            type(self.loss_func) == type(other.loss_func)
            and self.loss_type == other.loss_type
        )

    def __hash__(self):
        return hash((type(self.loss_func), self.loss_type))

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Serialize the TILoss to a binary format.

        Args:
            byteorder (str): The byte order to use for marshaling. Defaults to BYTE_ORDER

        Returns:
            bytes: The serialized binary representation of the TILoss.
        """
        buffer = BytesIO()

        buffer.write(int(self.loss_type).to_bytes(1, byteorder, signed=False))

        loss_func_name = self.loss_func.__class__.__name__
        marshal_string_data(buffer, loss_func_name, byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, binary_loss: bytes, byteorder: str = BYTE_ORDER
    ) -> "TILoss":
        """
        Deserialize binary data into a TILoss object.

        Args:
            binary_loss (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for unmarshaling. Defaults to BYTE_ORDER.

        Returns:
            TILoss: The deserialized TILoss object.
        """
        f = BytesIO(binary_loss)

        # Read loss_type
        loss_type = LossType(int.from_bytes(f.read(1), byteorder, signed=False))

        # Read loss_func class name size
        name_size = int.from_bytes(f.read(8), byteorder, signed=False)

        # Read loss_func class name
        loss_func_name = f.read(name_size).decode()

        # Create the TILoss instance with the appropriate loss function
        LossClass = getattr(torch.nn, loss_func_name)
        loss_func = LossClass()

        ti_loss = cls(loss_func=loss_func, loss_type=loss_type)

        return ti_loss


def infer_loss_type_from_func(loss_func: _Loss) -> LossType:
    """
    Infer the LossType from a given loss function instance.

    Args:
        loss_func (_Loss): The loss function instance.

    Returns:
        LossType: The inferred loss type.
    """
    if isinstance(loss_func, (BCELoss, BCEWithLogitsLoss)):
        return LossType.BINARY
    if isinstance(loss_func, (CrossEntropyLoss, NLLLoss)):
        return LossType.MULTICLASS
    return LossType.REGRESSION
