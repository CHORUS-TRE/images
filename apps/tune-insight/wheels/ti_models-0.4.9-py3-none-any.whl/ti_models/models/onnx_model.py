import io
import warnings
from typing import Optional, Dict, Any, List, Tuple
from collections import OrderedDict
import torch
from torch import nn
from torch.nn import (
    Identity,
    BatchNorm1d,
    BatchNorm2d,
    BatchNorm3d,
)
import onnx
from torchvision.ops.stochastic_depth import StochasticDepth
from ti_models.models.ti_model import TIModel
from ti_models.models.layers.ti_layer import TILayer, LayerType
from ti_models.models.circuit.ti_circuit import TICircuit, create_steps
from ti_models.models.layers.activations.polynomial import SUPPORTED_ACTIVATIONS
from ti_models.models.layers.activations.chebyshev_poly import ChebyshevPoly, Polynomial

ONNX_TYPES = {
    "flatten": LayerType.FLATTEN,
    "add": LayerType.ADD,
    "mul": LayerType.MUL,
    "div": LayerType.DIV,
    "concat": LayerType.CONCATENATE,
}

# TODO: Rewrite the circuit generation logic, as ONNX conversion does not work with torch.fx.GraphModule # pylint: disable=W0511


class ONNXModel(TIModel):
    """
    DEPRECATED: This class is deprecated and will be removed in a future release.
    Please use alternative approaches for ONNX integration.

    Class that integrates ONNX-related tools to TIModels, allowing circuit generation
    for exporting models for secure inference (MaaS). The ONNX conversion is simplified by discarding
    some mathematical operations and skipping non-used nodes, and used to obtain the model
    circuit, the interactions between the layers, and the order of operations.

    Attributes:
        name (str): The name identifier for the model.
        description (Optional[str]): A description of the model's purpose and architecture.
        torch_model (Optional[nn.Module]): The underlying PyTorch model.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs.
        layers (OrderedDict[str, TILayer]): OrderedDict of layers indexed by their names in the model. Defaults to None.
        circuit (TICircuit): The circuit representation of the model.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        onnx_model (Optional[Any]): An optional ONNX model associated with the model.
    """

    def __init__(
        self,
        name: str,
        description: Optional[str] = None,
        n_classes: Optional[int] = None,
        torch_model: nn.Module = None,
        preprocessing: Optional["Preprocessing"] = None,
        layers: Optional[OrderedDict[str, TILayer]] = None,
        secure_inference_enabled: bool = False,
        onnx_model: Optional[Any] = None,
    ):
        self.secure_inference_enabled = secure_inference_enabled
        self.circuit = TICircuit()

        super().__init__(
            name=name,
            n_classes=n_classes,
            torch_model=torch_model,
            description=description,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
        )
        self.onnx_model = onnx_model

        if self.secure_inference_enabled:
            self._generate_circuit_from_torch()

    def __eq__(self, other: object) -> bool:
        """
        Check if this ONNXModel is equal to another ONNXModel.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the models are equal, False otherwise.
        """
        # if not isinstance(other, ONNXModel):
        #     return False

        return (
            super().__eq__(other)
            and self.circuit == other.circuit
            # and self.secure_inference_enabled == other.secure_inference_enabled
        )

    def __hash__(self):
        return hash((super().__hash__(), self.circuit, self.secure_inference_enabled))

    def update_from_torch(self) -> None:
        """
        Updates the TIModel's layers from the underlying PyTorch model.

        Raises:
            ValueError: If no torch model has been set for the TIModel.
        """

        super().update_from_torch()

        if self.secure_inference_enabled:
            self._generate_circuit_from_torch()

    def enable_secure_inference(self):
        self.secure_inference_enabled = True
        self._generate_circuit_from_torch()

    def disable_secure_inference(self):
        self.secure_inference_enabled = False
        self.circuit = TICircuit()

    def _generate_circuit_from_torch(self):
        """
        Generates the TICircuit by converting the PyTorch model into a circuit
        representation.

        Raises:
            ValueError: If any input of a layer is not found in previous steps of the circuit.
        """

        self.circuit = TICircuit()

        self._gen_onnx_model_from_torch()
        onnx_nodes, skipped_nodes = self._get_onnx_nodes()

        model_children = self.get_flatten_named_children()

        for onnx_node in onnx_nodes:
            layer_name = onnx_to_torch_name(onnx_node["name"])

            onnx_type = onnx_node["type"].lower()

            input_prefixes = [
                onnx_to_torch_name(x)
                for x in onnx_node["input"]
                if "/" in x or "input" in x
            ]
            input_names = [
                (
                    self.circuit.find_input(x, skipped_nodes)
                    if "input" not in x and "Constant" not in x
                    else x
                )
                for x in input_prefixes
            ]

            if not all(input_names) and onnx_type not in ["div", "mul"]:
                raise ValueError(
                    f"input of layer {layer_name} not found in previous steps of the circuit"
                )

            layer = None
            for child_name, child_layer in model_children.items():
                if child_name.endswith(layer_name) or layer_name.startswith(child_name):
                    layer = child_layer

            if layer is None:
                layer_name = ".".join([layer_name, onnx_type])
                layer_type = ONNX_TYPES.get(onnx_type, None)

                self.layers[layer_name] = TILayer(
                    layer_type=layer_type,
                    shape=[],
                    data=[],
                    meta_params=[],
                )

            output_prefix = f"{layer_name}.output"

            if onnx_type in ["gemm", "conv"]:
                circuit_steps = create_steps(
                    layer_name=layer_name,
                    input_names=input_names,
                    output_prefix=output_prefix,
                    add_weights=True,
                    add_bias=layer.bias is not None,
                    add_bn_track_running_stats=False,
                    add_generic=False,
                )
                self.circuit.circuit_steps.extend(circuit_steps)
            elif onnx_type == "BatchNormalization".lower():
                circuit_steps = create_steps(
                    layer_name=layer_name,
                    input_names=input_names,
                    output_prefix=output_prefix,
                    add_weights=layer.affine,
                    add_bias=layer.affine,
                    add_bn_track_running_stats=layer.track_running_stats,
                    add_generic=False,
                )
                self.circuit.circuit_steps.extend(circuit_steps)
            elif onnx_type in [
                "flatten",
                "dropout",
                "sigmoid",
                "relu",
                "silu",
                "tanh",
                "maxpool",
                "globalmaxpool",
                "averagepool",
                "globalaveragepool",
                "add",
                "mul",
                "div",
                "concat",
            ]:
                circuit_steps = create_steps(
                    layer_name=layer_name,
                    input_names=input_names,
                    output_prefix=output_prefix,
                    add_weights=False,
                    add_bias=False,
                    add_bn_track_running_stats=False,
                    add_generic=True,
                )
                self.circuit.circuit_steps.extend(circuit_steps)
            else:
                print(
                    f"WARNING: Onnx layer type {onnx_node['type']} not compatible for export."
                )

                circuit_steps = create_steps(
                    layer_name=layer_name,
                    input_names=input_names,
                    output_prefix=output_prefix,
                    add_weights=False,
                    add_bias=False,
                    add_bn_track_running_stats=False,
                    add_generic=True,
                )
                self.circuit.circuit_steps.extend(circuit_steps)

    def _get_onnx_nodes(self) -> Tuple[List[Dict], Dict[str, str]]:
        """
        Extracts the ONNX nodes from the ONNX model.

        This method generates the ONNX model from the PyTorch model and processes
        the ONNX graph to extract a list of nodes representing the circuit. It skips
        certain nodes like 'Constant', 'Dropout', and 'Pad', and handles specific
        node patterns such as 'SiLU' for simplification.

        Returns:
            List[Dict]: A list of nodes representing nodes in the ONNX circuit with
                types, names, inputs, and outputs.
            Dict[str, str]: A dict of skipped nodes from the original ONNX circuit
                with their ONNX names as keys and corresponding torch names as values
        """
        onnx_circuit = []
        skipped_nodes = {}

        graph = self.onnx_model.graph
        n_nodes = len(graph.node)

        i = 0
        while i < n_nodes:
            node = graph.node[i]
            i += 1
            next_node = graph.node[min(i, n_nodes - 1)]

            op_type = node.op_type
            name = node.name
            input_ = node.input
            output = node.output

            # skip constant and unsqueeze nodes
            if op_type in ["Constant", "Unsqueeze"]:
                continue

            # Skip concatenation of skipped layers
            if op_type == "Concat" and all("Unsqueeze" in inp for inp in input_):
                continue

            # Skip Dropout, Pad and Unsqueeze nodes via skipped_nodes dict
            if op_type in ["Dropout", "Pad", "Reshape"]:
                input_ = input_[0]
                output = output[0]

                skipped_nodes[onnx_to_torch_name(input_)] = onnx_to_torch_name(output)
                continue

            next_op_type = next_node.op_type
            next_input = next_node.input
            next_output = next_node.output

            is_silu = (
                op_type == "Sigmoid"
                and next_op_type == "Mul"
                and next_input[0] == input_[0]
                and next_input[1] == output[0]
            )
            if is_silu:
                op_type = "SiLU"
                output = next_output
                i += 1

            onnx_circuit_node = {
                "type": op_type,
                "name": name,
                "input": input_,
                "output": output,
            }

            onnx_circuit.append(onnx_circuit_node)

        return onnx_circuit, skipped_nodes

    def _get_swap_dicts(
        self,
    ) -> Tuple[List[Tuple[str, "nn.Module"]], List[Tuple[str, "nn.Module"]]]:
        """
        This function returns two dicts used to swap some torch layers before and after
        ONNX conversion for simplification and consistency.
            The role of the first dict is to simplify the ONNX conversion by replacing
        complex layers whose operations do not need to be exported.
            The role of the second dict is to convert the model back to its initial state
        after the ONNX conversion.
        The modifications applied before ONNX conversion are the following:
            1. Convert polynomial activations to normal activations to avoid ONNX converting polynomial operations.
            2. Use copies of batch normalization layers to prevent ONNX conversion from altering their weights.
            3. Discard the following layers, not needed in inference, by replacing them with Identity functions:
                - torchvision.ops.stochastic_depth.StochasticDepth

        Args:
            ti_model (TIModel): the TI model to get swapping dicts from

        Returns:
            Tuple[List[Tuple[str, Module]], List[Tuple[str, Module]]]:
                The pre-conversion and post-conversion swapping dicts
        """

        pre_conversion_mapping = {}
        post_conversion_mapping = {}

        previous_layer = None
        # Swap polynomial activations
        for name, layer in self.get_flatten_named_children().items():
            # Swap polynomial activations to simple activations to avoid complex circuit
            if isinstance(layer, (ChebyshevPoly)):
                new_layer = list(SUPPORTED_ACTIVATIONS.keys())[
                    list(SUPPORTED_ACTIVATIONS.values()).index(layer.get_func())
                ]()
                post_conversion_mapping[name] = layer
                pre_conversion_mapping[name] = new_layer

            if isinstance(layer, Polynomial):
                new_layer = nn.SiLU()
                post_conversion_mapping[name] = layer
                pre_conversion_mapping[name] = new_layer

            # Create new instances of batch normalization layers to preserve original layer weights modified by ONNX
            if isinstance(layer, (BatchNorm1d, BatchNorm2d, BatchNorm3d)):
                new_layer = layer.__class__(layer.num_features)
                post_conversion_mapping[name] = layer
                pre_conversion_mapping[name] = new_layer

            # Discard StochasticDepth layers that are not supported by ONNX
            if isinstance(layer, StochasticDepth):
                new_layer = Identity()
                post_conversion_mapping[name] = layer
                pre_conversion_mapping[name] = new_layer

            if isinstance(layer, nn.Linear) and isinstance(
                previous_layer,
                (
                    nn.Conv1d,
                    nn.Conv2d,
                    nn.Conv3d,
                    nn.MaxPool1d,
                    nn.MaxPool2d,
                    nn.MaxPool3d,
                    nn.AdaptiveMaxPool1d,
                    nn.AdaptiveMaxPool2d,
                    nn.AdaptiveMaxPool3d,
                    nn.AvgPool1d,
                    nn.AvgPool2d,
                    nn.AvgPool3d,
                    nn.AdaptiveAvgPool1d,
                    nn.AdaptiveAvgPool2d,
                    nn.AdaptiveAvgPool3d,
                ),
            ):
                new_layer = nn.Sequential(nn.Flatten(), layer)
                post_conversion_mapping[name] = layer
                pre_conversion_mapping[name] = new_layer

            previous_layer = layer

        return pre_conversion_mapping, post_conversion_mapping

    def _gen_onnx_model_from_torch(self):
        """
        Generates an ONNX model from the current PyTorch model.

        Raises:
            ValueError: If no PyTorch model has been in the TIModel.
        """

        if self.eval_graph is None:
            raise ValueError("No torch graph has been set")

        # Prepare mappings to simplify export and protect model from export
        pre_conversion_mapping, post_conversion_mapping = self._get_swap_dicts()

        # Generate the ONNX model after replacement of the needed layers
        self.replace_layers(pre_conversion_mapping)

        buffer = io.BytesIO()

        # Hide user warnings from ONNX export
        warnings.filterwarnings("ignore", category=UserWarning, module="torch.onnx")

        torch.onnx.export(
            self.eval_graph.module(),
            self.get_dummy_input(),
            buffer,
            export_params=False,
            do_constant_folding=False,
        )

        buffer.seek(0)
        onnx_model = onnx.load(buffer)

        self.onnx_model = onnx_model

        # Replace the layers back to the state before conversion
        self.replace_layers(post_conversion_mapping)


def onnx_to_torch_name(onnx_name: str):
    if "input" in onnx_name:
        number = int(onnx_name.split(".")[1]) - 1

        return f"input_{number}"

    parsed_name = list(
        filter(bool, map(lambda x: x.split(".")[-1], onnx_name.split("/")))
    )
    if len(parsed_name) > 1:
        parsed_name = parsed_name[:-1]
    else:
        parsed_name[0] = parsed_name[0].split("_")[0].lower()

    torch_name = ".".join(parsed_name).strip(".")

    return torch_name
