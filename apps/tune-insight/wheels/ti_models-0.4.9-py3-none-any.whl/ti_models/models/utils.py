from typing import Union, Optional


def format_size(
    input_size: Union[int, float, tuple[int]], dim: Optional[int] = None
) -> list:
    """
    Format a pytorch single or multi-dimensional size value into a list, for consistency.

    Args:
        input_size (Union[int, float, tuple[int]]): Input value to format - can be a single number or tuple/list
        dim (Optional[int], optional): Target dimension for output list. If None, uses 1 for numbers or length
            of tuple/list. Defaults to None.

    Returns:
        list[Union[int, float]]: Formatted list of values with specified dimension
    """
    formatted_size = []

    if isinstance(input_size, (int, float)):
        dim = dim or 1
        formatted_size = [input_size] * dim
    elif isinstance(input_size, (tuple, list)):
        dim = dim or len(input_size)
        if len(input_size) == 1:
            input_size = [input_size[0]] * dim
        formatted_size.extend(input_size[:dim])

    return formatted_size
