from typing import Tuple, Optional
from collections import OrderedDict
from torch import nn
from ti_models.models.regressors.regressor import TIRegressor
from ti_models.preprocessing.preprocessing import Preprocessing
from ti_models.models.data_types import InputType


class MLPRegressor(TIRegressor):
    """MLP Regressor is a Multilayer perceptron head for regression tasks.

    Attributes:
        input_dim (int): Number of input features
        name (str): Name identifier for the model. Defaults to "MLP_Regressor".
        description (Optional[str]): Description of the model. Defaults to None.
        hidden_dims (Tuple[int]): Hidden layer dimensions. Defaults to ().
        dropout (float): Dropout probability. Defaults to 0.0.
        batch_norm (bool): Whether to use batch normalization. Defaults to False.
        activation (nn.Module): Activation function to use. Defaults to nn.SiLU.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        layers (OrderedDict[str, TILayer]): OrderedDict of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
    """

    def __init__(
        self,
        input_dim: int,
        name: str = "MLP_Regressor",
        description: Optional[str] = None,
        hidden_dims: Tuple[int] = (),
        dropout: float = 0.0,
        batch_norm: bool = False,
        activation: nn.Module = nn.SiLU,
        preprocessing: Optional["Preprocessing"] = None,
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        secure_inference_enabled: bool = False,
    ):
        torch_layers = []

        if dropout != 0:
            torch_layers.append(nn.Dropout(p=dropout))

        torch_layers.append(nn.Flatten())

        previous_dim = input_dim

        if hidden_dims:
            for hidden_dim in hidden_dims:
                torch_layers.append(nn.Linear(previous_dim, hidden_dim))
                if batch_norm:
                    torch_layers.append(nn.BatchNorm1d(hidden_dim))
                torch_layers.append(activation())
                if dropout != 0:
                    torch_layers.append(nn.Dropout(p=dropout))
                previous_dim = hidden_dim

        torch_layers.append(nn.Linear(previous_dim, 1))

        model = nn.Sequential(*torch_layers)

        preprocessing = preprocessing or Preprocessing(
            input_type=InputType.TABULAR, input_shape=(input_dim,)
        )

        super().__init__(
            name=name,
            description=description,
            torch_model=model,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )


class LinearRegression(MLPRegressor):
    """
    Linear Regression Model inheriting from MLPRegressor.

    Attributes:
        n_inputs (int): Number of input features.
        name (str): Name identifier for the model. Defaults to "Linear_Regression".
        description (Optional[str]): Description of the model. Defaults to None.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
    """

    def __init__(
        self,
        input_dim: int,
        name: str = "Linear_Regression",
        description: Optional[str] = None,
        preprocessing: Optional[Preprocessing] = None,
        secure_inference_enabled: bool = False,
    ):
        """Initialize LinearRegression.

        Args:
            input_dim (int): Number of input features.
            name (str): Name identifier for the model. Defaults to "Linear_Regression".
            description (Optional[str]): Description of the model. Defaults to None.
            preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
            secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        """
        super().__init__(
            input_dim=input_dim,
            name=name,
            hidden_dims=(),  # No hidden layers for linear regression
            dropout=0.0,  # No dropout
            batch_norm=False,  # No batch normalization
            activation=None,  # No activation function needed
            description=description,
            preprocessing=preprocessing,
            secure_inference_enabled=secure_inference_enabled,
        )
