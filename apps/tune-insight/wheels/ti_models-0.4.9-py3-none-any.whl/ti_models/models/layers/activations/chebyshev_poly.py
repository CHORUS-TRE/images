import math
from torch import Tensor
from ti_models.models.layers.activations.polynomial import (
    PolyBasis,
    Polynomial,
)


class ChebyshevPoly(Polynomial):
    """
    reference: https://excamera.com/sphinx/article-chebyshev.html

    An activation function using Chebyshev polynomials defined by a range [A, B], a number
        of nodes and  function to approximate.

    Args:
        A (float): The lower bound of the interval.
        B (float): The upper bound of the interval.
        nodes (int): The number of nodes for the Chebyshev polynomial.
        func (callable): The function to approximate using Chebyshev polynomials.
        debug (bool, optional): Flag to enable or disable debug mode. Defaults to True.
    """

    def __init__(self, A: float, B: float, nodes: int, func, debug: bool = True):
        if A >= B:
            raise ValueError(f"A must be smaller than B. {A} >= {B}")

        self.nodes = nodes

        bma = 0.5 * (B - A)  # interval
        bpa = 0.5 * (B + A)  # middle
        f = [
            func(Tensor([math.cos(math.pi * (k + 0.5) / nodes) * bma + bpa]))
            for k in range(nodes)
        ]
        fac = 2.0 / nodes
        coeffs = [
            fac
            * sum(
                f[k] * math.cos(math.pi * j * (k + 0.5) / nodes) for k in range(nodes)
            )
            for j in range(nodes)
        ]

        coeffs[0] /= 2

        super().__init__(
            basis=PolyBasis.CHEBYSHEV,
            A=A,
            B=B,
            coeffs=coeffs,
            func=func,
            debug=debug,
        )
