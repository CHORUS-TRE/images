from enum import IntEnum


class InputType(IntEnum):
    """
    Enumeration of supported input types for TI models.

    Attributes:
        UNKNOWN: For models with unspecified input type
        TABULAR: For tabular data processing models
        IMAGE: For image processing models
        TEXT: For natural language processing models
        AUDIO: For audio processing models
        TENSOR: For models that handle raw tensors
        MULTIMODAL: For models that handle multiple input types
    """

    UNKNOWN = 0
    TABULAR = 1
    IMAGE = 2
    TEXT = 3
    AUDIO = 4
    TENSOR = 5
    MULTIMODAL = 6
