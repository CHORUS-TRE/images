from typing import Optional
from abc import ABC
from collections import OrderedDict
from torch import nn
from ti_models.models.onnx_model import ONNXModel


class TIClassifier(ONNXModel, ABC):
    """Abstract TI model for classification tasks, inheriting ONNXModel for secure inference (MaaS) capabilities.

    Attributes:
        name (str): The name identifier for the model.
        torch_model (Optional[nn.Module]): The underlying PyTorch model. Defaults to None.
        description (Optional[str]): A description of the model's purpose and architecture. Defaults to None.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        layers (OrderedDict[str, TILayer]): Dict of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
    """

    def __init__(
        self,
        name: str,
        n_classes: int,
        torch_model: nn.Module = None,
        description: Optional[str] = None,
        preprocessing: Optional["Preprocessing"] = None,
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        secure_inference_enabled: bool = False,
    ):
        super().__init__(
            name=name,
            description=description,
            n_classes=n_classes,
            torch_model=torch_model,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )
