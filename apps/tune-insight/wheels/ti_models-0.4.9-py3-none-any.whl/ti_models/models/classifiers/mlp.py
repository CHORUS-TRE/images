from typing import Tuple, Optional
from collections import OrderedDict
from torch import nn
from ti_models.models.classifiers.classifier import TIClassifier
from ti_models.preprocessing.preprocessing import Preprocessing
from ti_models.models.data_types import InputType


class MLPClassifier(TIClassifier):
    """MLP Classifier is a Multilayer perceptron classifier head for classification tasks.

    Attributes:
        input_dim (int): Number of input features
        n_classes (int): Number of output classes
        name (str): Name identifier for the model. Defaults to "MLP_Classifier".
        description (Optional[str]): Description of the model. Defaults to None.
        hidden_dims (Tuple[int]): Hidden layer dimensions. Defaults to ().
        dropout (float): Dropout probability. Defaults to 0.0.
        batch_norm (bool): Whether to use batch normalization. Defaults to False.
        standardize (bool): Whether to standardize inputs. Defaults to True.
        activation (nn.Module): Activation function to use. Defaults to nn.SiLU.
        prob_output (bool): Whether to output probabilities using softmax. Defaults to False.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        layers (OrderedDict[str, TILayer]): OrderedDict of layers indexed by their names in the model. Defaults to None.
        single_logit (bool): If True, the model will output a single logit for binary classification. Defaults to False.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        torch_model (Optional[nn.Module]): The underlying PyTorch model, used for combining the MLPClassifier as a head for other models. Defaults to None.
    """

    def __init__(
        self,
        input_dim: int,
        n_classes: int,
        name: str = "MLP_Classifier",
        description: Optional[str] = None,
        hidden_dims: Tuple[int] = (),
        dropout: float = 0.0,
        batch_norm: bool = False,
        activation: nn.Module = nn.SiLU,
        prob_output: bool = False,
        standardize: Optional[bool] = True,
        preprocessing: Optional[Preprocessing] = None,
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        single_logit: bool = False,
        secure_inference_enabled: bool = False,
    ):
        torch_layers = []

        if dropout != 0:
            torch_layers.append(nn.Dropout(p=dropout))

        torch_layers.append(nn.Flatten())

        if standardize:
            torch_layers.append(
                nn.BatchNorm1d(input_dim, affine=False, track_running_stats=True)
            )

        previous_dim = input_dim

        if hidden_dims:
            for hidden_dim in hidden_dims:
                torch_layers.append(nn.Linear(previous_dim, hidden_dim))
                if batch_norm:
                    torch_layers.append(nn.BatchNorm1d(hidden_dim))
                torch_layers.append(activation())
                if dropout != 0:
                    torch_layers.append(nn.Dropout(p=dropout))
                previous_dim = hidden_dim

        n_logits = 1 if single_logit else n_classes
        torch_layers.append(nn.Linear(previous_dim, n_logits))

        if prob_output:
            torch_layers.append(nn.Softmax(dim=1))

        self.torch_model = nn.Sequential(*torch_layers)

        preprocessing = preprocessing or Preprocessing(
            input_type=InputType.TABULAR, input_shape=(input_dim,)
        )

        super().__init__(
            n_classes=n_classes,
            name=name,
            description=description,
            torch_model=self.torch_model,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )


class LogisticRegression(MLPClassifier):
    """
    Logistic Regression Classifier inheriting from MLPClassifier.
    """

    def __init__(
        self,
        input_dim: int,
        n_classes: int,
        name: str = "Logistic_Regression",
        description: Optional[str] = None,
        preprocessing: Optional[Preprocessing] = None,
        single_logit: bool = False,
        secure_inference_enabled: bool = False,
    ):
        """Initialize LogisticRegression.

        Args:
            input_dim (int): Number of input features.
            n_classes (int): Number of output classes.
            name (str): Name identifier for the model. Defaults to "Logistic_Regression".
            description (Optional[str]): Description of the model. Defaults to None.
            preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
            single_logit (bool): If True, the model will output a single logit for binary classification. Defaults to False.
            secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        """
        if single_logit and n_classes != 2:
            raise ValueError("For single logit output, n_classes must be 2.")

        super().__init__(
            input_dim=input_dim,
            n_classes=n_classes,
            name=name,
            hidden_dims=(),  # No hidden layers for logistic regression
            dropout=0.0,  # No dropout
            batch_norm=False,  # No batch normalization
            activation=None,  # No activation function needed
            prob_output=not single_logit,  # If multiclass, use Softmax for probability output. Equivalent to applying sigmoid if there are 2 logits.
            description=description,
            preprocessing=preprocessing,
            single_logit=single_logit,
            secure_inference_enabled=secure_inference_enabled,  # Enable secure inference (MaaS)
        )
