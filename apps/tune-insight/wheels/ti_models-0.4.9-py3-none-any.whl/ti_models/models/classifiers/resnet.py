from typing import Optional, Tuple
from collections import OrderedDict
from torch import nn
from torchvision import models as tvmodels
from ti_models.models.classifiers.classifier import TIClassifier
from ti_models.models.classifiers.mlp import MLPClassifier


class ResNet(TIClassifier):
    """
    Residual Network as presented in "Deep Residual Learning for Image Recognition",
        ref: https://ieeexplore.ieee.org/document/7780459.

    The encoding part of the model is obtained in various sizes (see resnet_cat
    attribute) from torchvizion library and its classification head is adapted to
    fit the task.

    Attributes:
        resnet_cat (str): The ResNet category of the model, e.g. "50" for ResNet50.
            Available categories are: "18", "34", "50", "wide50", "101", "wide101" and "152"
        n_classes (int): Number of classes for classification.
        name (str): Name identifier for the model. Defaults to "ResNet{resnet_cat}".
        description (Optional[str]): Description of the model's purpose and architecture. Defaults to None.
        hidden_dims (Tuple[int]): Hidden layer dimensions of the classification head. Defaults to ().
        dropout (float): Dropout probability. Defaults to 0.0.
        batch_norm (bool): Whether to use batch normalization in classification head. Defaults to False.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        layers (OrderedDict()[str, TILayer]): OrderedDict() of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        freeze_encoders (bool): Whether to freeze the encoding part applied before the final classification. Default to False.
    """

    def __init__(
        self,
        resnet_cat: str,
        n_classes: int,
        name: str = None,
        description: Optional[str] = None,
        hidden_dims: Tuple[int] = (200,),
        dropout: float = 0.0,
        batch_norm: bool = False,
        pretrained: bool = True,
        preprocessing: Optional["Preprocessing"] = None,
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        secure_inference_enabled: bool = False,
        freeze_encoders: bool = False,
    ):
        """
        Initialize the ResNet model.

        Args:
            resnet_cat (str): The ResNet category of the model, e.g. "50" for ResNet50.
                Available categories are: "18", "34", "50", "wide50", "101", "wide101" and "152"
            n_classes (int): Number of classes for classification.
            name (str, optional): Name identifier for the model. Defaults to None.
            description (Optional[str], optional): Description of the model's purpose and architecture. Defaults to None.
            hidden_dims (Tuple[int], optional): Hidden layer dimensions of the classification head. Defaults to (200,).
            dropout (float, optional): Dropout probability. Defaults to 0.0.
            batch_norm (bool, optional): Whether to use batch normalization in classification head. Defaults to False.
            pretrained (bool, optional): Whether to use a pretrained model. Defaults to True.
            preprocessing (Optional["Preprocessing"], optional): Optional preprocessing transforms to apply to inputs. Defaults to None.
            layers (Optional[OrderedDict[str, "TILayer"]], optional): OrderedDict of layers indexed by their names in the model. Defaults to None.
            secure_inference_enabled (bool, optional): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
            freeze_encoders (bool, optional): Whether to freeze the encoding part applied before the final classification. Default to False.
        """

        name = name or f"ResNet{resnet_cat}"
        model = self._get_model(resnet_cat=resnet_cat, pretrained=pretrained)

        classifier_inputs = model.fc.in_features

        if freeze_encoders:
            for param in model.parameters():
                param.requires_grad = False

        # Classification head
        head = MLPClassifier(
            input_dim=classifier_inputs,
            n_classes=n_classes,
            hidden_dims=hidden_dims,
            dropout=dropout,
            batch_norm=batch_norm,
            activation=nn.SiLU,
            prob_output=False,
            standardize=False,
            name="ResNet_Classifier_Head",
            description="MLP head of ResNet classifier",
        )
        model.fc = head.torch_model

        super().__init__(
            name=name,
            n_classes=n_classes,
            torch_model=model,
            description=description,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )
        self.head = head

    def _get_model(self, resnet_cat: str, pretrained: bool):
        """Retrieve the appropriate ResNet model."""
        weight_map = {
            "18": tvmodels.ResNet18_Weights,
            "34": tvmodels.ResNet34_Weights,
            "50": tvmodels.ResNet50_Weights,
            "wide50": tvmodels.Wide_ResNet50_2_Weights,
            "101": tvmodels.ResNet101_Weights,
            "wide101": tvmodels.Wide_ResNet101_2_Weights,
            "152": tvmodels.ResNet152_Weights,
        }

        model_map = {
            "18": tvmodels.resnet18,
            "34": tvmodels.resnet34,
            "50": tvmodels.resnet50,
            "wide50": tvmodels.wide_resnet50_2,
            "101": tvmodels.resnet101,
            "wide101": tvmodels.wide_resnet101_2,
            "152": tvmodels.resnet152,
        }

        if resnet_cat not in model_map:
            raise ValueError(
                f"Invalid ResNet category: {resnet_cat}. Supported categories are"
                "'18', '34', '50', 'wide50', '101', 'wide101', and '152'."
            )

        weights = weight_map.get(resnet_cat).DEFAULT if pretrained else None
        return model_map[resnet_cat](weights=weights)
