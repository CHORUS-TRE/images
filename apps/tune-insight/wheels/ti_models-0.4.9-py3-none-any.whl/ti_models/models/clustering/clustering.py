from typing import Optional, List
from collections import OrderedDict
import networkx as nx
import numpy as np
import torch
from ti_models.models.ti_model import TIModel
from ti_models.preprocessing.preprocessing import Preprocessing, InputType


ALPHA = 0.5  # The weight of the owner of a graph node in the clustering matrix.


class TIClustering(TIModel):
    """TI model for clustering tasks.

    Attributes:
        adjacency_matrix (np.ndarray): the adjacency matrix of the graph
        owned_nodes (List[int]): the owned set of nodes by the collaborator
        num_collaborators (int): the number of collaborators
        num_communities (int): the number of communities to detect
        rho (float): the rho parameter of the Emprise algorithm
        test_adjacency_matrix (np.ndarray): the adjacency matrix of the whole graph for testing purposes
        name (str): Name identifier for the model. Defaults to "MNIST_Classifier".
        torch_model (Optional[nn.Module]): The underlying PyTorch model. Defaults to None.
        description (Optional[str]): A description of the model's purpose and architecture. Defaults to None.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        layers (OrderedDict[str, TILayer]): Dict of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
    """

    def __init__(
        self,
        adjacency_matrix: np.ndarray,
        owned_nodes: List[int],
        num_collaborators: int,
        num_communities: int,
        rho: float,
        test_adjacency_matrix: np.ndarray = None,
        name: str = "Clustering_Model",
        description: Optional[str] = None,
        preprocessing: Optional["Preprocessing"] = None,
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
    ):
        self.clustering_model = EmpriseClustering(
            adjacency_matrix=adjacency_matrix,
            owned_nodes=owned_nodes,
            num_collaborators=num_collaborators,
            num_communities=num_communities,
            rho=rho,
            test_adjacency_matrix=test_adjacency_matrix,
        )

        if preprocessing is None:
            preprocessing = Preprocessing(
                input_type=InputType.TENSOR,
                transforms=[],
                input_shape=(),
            )

        super().__init__(
            name=name,
            description=description,
            torch_model=self.clustering_model,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
        )

    def solve(self):
        """Solve the clustering problem."""
        self.clustering_model.solve()

    def evaluate_global_modularity(self):
        """Evaluate the global modularity of the clustering."""
        return self.clustering_model.evaluate_global_modularity()


class EmpriseClustering(torch.nn.Module):
    """
    Pytorch model for the Emprise et al. clustering algorithm. (https://www.ijcai.org/Proceedings/11/Papers/370.pdf)
    This implementation is experimental and not yet fully optimized.
    Next steps:
        - Circumvent the need to detach the tensors to numpy arrays every time.
        - Add more parallelization to the matrix operations.
        - Persist the matrices and avoid recomputing ZU, B and F every iteration.
    """

    def __init__(
        self,
        adjacency_matrix: np.ndarray,
        owned_nodes: List[int],
        num_collaborators: int,
        num_communities: int,
        rho: float,
        test_adjacency_matrix: np.ndarray = None,
    ):
        """
        Initialize the clustering model.
        Args:
            adjacency_matrix (np.ndarray): the adjacency matrix of the graph
            owned_nodes (List[int]): the owned set of nodes by the collaborator
            num_collaborators (int): the number of collaborators
            num_communities (int): the number of communities to detect
            rho (float): the rho parameter of the Emprise algorithm
            test_adjacency_matrix (np.ndarray): the adjacency matrix of the whole graph for testing purposes
        """
        super().__init__()

        self.A = adjacency_matrix
        assert np.allclose(self.A, self.A.T), "The adjacency matrix is not symmetric."
        self.A_test = test_adjacency_matrix

        self.n = self.A.shape[0]
        self.k = num_communities

        # Place the state in torch tensors so it can be exported automatically by ti-models library
        self.agg_clustering_matrix = torch.nn.Parameter(  # agg_clustering_matrix represents the internal state of the clustering via a (n * k) matrix.
            torch.randn(self.n, self.k), requires_grad=False
        )
        self.vertices_mapping = torch.nn.Parameter(
            torch.full((self.n,), -1),
            requires_grad=False,  # vertices_mapping is a vector of size n that maps each vertex to a cluster. If a vertex is not assigned to a cluster, it is marked with -1.
        )

        # Build the shifted modularity matrix
        self.S = shifted_modularity_matrix(self.A)
        # Compute the number of clusters to assign in each round based on the rho parameter and the total number of vertices.
        self.C = max(int(self.n / np.log(self.n) * np.log(1 / rho)), 1)

        # setup the weighted contribution matrix
        p = num_collaborators
        o = owned_nodes
        self.W = np.full((self.n, self.k), ALPHA * (1 / (p - 1)))
        self.W[o, :] = 1 - ALPHA

        # The secure aggregation protcol is geco averages the contributions of the participants and we require a sum instead.
        # We multiply the contribution of each participant by the total number of participants to get the sum after the secure aggregation.
        self.W = self.W * p

    def solve(self):
        """Solve the clustering problem using the Emprise algorithm for the unassigned set of vertices."""
        # Verify if the clustering is already done
        mapping = self.vertices_mapping.detach().numpy()  # pylint: disable=not-callable
        if np.all(mapping >= 0):
            return

        # Perform the clustering for C unassigned vertices and update the clustering matrix and the mapping
        self._cluster()
        # Extract the mapping post clustering
        mapping = self.vertices_mapping.detach().numpy()  # pylint: disable=not-callable
        # Extract the indices of the unassigned vertices
        assigned = np.where(mapping >= 0)[0]
        unassigned = np.setdiff1d(np.arange(self.n), assigned)

        Z = self.agg_clustering_matrix.detach().numpy()  # pylint: disable=not-callable
        I = np.eye(self.n, dtype=float)

        # The following code is based on the equation (10) of the reference paper: find X that maximises Tr(X^T S' X + 2F^T X) <-> S'X = -F
        # where X is the submatrix of Z corresponding to the unassigned vertices, S' is the submatrix of S corresponding to the unassigned vertices and
        # F contains the interaction between the assigned and unassigned vertices.

        B = I[
            unassigned, :
        ]  # Extract the rows of the identity matrix corresponding to the unassigned vertices
        S_prime = (
            B @ self.S @ B.T
        )  # Compute the submatrix of S corresponding to the unassigned vertices

        F = np.zeros((len(unassigned), self.k), dtype=float)  # Fill F with 0s initially
        BSU = (
            B @ self.S[:, assigned]
        )  # Compute the product of B and S for the assigned vertices
        ZU = Z[
            assigned, :
        ]  # Extract the rows of Z corresponding to the assigned vertices

        # Compute the interaction matrix F
        for i in range(len(assigned)):
            F += np.outer(
                BSU[:, i], ZU[i, :]
            )  # Every entry F[i, j] accumulates the influence of the assigned vertices on the unassigned vertice i in cluster j

        X = np.linalg.solve(S_prime, -F)  # Solve the linear system S'X = -F
        Z[unassigned, :] = (
            X  # Assign the computed values to the unassigned vertices and update the clustering matrix
        )

        Z = Z * self.W  # Apply the weighted contribution matrix
        self.agg_clustering_matrix = torch.nn.Parameter(
            torch.tensor(Z), requires_grad=False
        )

    # pylint: disable=unused-argument
    def forward(self, x: torch.Tensor):
        """Implemented only to comply with the torch.nn.Module interface."""
        return self.agg_clustering_matrix

    def _cluster(self):
        """
        Assign the vertices to the clusters according to the results of the
        the previous aggregation round.
        """
        mapping = self.vertices_mapping.detach().numpy()  # pylint: disable=not-callable

        # if we are at round 0, we need to initialize the clustering matrix to break symmetry by assigning a vertex to the first cluster
        if np.all(mapping < 0):
            v = self.n // 2
            mapping[v] = 0
            Z = (
                self.agg_clustering_matrix.detach().numpy()  # pylint: disable=not-callable
            )
            Z[v, :] = -1
            Z[v, 0] = 1
            self.agg_clustering_matrix = torch.nn.Parameter(
                torch.tensor(Z), requires_grad=False
            )
            self.vertices_mapping = torch.nn.Parameter(
                torch.tensor(mapping), requires_grad=False
            )

        else:
            Z = (
                self.agg_clustering_matrix.detach().numpy()  # pylint: disable=not-callable
            )
            # chose the rows in Z with the highest max
            max_values = np.max(Z, axis=1)
            top_vertices = np.argsort(max_values)
            top_vertices = top_vertices[
                ~np.isin(top_vertices, np.where(mapping >= 0)[0])
            ]
            top_vertices = top_vertices[-self.C :]
            top_vertices = top_vertices[::-1]
            full_clusters = np.unique(mapping[mapping >= 0])

            for v in top_vertices:
                cluster = np.argmax(Z[v])
                mapping[v] = cluster
                Z[v, :] = -1
                Z[v, cluster] = 1

                # Restart trick: in case we are introducing a new cluster, we need to finish the round
                # because the new cluster might have an impact on the other vertices assignments
                if cluster not in full_clusters:
                    self.agg_clustering_matrix = torch.nn.Parameter(
                        torch.tensor(Z), requires_grad=False
                    )
                    self.vertices_mapping = torch.nn.Parameter(
                        torch.tensor(mapping), requires_grad=False
                    )
                    return

            self.agg_clustering_matrix = torch.nn.Parameter(
                torch.tensor(Z), requires_grad=False
            )
            self.vertices_mapping = torch.nn.Parameter(
                torch.tensor(mapping), requires_grad=False
            )

    def evaluate_global_modularity(self):
        Z = self.agg_clustering_matrix.detach().numpy()
        # build the mapping from the clustering matrix to the actual clustering
        clustering = np.argmax(Z, axis=1)
        communities = [set() for _ in range(self.k)]

        for i in range(self.n):
            communities[clustering[i]].add(i)

        # measure the modularity
        mod = nx.algorithms.community.modularity(
            nx.from_numpy_array(self.A_test), communities
        )
        return mod


# pylint: disable=non-ascii-name
def shifted_modularity_matrix(A: np.ndarray) -> np.ndarray:
    """
    Computes the shifted modularity matrix of a graph.

    The shifted modularity matrix is defined as Q - λI, where Q is the modularity matrix
    and λ is the biggest non negative eigenvalue of Q.
    """
    G = nx.from_numpy_array(A)
    Q = nx.modularity_matrix(G)
    n = Q.shape[0]
    λs = np.linalg.eigvalsh(Q)
    assert np.all(
        np.isreal(λs)
    ), "The eigenvalues of the modularity matrix are not real."
    λ = np.max(λs)
    λ = np.max([λ, 0]) + 1e-10  # We add a small value to avoid numerical issues.
    S = Q - λ * np.eye(n)
    assert np.all(
        np.linalg.eigvalsh(S) <= 0
    ), "The shifted modularity matrix is not negative semidefinite."
    return S
