from io import BytesIO
from collections import OrderedDict
from typing import Optional, Dict, List, Tuple
import torch
from torch import nn
from packaging.version import Version
from ti_models.models.circuit.ti_circuit import TICircuit
from ti_models.models.model_metadata import ModelMetadata
from ti_models.utils.utils import (
    PrettyPrinter,
    SerializableMixin,
    get_device,
    BYTE_ORDER,
    append_marshaled_block,
    marshal_string_data,
    unmarshal_size,
    unmarshal_string,
    unmarshal_block,
)
from ti_models.models.layers.ti_layer import TILayer, LayerType
from ti_models.preprocessing.preprocessing import Preprocessing


class TIModel(SerializableMixin):
    """
    Abstract base class for Tune Insight's machine learning models. TI models inherit from
    PyTorch nn.Module and integrate import/export tools compatible with Tune Insight's backend,
    as well as conversion tools used for Secure Model Inference on encrypted data (MaaS).

    Attributes:
        version (Version): The version of the binary serialization format of the TIModel.
        name (str): The name identifier for the model
        description (Optional[str]): A description of the model's purpose and architecture
        n_classes (Optional[int]): The number of output classes for the model if it is a classifier
        device (Optional[torch.device]): The device to run the model on (CPU or GPU/cuda)
        train_graph (Optional[torch.fx.GraphModule]): The serializable training graph of the model
        eval_graph (Optional[torch.fx.GraphModule]): The serializable evaluation graph of the model
        preprocessing (Optional[Preprocessing]): Preprocessing transforms to apply to inputs
        metadata (ModelMetadata): Information about the model's history and training data
        layers (OrderedDict[str, TILayer]): OrderedDict of layers indexed by their names in the model
        circuit (TICircuit): The circuit representation of the model.
    """

    # Version of the binary serialization format of the TIModel
    version = Version("1.0.1")

    def __init__(
        self,
        name: str,
        description: Optional[str] = None,
        n_classes: Optional[int] = None,
        device: Optional[torch.device] = None,
        torch_model: Optional[nn.Module] = None,
        train_graph: Optional[torch.fx.GraphModule] = None,
        eval_graph: Optional[torch.fx.GraphModule] = None,
        preprocessing: Optional[Preprocessing] = None,
        metadata: Optional[ModelMetadata] = None,
        layers: Optional[OrderedDict[str, TILayer]] = None,
        circuit: Optional[TICircuit] = None,
    ):
        """
        Initialize the TIModel.

        Args:
            name (str): The name identifier for the model.
            description (Optional[str], optional): A description of the model's purpose and architecture. Defaults to None.
            n_classes (Optional[int], optional): The number of output classes for the model if it is a classifier. Defaults to None.
            device (Optional[torch.device], optional): The device to run the model on (CPU or GPU/cuda). Defaults to None.
            torch_model (Optional[nn.Module], optional): The underlying PyTorch model to generate serializable train and eval graphs from. Defaults to None.
            train_graph (Optional[torch.fx.GraphModule], optional): The serializable training graph of the model. Defaults to None.
            eval_graph (Optional[torch.fx.GraphModule], optional): The serializable evaluation graph of the model. Defaults to None.
            preprocessing (Optional[Preprocessing]): Preprocessing including transforms to apply to inputs. Defaults to None.
            metadata (Optional[ModelMetadata], optional): Information about the model's history and training data. Defaults to None.
            layers (Optional[OrderedDict[str, TILayer]], optional): OrderedDict of layers indexed by their names in the model. Defaults to None.
            circuit (Optional[TICircuit], optional): The circuit representation of the model (MaaS). Defaults to None.
        """

        if (train_graph is None) ^ (eval_graph is None):
            raise ValueError(
                "Both train_graph and eval_graph must be provided or both must be None."
            )

        if device == "cuda" and not torch.cuda.is_available():
            raise ValueError("CUDA device requested but not available.")

        if torch_model is not None and train_graph is not None:
            raise ValueError(
                "Only one of torch_model or train_graph/eval_graph should be provided."
            )

        if preprocessing is None:
            raise ValueError("Preprocessing must be provided.")

        super().__init__()

        self.version = TIModel.version
        self.name = name
        self.description = description or ""
        self.n_classes = n_classes
        self.device = device or get_device()
        self.train_graph = train_graph
        self.eval_graph = eval_graph
        self.preprocessing = preprocessing
        self.metadata = metadata or ModelMetadata()
        self.layers: OrderedDict[str, TILayer] = layers or OrderedDict()
        self.circuit = circuit

        if torch_model is not None:
            torch_model.to(self.device)

            # Note: with export(), both training and evaluation graphs share the same weights object, which is
            # an unexpected but desired behavior. `sync_eval_graph` ensures this in case this behavior changes.
            torch_model.train()
            self.train_graph = torch.export.export_for_training(
                mod=torch_model,
                args=(self.get_dummy_input(),),
                dynamic_shapes=[{0: torch.export.Dim("batch")}],
            )

            torch_model.eval()
            self.eval_graph = torch.export.export(
                mod=torch_model,
                args=(self.get_dummy_input(),),
                dynamic_shapes=[{0: torch.export.Dim("batch")}],
            )

            self.sync_eval_graph()

        if self.train_graph is not None and self.eval_graph is not None:
            self.generate_layers_from_torch()

    def __str__(self) -> str:
        class_name = self.__class__.__name__
        fields = [
            f"version={self.version}",
            f"name={self.name}",
            f"input_type={self.preprocessing.input_type.value}({self.preprocessing.input_type.name})",
            f"description={self.description}",
            f"n_classes={self.n_classes or 'N/A'}",
            f"device={self.device}",
            f"metadata={self.metadata}",
            f"len(layers)={len(self.layers):,}",
            f"num_params={self.get_n_params():,}",
            f"num_trainable_params={self.get_n_params(trainable_only=True):,}",
        ]

        fields_str = ",\n".join(f"{field}" for field in fields)
        return f"{class_name}(\n{PrettyPrinter.indent(fields_str)}\n)"

    def __eq__(self, other: object) -> bool:
        """
        Check if this TIModel is equal to another TIModel.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the models are equal, False otherwise.
        """
        if not isinstance(other, TIModel):
            return False

        return (
            self.name == other.name
            and self.description == other.description
            and self.n_classes == other.n_classes
            and self.device == other.device
            and self.preprocessing == other.preprocessing
            and self.metadata == other.metadata
            and frozenset(self.layers.items()) == frozenset(other.layers.items())
            and self.circuit == other.circuit
        )

    def __hash__(self):
        return hash(
            (
                self.name,
                self.description,
                self.n_classes,
                self.device,
                self.preprocessing,
                self.metadata,
                frozenset(self.layers.items()),
                self.circuit,
            )
        )

    def get_n_params(self, trainable_only: bool = False) -> int:
        """
        Returns the total number of parameters in the model.

        Args:
            trainable_only (bool): If True, only count trainable parameters. Defaults to False.

        Returns:
            int: Total number of parameters in the model
        """

        n_parameters = 0
        for layer in self.layers.values():
            if not trainable_only or layer.trainable:
                n_parameters += len(layer.data)

        return n_parameters

    def update_from_torch(self) -> None:
        """
        Updates the TIModel's layers from the underlying PyTorch graph model.

        Raises:
            ValueError: If no torch model has been set for the TIModel.
        """

        if self.train_graph is None:
            raise ValueError("No training graph has been set from a torch model")

        self.generate_layers_from_torch()

    def get_flatten_named_children(
        self, name_prefix="", parent: Optional[nn.Module] = None
    ) -> Dict[str, "nn.Module"]:
        """
        Recursive function that returns a map of every layer of the model referenced by its name

        Args:
            name_prefix (str): Prefix to prepend to layer names in the returned mapping
            parent (Optional[nn.Module]): Parent module to get children from. Defaults to self.model

        Returns:
            Dict[str, "nn.Module"]: a dict referencing every layer of the model
        """
        if self.train_graph is None:
            raise ValueError("No training graph has been set from a torch model")

        if parent is None:
            parent = self.train_graph.module()

        named_children = list(parent.named_children())

        if not named_children:
            return {name_prefix: parent}

        flatten_named_children = {}

        for child_name, child in named_children:
            name = ".".join([name_prefix, child_name]) if name_prefix else child_name
            flatten_named_children = (
                flatten_named_children | self.get_flatten_named_children(name, child)
            )

        return flatten_named_children

    def replace_layers(self, layer_mapping: Dict[str, "nn.Module"]):
        """
        Replace the layers of a model according to the provided map by recursively finding them in the children.

        Args:
            layer_mapping (Dict[str, "nn.Module"]): the layers (submodules) to replace the original layers with.
        """
        if self.train_graph is None:
            raise ValueError("No training graph has been set from a torch model")

        for name, layer in layer_mapping.items():
            sub_module = self.train_graph
            sub_names = name.split(".")

            # Recursive search for the layer in the children
            for sub_name in sub_names[:-1]:
                sub_module = getattr(sub_module, sub_name)

            setattr(
                sub_module,
                sub_names[-1],
                layer,
            )

    def generate_layers_from_torch(self):
        """
        Updates the layers attribute by extracting all named children from the torch graph module.
        Adds only trainable layers to the export as the export is intended for FL aggregations only.
        See ONNXModel for more complete export including circuit.

        Args:
            trainable_only (bool): If True, only trainable layers are added to the export.
                If False, all layers are included.

        Raises:
            ValueError: If no torch model has been set.
        """

        if self.train_graph is None:
            raise ValueError("No training graph has been set from a torch model")

        self.layers = OrderedDict()

        for layer_name, layer in self.get_flatten_named_children().items():
            ti_layers = TILayer.from_torch_module(layer_name, layer)

            for ti_layer_name, ti_layer in ti_layers.items():
                self.layers[ti_layer_name] = ti_layer

    def weight_update_from_binary(
        self, binary_model: bytes, byteorder: str = BYTE_ORDER
    ):
        """Update the model weights from a binary representation of another TIModel.

        Args:
            binary_model (bytes):
            byteorder (str, optional): Description of the byte order. Defaults to BYTE_ORDER.

        Raises:
            ValueError: _no training or evaluation graph has been set from a torch model_
            ValueError: _unexpected keys during model import_
        """
        if self.train_graph is None or self.eval_graph is None:
            raise ValueError(
                "No training or evaluation graph has been set from a torch model"
            )

        new_model = TIModel.unmarshal_binary(
            binary_model=binary_model, byteorder=byteorder
        )
        state_dict = new_model.generate_torch_state_dict()

        # strict=False permit to update only a subset of the layer (the aggregated ones)
        incompatible_keys = self.train_graph.module().load_state_dict(
            state_dict=state_dict, strict=False
        )
        self.sync_eval_graph()

        # throw an exception if some layers from the binary model were not present in the TIModel
        if incompatible_keys.unexpected_keys:
            raise ValueError(
                f"Unexpected keys during model import: {incompatible_keys.unexpected_keys}"
            )

        self.update_from_torch()

    def generate_torch_state_dict(self) -> OrderedDict[str, torch.Tensor]:
        """
        Generates the PyTorch-compatible state dict containing the weight from the TILayers.

        Returns:
            OrderedDict[str, torch.Tensor]: The torch state dict.
        """
        state_dict = OrderedDict()
        for layer_name, layer in self.layers.items():
            if layer.data:
                if len(layer.shape) == 0:
                    state_dict[layer_name] = torch.tensor(layer.data)
                else:
                    state_dict[layer_name] = torch.tensor(layer.data).reshape(
                        layer.shape
                    )

        return state_dict

    def get_dummy_input(self) -> torch.Tensor:
        if self.preprocessing is None:
            raise ValueError("No preprocessing has been set")

        sample_input_size = self.preprocessing.get_output_shape()
        dummy_batch_size = 2

        dummy_input = torch.randn((dummy_batch_size,) + sample_input_size)

        return dummy_input

    def sync_eval_graph(self):
        """Syncs the evaluation graph weights with the training graph weights."""
        self.eval_graph.module().load_state_dict(self.train_graph.module().state_dict())

    def marshal_binary(
        self,
        fl_only: bool,
        include_arch: bool = True,
        include_circuit: bool = False,
        byteorder: str = BYTE_ORDER,
    ) -> bytes:
        """
        Serializes the model into binary format for the backend.

        Marshalling order:
            1. version
            2. name
            3. description
            4. device
            5. n_classes
            6. train_graph
            7. eval_graph
            8. preprocessing
            9. metadata
            10. layers
            11. circuit

        Args:
            fl_only (bool): If True, only relevant layers for federated learning are included in the serialization.
            include_arch (bool): If True, include the model graphs for reconstruction (model sharing).
            include_circuit (bool): If True, include the circuit of the model (MaaS).
            byteorder (str): The byte order to use for serialization. Defaults to BYTE_ORDER.

        Returns:
            bytes: A binary representation of the TIModel.
        """

        buffer = BytesIO()

        for attr in [
            str(TIModel.version),
            self.name,
            self.description,
            str(self.device),
        ]:
            marshal_string_data(buffer, attr, byteorder)

        n_classes = self.n_classes or 0
        buffer.write(n_classes.to_bytes(4, byteorder, signed=False))

        if self.train_graph is None or include_arch is False:
            train_graph_data = bytearray()
        else:
            # Get train graph size and train graph data
            train_graph_buffer = BytesIO()
            torch.export.save(self.train_graph, train_graph_buffer)
            train_graph_data = train_graph_buffer.getvalue()
        append_marshaled_block(buffer, train_graph_data, byteorder)

        if self.eval_graph is None or include_arch is False:
            eval_graph_data = bytearray()
        else:
            # Get eval graph size and eval graph data
            eval_graph_buffer = BytesIO()
            torch.export.save(self.eval_graph, eval_graph_buffer)
            eval_graph_data = eval_graph_buffer.getvalue()
        append_marshaled_block(buffer, eval_graph_data, byteorder)

        preprocessing_data = self.preprocessing.marshal_binary(byteorder)
        append_marshaled_block(buffer, preprocessing_data, byteorder)

        metadata_data = self.metadata.marshal_binary(byteorder)
        append_marshaled_block(buffer, metadata_data, byteorder)

        layers_data = self.marshal_binary_layers(fl_only, byteorder)
        append_marshaled_block(buffer, layers_data, byteorder)

        if self.circuit is None or include_circuit is False:
            circuit_data = bytearray()
        else:
            circuit_data = self.circuit.marshal_binary(byteorder)
        append_marshaled_block(buffer, circuit_data, byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, binary_model: bytes, byteorder: str = BYTE_ORDER
    ) -> "TIModel":
        """
        Deserialize binary data into a TIModel object.

        Args:
            binary_model (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for unmarshaling. Defaults to BYTE_ORDER.

        Returns:
            TIModel: The deserialized TIModel object.
        """
        f = BytesIO(binary_model)

        version = Version(unmarshal_string(f, byteorder))
        if not cls.is_serialization_compatible(version):
            raise ValueError(
                f"Incompatible model version: {version}. Expected version: {cls.version}"
            )

        name = unmarshal_string(f, byteorder)
        description = unmarshal_string(f, byteorder)
        device = torch.device(unmarshal_string(f, byteorder))

        n_classes = int.from_bytes(f.read(4), byteorder, signed=False)
        if n_classes == 0:
            n_classes = None

        train_graph_size = unmarshal_size(f, byteorder)
        train_graph = None
        if train_graph_size > 0:
            train_graph_data = f.read(train_graph_size)
            buffer = BytesIO(train_graph_data)
            train_graph = torch.export.load(buffer)

        eval_graph_size = unmarshal_size(f, byteorder)
        eval_graph = None
        if eval_graph_size > 0:
            eval_graph_data = f.read(eval_graph_size)
            buffer = BytesIO(eval_graph_data)
            eval_graph = torch.export.load(buffer)

        preprocessing_data = unmarshal_block(f, byteorder)
        preprocessing = Preprocessing.unmarshal_binary(
            binary_preprocessing=preprocessing_data,
            byteorder=byteorder,
        )

        metadata_data = unmarshal_block(f, byteorder)
        metadata = ModelMetadata.unmarshal_binary(
            binary_data=metadata_data,
            byteorder=byteorder,
        )

        layers_data = unmarshal_block(f, byteorder)
        layers = _unmarshal_binary_layers(layers_data, byteorder)

        circuit_size = unmarshal_size(f, byteorder)
        circuit = None
        if circuit_size > 0:
            circuit = TICircuit.unmarshal_binary(f.read(circuit_size), byteorder)

        ti_model = cls(
            name=name,
            description=description,
            n_classes=n_classes,
            device=device,
            train_graph=train_graph,
            eval_graph=eval_graph,
            preprocessing=preprocessing,
            metadata=metadata,
            layers=layers,
            circuit=circuit,
        )

        return ti_model

    def marshal_binary_layers(
        self, fl_only: bool, byteorder: str = BYTE_ORDER
    ) -> bytes:

        buffer = BytesIO()

        # Collect layers to be serialized
        layers_to_serialize: List[Tuple[str, TILayer]] = []
        n_layers_total: int = len(self.layers)
        for layer_name, layer in self.layers.items():
            # Do not include unneeded layers for FL if the export is intended for FL aggregations.
            is_batch_norm_stat = (
                layer.layer_type is LayerType.BATCH_NORM_RUNNING_MEAN
                or layer.layer_type is LayerType.BATCH_NORM_RUNNING_VAR
            )
            # If the model is shallow, the batch norm stats are needed to compute coefficients in the backend
            needed_for_coeffs = n_layers_total < 10 and is_batch_norm_stat

            # Do not include unneeded layers for FL if the export is intended for FL aggregations.
            if fl_only is True and not layer.is_fl_layer() and not needed_for_coeffs:
                continue
            layers_to_serialize.append((layer_name, layer))

        # Write the correct number of layers
        n_layers = len(layers_to_serialize)
        buffer.write(n_layers.to_bytes(8, byteorder, signed=False))

        for layer_name, layer in layers_to_serialize:
            marshal_string_data(buffer, layer_name, byteorder)
            layer_content_data = layer.marshal_binary(byteorder)
            append_marshaled_block(buffer, layer_content_data, byteorder)

        return buffer.getvalue()


def _unmarshal_binary_layers(
    binary_layers: bytes, byteorder: str = BYTE_ORDER
) -> "OrderedDict[str, TILayer]":
    layer_dict: OrderedDict[str, TILayer] = OrderedDict()

    f = BytesIO(binary_layers)

    n_layers = unmarshal_size(f, byteorder)

    for _ in range(n_layers):
        name = unmarshal_string(f, byteorder)
        layer_data = unmarshal_block(f, byteorder)

        layer_dict[name] = TILayer.unmarshal_binary(layer_data, byteorder)

    return layer_dict
