from typing import Dict, Type, Any
import torch
from torch.nn import Module, SiLU
from ti_models.models.ti_model import TIModel
from ti_models.models.classifiers.mlp import (
    MLPClassifier,
    LogisticRegression,
)
from ti_models.models.classifiers.cnn import MnistCNN
from ti_models.models.classifiers.classifier import TIClassifier
from ti_models.models.regressors.mlp import LinearRegression
from ti_models.models.miscellaneous.testing_models import (
    TestModelSimple,
    TestModelAdvanced,
)
from ti_models.models.chenyaofo.resnet import create_resnet20
from ti_models.preprocessing.presets import (
    MNIST_PREPROCESSING_GRAYSCALE,
    CIFAR_PREPROCESSING,
)

TI_MODELS: Dict[str, Dict[str, Any]] = {
    "mlp_mnist": {
        "class": MLPClassifier,
        "params": {
            "input_dim": 28 * 28,
            "n_classes": 10,
            "hidden_dims": (92, 92),
            "name": "MLP_MNIST",
            "description": "MLP Classifier for MNIST",
        },
    },
    "cnn_mnist": {
        "class": MnistCNN,
        "params": {
            "name": "CNN_MNIST",
            "batch_norm": True,
            "description": "CNN Classifier for MNIST",
            "preprocessing": MNIST_PREPROCESSING_GRAYSCALE,
        },
    },
    "resnet20_cifar": {
        "class": TIClassifier,
        "params": {
            "name": "ResNet20_CIFAR",
            "n_classes": 10,
            "description": "ResNet-20 Classifier for CIFAR, developed by chenyaofo (github.com/chenyaofo), using SiLU activations",
            "preprocessing": CIFAR_PREPROCESSING,
        },
        "torch_model_constructor": create_resnet20,
        "torch_model_params": {
            "arch": "resnet20",
            "layers": [3] * 3,
            "pretrained": True,
            "num_classes": 10,
            "activation": SiLU,
        },
    },
    "resnet20_cifar_relu": {
        "class": TIClassifier,
        "params": {
            "name": "ResNet20_CIFAR",
            "n_classes": 10,
            "description": "ResNet-20 Classifier for CIFAR, developed by chenyaofo (github.com/chenyaofo), using ReLU activations",
            "preprocessing": CIFAR_PREPROCESSING,
        },
        "torch_model_constructor": torch.hub.load,
        "torch_model_params": {
            "repo_or_dir": "chenyaofo/pytorch-cifar-models",
            "model": "cifar10_resnet20",
            "pretrained": True,
        },
    },
    "linreg": {
        "class": LinearRegression,
        "params": {
            "name": "Linear_Regression",
            "description": "Linear Regression model",
        },
        "required_params": [
            "input_dim",
        ],
    },
    "logreg": {
        "class": LogisticRegression,
        "params": {
            "name": "Logistic_Regression",
            "description": "Logistic Regression classifier with multiclass support",
        },
        "required_params": [
            "input_dim",
            "n_classes",
        ],
    },
    "binary_logreg": {
        "class": LogisticRegression,
        "params": {
            "n_classes": 2,
            "single_logit": True,
            "name": "Binary_Logistic_Regression",
            "description": "Binary Logistic Regression classifier with single output neuron",
        },
        "required_params": [
            "input_dim",
        ],
    },
    "maas_test_simple": {"class": TestModelSimple},
    "maas_test_advanced": {"class": TestModelAdvanced},
}


def list_available_models() -> dict[str, dict]:
    """
    Returns a dict of available model keys to their display names and descriptions.

    Returns:
        Dict[str, dict]: Each key maps to a dict with 'name' and 'description'.
    """
    models = {}
    for key, info in TI_MODELS.items():
        params = info.get("params", {})
        models[key] = {
            "name": params.get("name", key),
            "description": params.get("description", ""),
        }
    return models


def get_premade_ti_model(name: str, **kwargs) -> TIModel:
    """
    Factory function to return a pre-created TI Model referenced by name.

    Args:
        name (str): The name of the pre-created model to retrieve.
        **kwargs: Additional keyword arguments specific to the model_class.

    Returns:
        TIModel: An instance of the specified pre-created model.

    Raises:
        ValueError: If the TI Model is not found in predefined models.
    """
    if name.lower() not in TI_MODELS:
        raise ValueError(f"TI Model with name '{name}' not found.")

    model_info = TI_MODELS[name]
    model_class: Type[TIModel] = model_info["class"]

    required_params = model_info.get("required_params", [])
    for req_param in required_params:
        if req_param not in kwargs:
            raise ValueError(
                f"Missing required parameter '{req_param}' for TI Model '{name}'"
            )

    params = model_info.get("params", {})
    params.update(kwargs)

    # If a torch model is passed by a constructor
    if "torch_model_constructor" in model_info:
        torch_model_params = model_info.get("torch_model_params", {})
        torch_model: Module = model_info["torch_model_constructor"](
            **torch_model_params
        )
        params["torch_model"] = torch_model

    return model_class(**params)
