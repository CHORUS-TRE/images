from typing import Dict, Any
from torch import nn
from ti_models.trainer.ti_loss import TILoss
from ti_models.trainer.ti_trainer import TITrainer
from ti_models.factories.ti_model_factory import get_premade_ti_model, TI_MODELS
from ti_models.trainer.ti_optimizer import TIOptimizer, OptimizerType

TI_TRAINERS: Dict[str, Dict[str, Any]] = {
    "mlp_mnist": {
        "model_name": "mlp_mnist",
        "params": {
            "loss": TILoss(loss_func=nn.CrossEntropyLoss()),
            "optimizer": TIOptimizer(
                optimizer_type=OptimizerType.SECURE_SGD, lr=0.001, momentum=0.9
            ),
            "batch_size": 128,
        },
    },
    "cnn_mnist": {
        "model_name": "cnn_mnist",
        "params": {
            "loss": TILoss(loss_func=nn.CrossEntropyLoss()),
            "optimizer": TIOptimizer(
                optimizer_type=OptimizerType.SECURE_SGD, lr=0.001, momentum=0.9
            ),
            "batch_size": 128,
        },
    },
    "resnet20_cifar": {
        "model_name": "resnet20_cifar",
        "params": {
            "loss": TILoss(loss_func=nn.CrossEntropyLoss()),
            "optimizer": TIOptimizer(
                optimizer_type=OptimizerType.SECURE_SGD, lr=0.01, momentum=0.9
            ),
            "batch_size": 256,
        },
    },
    "resnet20_cifar_relu": {
        "model_name": "resnet20_cifar_relu",
        "params": {
            "loss": TILoss(loss_func=nn.CrossEntropyLoss()),
            "optimizer": TIOptimizer(
                optimizer_type=OptimizerType.SECURE_SGD, lr=0.01, momentum=0.9
            ),
            "batch_size": 256,
        },
    },
    "linreg": {
        "model_name": "linreg",
        "params": {
            "loss": TILoss(loss_func=nn.MSELoss()),
            "optimizer": TIOptimizer(
                optimizer_type=OptimizerType.SECURE_SGD, lr=0.1, momentum=0.9
            ),
            "batch_size": 16,
        },
        "required_params": [
            "input_dim",
        ],
    },
    "logreg": {
        "model_name": "logreg",
        "params": {
            "loss": TILoss(loss_func=nn.CrossEntropyLoss()),
            "optimizer": TIOptimizer(
                optimizer_type=OptimizerType.SECURE_SGD, lr=0.1, momentum=0.9
            ),
            "batch_size": 16,
        },
        "required_params": [
            "input_dim",
            "n_classes",
        ],
    },
    "binary_logreg": {
        "model_name": "binary_logreg",
        "params": {
            "loss": TILoss(loss_func=nn.BCEWithLogitsLoss()),
            "optimizer": TIOptimizer(
                optimizer_type=OptimizerType.SECURE_SGD, lr=0.1, momentum=0.9
            ),
            "batch_size": 16,
        },
        "required_params": [
            "input_dim",
        ],
    },
}


def list_available_trainers() -> dict[str, dict]:
    """
    Returns a dict of available trainer keys to their details, including model description,
    loss, optimizer, and batch size.

    Returns:
        Dict[str, dict]: Each key maps to a dict with 'model_name', 'model_description',
                         'loss', 'optimizer', and 'batch_size'.
    """
    trainers = {}
    for key, info in TI_TRAINERS.items():
        params = info.get("params", {})
        model_key = info.get("model_name", "")
        model_info = TI_MODELS.get(model_key, {})
        model_params = model_info.get("params", {})
        model_name = model_params.get("name", model_key)
        model_description = model_params.get("description", "")

        trainers[key] = {
            "model_name": model_name,
            "model_description": model_description,
            "loss": str(params.get("loss", "")),
            "optimizer": str(params.get("optimizer", "")),
            "batch_size": params.get("batch_size", None),
        }

    return trainers


def get_premade_ti_trainer(name: str, **kwargs) -> TITrainer:
    """
    Factory function to return a pre-created TI Trainer referenced by name.

    Args:
        name (str): The name of the pre-created trainer to retrieve.
        **kwargs: Additional keyword arguments specific to the trainer_class.

    Returns:
        TITrainer: An instance of the specified pre-created trainer.
    Raises:
        ValueError: If the TI Trainer is not found in predefined trainers.
    """
    if name.lower() not in TI_TRAINERS:
        raise ValueError(f"TI Trainer with name '{name}' not found.")

    # list of possible model parameters to pass to the TI Model factory
    model_param_names = {"input_dim", "n_classes"}

    trainer_info = TI_TRAINERS[name]

    if not "model_name" in trainer_info:
        raise ValueError(
            "The 'model_name' parameter must be specified to get the TI Model"
        )

    required_params = trainer_info.get("required_params", [])
    for req_param in required_params:
        if req_param not in kwargs:
            raise ValueError(
                f"Missing required parameter '{req_param}' for TI Model '{name}'"
            )

    params = trainer_info.get("params", {})

    model_kwargs = {}
    for model_param in model_param_names:
        if model_param in kwargs:
            model_kwargs[model_param] = kwargs.pop(model_param)

    params["model"] = get_premade_ti_model(trainer_info["model_name"], **model_kwargs)

    params.update(kwargs)

    return TITrainer(**params)
