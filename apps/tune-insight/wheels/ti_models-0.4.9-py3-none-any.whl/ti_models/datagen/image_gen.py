from typing import Tuple
import torch
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import numpy as np
from PIL import Image


class RandomImageGenerator(Dataset):

    def __init__(
        self,
        image_size: Tuple[int],
        n_channels: int = 3,
        n_classes: int = 10,
        n_items: int = 10000,
        transform=None,
    ):
        self.image_size = image_size
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.n_items = n_items
        self.transform = transform

    def __len__(self):
        return self.n_items

    def __getitem__(self, idx):
        np.random.seed(idx)

        # Generate a random image
        pixel_array = (
            np.random.rand(self.image_size[0], self.image_size[1], self.n_channels)
            * 255
        )
        random_image = Image.fromarray(pixel_array.astype("uint8")).convert("RGBA")

        # Generate a random label for classification
        label = np.random.randint(0, self.n_classes)

        # Apply transformations (if any)
        if self.transform:
            random_image = self.transform(random_image)

        return random_image.clone().detach(), torch.tensor(label)


def get_random_image_loader(
    image_size: Tuple[int],
    n_channels: int = 3,
    n_classes: int = 10,
    n_items: int = 10000,
    transform=None,
    batch_size: int = 64,
) -> DataLoader:
    image_gen = RandomImageGenerator(
        image_size=image_size,
        n_channels=n_channels,
        n_classes=n_classes,
        n_items=n_items,
        transform=transform,
    )

    return DataLoader(image_gen, batch_size=batch_size, shuffle=False)
