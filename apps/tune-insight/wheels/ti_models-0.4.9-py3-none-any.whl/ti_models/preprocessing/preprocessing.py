from io import BytesIO
from typing import List, Tuple, Optional
from torchvision import transforms as tv_transforms

from ti_models.preprocessing.transform import Transform, TransformType
from ti_models.models.data_types import InputType
from ti_models.utils.utils import BYTE_ORDER, PrettyPrinter, append_marshaled_block


class Preprocessing:
    """
    Represents chain of preprocessing transforms to apply to the input of a TIModel.

    Attributes:
        input_type (InputType): The type of input this preprocessing handles. Defaults to InputType.UNKNOWN.
        transforms (List[Transform]): List of transforms to apply to the input. Defaults to an empty list.
        input_shape (Optional[Tuple[int, ...]]): The expected shape of input data. Needed for secure inference conversion.
    """

    def __init__(
        self,
        input_type: InputType = None,
        transforms: List[Transform] = None,
        input_shape: Optional[Tuple[int]] = None,
    ):
        """
        Initialize Preprocessing.
        """
        self.input_type = input_type or InputType.UNKNOWN
        self.transforms = transforms or []
        self.input_shape = input_shape

    def __str__(self) -> str:
        class_name = self.__class__.__name__

        transform_str = (
            "\n"
            + PrettyPrinter.indent(",\n".join(str(t) for t in self.transforms))
            + "\n"
        )

        fields = [
            f"input_type={self.input_type.value}({self.input_type.name})",
            f"input_shape={self.input_shape}",
            f"transforms=[{transform_str if self.transforms else ''}]",
        ]

        fields_str = ",\n".join(f"{field}" for field in fields)
        return f"{class_name}(\n{PrettyPrinter.indent(fields_str)}\n)"

    def __eq__(self, other: object) -> bool:
        """
        Check if this Preprocessing instance is equal to another Preprocessing instance.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the preprocessing instances are equal, False otherwise.
        """
        if not isinstance(other, Preprocessing):
            return False

        return (
            self.input_type == other.input_type
            and self.transforms == other.transforms
            and self.input_shape == other.input_shape
        )

    def __hash__(self):
        return hash((self.input_type, tuple(self.transforms), self.input_shape))

    def get_output_shape(self) -> Tuple[int]:
        """
        Calculate the output shape after applying the preprocessing transforms.

        Returns:
            Tuple[int]: The shape of the data after all transforms have been applied.
        """
        output_shape = self.input_shape

        if output_shape is None:
            if self.input_type is not InputType.IMAGE:
                raise ValueError(
                    "Cannot get output shape: input_shape is None and input_type is not IMAGE"
                )

            output_shape = (3, 16, 16)  # Default shape for image

        elif self.input_type is InputType.IMAGE:
            # Add default number of channel for images
            default_channels = 3
            output_shape = (default_channels,) + output_shape

        if not self.transforms:
            return output_shape

        for transform in self.transforms:
            if transform.transform_type in (
                TransformType.IMAGE_RESIZE,
                TransformType.IMAGE_CENTER_CROP,
            ):
                output_shape = (
                    output_shape[0],
                    transform.params[0],
                    transform.params[1],
                )
            elif transform.transform_type == TransformType.IMAGE_TO_GRAYSCALE:
                output_shape = (transform.params[0], output_shape[1], output_shape[2])

        return output_shape

    def generate_torchvision_compose(self) -> "transforms.Compose":
        """
        Generate a torchvision.transforms.Compose object from an image transform.

        Returns:
            transforms.Compose: The generated Compose object.
        """

        if not all(transform.is_image_transform() for transform in self.transforms):
            raise ValueError("All transforms must be image transforms.")

        torch_vision_transforms = []
        for transform in self.transforms:
            torch_vision_transforms.append(transform.tv_transform)

        return tv_transforms.Compose(torch_vision_transforms)

    @classmethod
    def from_torchvision_compose(
        cls,
        compose: "transforms.Compose",
        input_shape: Optional[Tuple[int]] = None,
    ) -> "Preprocessing":
        """
        Create an image Preprocessing object from a torchvision.transforms.Compose object.

        Args:
            compose (torchvision.transforms.Compose): The Compose object containing transforms
            input_shape (Optional[Tuple[int]], optional): Expected input shape. Defaults to None.

        Returns:
            Preprocessing: A new image Preprocessing instance with the converted transforms
        """
        transforms: list[Transform] = []
        n_channels = 3

        for tv_transform in compose.transforms:
            transform = Transform.from_tv_transform(tv_transform, n_channels=n_channels)
            transforms.append(transform)

            # If grayscale is present, subsequent transforms are applied to a single channel
            if transform.transform_type == TransformType.IMAGE_TO_GRAYSCALE:
                n_channels = 1

        return cls(
            input_type=InputType.IMAGE, transforms=transforms, input_shape=input_shape
        )

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Serialize the preprocessing representation into a binary format.

        Args:
            byteorder (str, optional): The byte order to use for marshaling. Defaults to BYTE_ORDER.

        Raises:
            ValueError: If input_shape is None.

        Returns:
            bytes: The serialized binary representation of the Preprocessing.
        """
        if self.input_shape is None:
            raise ValueError("Input shape cannot be None for marshalling.")

        buffer = BytesIO()

        # Append input type
        buffer.write(int(self.input_type).to_bytes(1, byteorder, signed=False))

        # Append size of input shape
        input_shape_size: int = len(self.input_shape)
        buffer.write(input_shape_size.to_bytes(8, byteorder, signed=False))

        # Append input shape
        for dim in self.input_shape:
            buffer.write(int(dim).to_bytes(4, byteorder, signed=False))

        # Append size of preprocessing
        preprocessing_size: int = len(self.transforms)
        buffer.write(preprocessing_size.to_bytes(8, byteorder, signed=False))

        # Append preprocessing transforms
        for transform in self.transforms:
            transform_bytes = transform.marshal_binary(byteorder=byteorder)

            # Append the size of the transform
            append_marshaled_block(buffer, transform_bytes, byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, binary_preprocessing: bytes, byteorder: str = BYTE_ORDER
    ) -> "Preprocessing":
        """
        Unmarshal binary data into the preprocessing representation.

        Args:
            binary_preprocessing (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for serialization. Defaults to BYTE_ORDER.

        Returns:
            Preprocessing: The deserialized Preprocessing object.
        """
        f = BytesIO(binary_preprocessing)

        # Read input type
        input_type = InputType(int.from_bytes(f.read(1), byteorder, signed=False))

        input_shape = []
        transforms = []

        # Read input shape size
        input_shape_size = int.from_bytes(f.read(8), byteorder, signed=False)

        # Read input shape
        for _ in range(input_shape_size):
            input_shape.append(int.from_bytes(f.read(4), byteorder, signed=False))

        # Read number of transforms
        num_transforms = int.from_bytes(f.read(8), byteorder, signed=False)

        for _ in range(num_transforms):
            # Read transform size
            transform_size = int.from_bytes(f.read(8), byteorder, signed=False)

            # Read transform bytes
            transform_bytes = f.read(transform_size)

            transforms.append(
                Transform.unmarshal_binary(transform_bytes, byteorder=byteorder)
            )

        return cls(
            input_type=input_type, transforms=transforms, input_shape=tuple(input_shape)
        )
