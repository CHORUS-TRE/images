from torchvision import transforms
from ti_models.preprocessing.preprocessing import Preprocessing

IMAGENET_STATS = {
    "mean": [0.485, 0.456, 0.406],
    "std": [0.229, 0.224, 0.225],
}

CIFAR_STATS = {
    "mean": [0.4914, 0.4822, 0.4465],
    "std": [0.2023, 0.1994, 0.2010],
}

CIFAR_TRANSFORM = transforms.Compose(
    [
        transforms.Resize([32, 32]),
        transforms.ToTensor(),
        transforms.Normalize(mean=CIFAR_STATS["mean"], std=CIFAR_STATS["std"]),
    ]
)

CIFAR_PREPROCESSING = Preprocessing.from_torchvision_compose(
    compose=CIFAR_TRANSFORM, input_shape=(32, 32)
)

MNIST_DIMS = (28, 28)

MNIST_STATS = {
    "mean": 0.1307,
    "std": 0.3081,
}

MNIST_TRANSFORM = transforms.Compose(
    [
        transforms.Resize(MNIST_DIMS),
        transforms.ToTensor(),
        transforms.Normalize(mean=MNIST_STATS["mean"], std=MNIST_STATS["std"]),
    ]
)
MNIST_TRANSFORM_GRAYSCALE = transforms.Compose(
    [
        transforms.Resize(MNIST_DIMS),
        transforms.Grayscale(),
        transforms.ToTensor(),
        transforms.Normalize(mean=MNIST_STATS["mean"], std=MNIST_STATS["std"]),
    ]
)

MNIST_PREPROCESSING = Preprocessing.from_torchvision_compose(
    compose=MNIST_TRANSFORM, input_shape=MNIST_DIMS
)
MNIST_PREPROCESSING_GRAYSCALE = Preprocessing.from_torchvision_compose(
    compose=MNIST_TRANSFORM_GRAYSCALE, input_shape=MNIST_DIMS
)
