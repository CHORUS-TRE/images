from io import BytesIO
from typing import List, Optional
from enum import IntEnum
from torchvision import transforms

from ti_models.utils.utils import BYTE_ORDER, marshal_float, unmarshal_float
from ti_models.models.utils import format_size


class TransformType(IntEnum):
    # Image transform types [0-19]
    TO_TENSOR = 0
    NORMALIZE = 1  # (params: [mean[0], mean[1], ..., std[0], std[1], ...])
    IMAGE_CENTER_CROP = 2  # (params: [h, w])
    IMAGE_RESIZE = 3  # (params: [h, w])
    IMAGE_RANDOM_HORIZONTAL_FLIP = 4  # (params: [prob])
    IMAGE_RANDOM_VERTICAL_FLIP = 5  # (params: [prob])
    IMAGE_RANDOM_ROTATION = 6  # (params: [degrees])
    IMAGE_TO_GRAYSCALE = 7  # (params: [num_output_channels])
    IMAGE_INVERT = 8  # (params: [threshold, sign])

    # Tabular input types [20-39]
    FEATURE_INDICES = 20  # (params: [idx0, ..., idxN])
    FEATURE_CLIPPING = 21  # (params: [A, B])


class Transform:
    """
    Class representing a single preprocessing operation with its type and parameters.
    If the transform is an image transform, it is associated to its corresponding torchvision transform.

    Attributes:
        transform_type (TransformType): Type of transform operation
        params (Optional[List[float]]): List of parameters for the transform
        tv_transform (Optional[Any]): A torchvision transform object for image transforms.
    """

    def __init__(
        self,
        transform_type: TransformType,
        params: Optional[List[float]] = None,
    ):
        """
        Initialize a preprocessing operation.
        """

        self.transform_type = transform_type
        self.params = params or []

        if self.is_image_transform():
            self.get_tv_transform()

    def get_tv_transform(self) -> None:
        """
        Get the associated torchvision transform based on an image transform type and parameters.

        Returns:
            Optional[Any]: A torchvision transform object or None.
        """

        tv_transform = None
        if self.transform_type == TransformType.TO_TENSOR:
            tv_transform = transforms.ToTensor()
        elif self.transform_type == TransformType.NORMALIZE:
            n_channels = len(self.params) // 2
            tv_transform = transforms.Normalize(
                mean=tuple(self.params[:n_channels]),
                std=tuple(self.params[n_channels:]),
            )
        elif self.transform_type == TransformType.IMAGE_CENTER_CROP:
            tv_transform = transforms.CenterCrop(size=tuple(self.params))
        elif self.transform_type == TransformType.IMAGE_RESIZE:
            tv_transform = transforms.Resize(size=tuple(self.params))
        elif self.transform_type == TransformType.IMAGE_RANDOM_HORIZONTAL_FLIP:
            tv_transform = transforms.RandomHorizontalFlip(p=self.params[0])
        elif self.transform_type == TransformType.IMAGE_RANDOM_VERTICAL_FLIP:
            tv_transform = transforms.RandomVerticalFlip(p=self.params[0])
        elif self.transform_type == TransformType.IMAGE_RANDOM_ROTATION:
            tv_transform = transforms.RandomRotation(degrees=self.params[0])
        elif self.transform_type == TransformType.IMAGE_TO_GRAYSCALE:
            tv_transform = transforms.Grayscale(num_output_channels=self.params[0])
        elif self.transform_type == TransformType.IMAGE_INVERT:
            tv_transform = transforms.RandomInvert(p=self.params[0])
        else:
            raise ValueError(
                f"Transform type {self.transform_type} is not supported for Image Transform"
            )

        self.tv_transform = tv_transform

    def __str__(self) -> str:
        """
        Returns:
            str: A string representation of transform object
        """

        return f"Transform(transform_type={self.transform_type.value}({self.transform_type.name}), params={self.params})"

    def __eq__(self, other: object) -> bool:
        """
        Check if this Transform is equal to another Transform.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the transforms are equal, False otherwise.
        """
        if not isinstance(other, Transform):
            return False

        return (
            self.transform_type == other.transform_type and self.params == other.params
        )

    def __hash__(self):
        return hash((self.transform_type, tuple(self.params)))

    @classmethod
    def from_tv_transform(cls, tv_transform, n_channels: Optional[int] = None):
        """
        Initialize an Transform with a torchvision transform.
        """
        transform_type = None
        params = []

        if isinstance(tv_transform, transforms.ToTensor):
            transform_type = TransformType.TO_TENSOR
        elif isinstance(tv_transform, transforms.Normalize):
            if not n_channels:
                raise ValueError(
                    "Number of channels must be provided for normalization."
                )
            transform_type = TransformType.NORMALIZE
            params.extend(format_size(tv_transform.mean, n_channels))
            params.extend(format_size(tv_transform.std, n_channels))
        elif isinstance(tv_transform, transforms.CenterCrop):
            transform_type = TransformType.IMAGE_CENTER_CROP
            params.extend(format_size(tv_transform.size, 2))
        elif isinstance(tv_transform, transforms.Resize):
            transform_type = TransformType.IMAGE_RESIZE
            params.extend(format_size(tv_transform.size, 2))
        elif isinstance(tv_transform, transforms.RandomHorizontalFlip):
            transform_type = TransformType.IMAGE_RANDOM_HORIZONTAL_FLIP
            params.extend(format_size(tv_transform.p, 1))
        elif isinstance(tv_transform, transforms.RandomVerticalFlip):
            transform_type = TransformType.IMAGE_RANDOM_VERTICAL_FLIP
            params.extend(format_size(tv_transform.p, 1))
        elif isinstance(tv_transform, transforms.RandomRotation):
            transform_type = TransformType.IMAGE_RANDOM_ROTATION
            params.extend(format_size(tv_transform.degrees, 1))
        elif isinstance(tv_transform, transforms.Grayscale):
            transform_type = TransformType.IMAGE_TO_GRAYSCALE
            params.extend(format_size(tv_transform.num_output_channels, 1))
        else:
            raise ValueError(f"Transform type {type(tv_transform)} is not supported")

        return cls(transform_type, params)

    def is_image_transform(self) -> bool:
        """
        Check if the given transform type is an image transform.

        Args:
            transform_type (TransformType): The transform type to check.

        Returns:
            bool: True if the transform type is an image transform, False otherwise.
        """
        return self.transform_type in {
            TransformType.TO_TENSOR,
            TransformType.NORMALIZE,
            TransformType.IMAGE_CENTER_CROP,
            TransformType.IMAGE_RESIZE,
            TransformType.IMAGE_RANDOM_HORIZONTAL_FLIP,
            TransformType.IMAGE_RANDOM_VERTICAL_FLIP,
            TransformType.IMAGE_RANDOM_ROTATION,
            TransformType.IMAGE_TO_GRAYSCALE,
            TransformType.IMAGE_INVERT,
        }

    def is_tabular_transform(self) -> bool:
        """
        Check if the given transform type is a tabular transform.

        Args:
            transform_type (TransformType): The transform type to check.

        Returns:
            bool: True if the transform type is a tabular transform, False otherwise.
        """
        return self.transform_type in {
            TransformType.FEATURE_INDICES,
            TransformType.FEATURE_CLIPPING,
        }

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Serialize the Transform to a binary format.

        Args:
            byteorder (str): The byte order to use for marshaling. Defaults to BYTE_ORDER.

        Returns:
            bytes: The serialized binary representation of the Transform.
        """
        buffer = BytesIO()

        # Append transform type
        buffer.write(int(self.transform_type).to_bytes(1, byteorder, signed=False))

        # Append params size
        params_size = len(self.params)
        buffer.write(params_size.to_bytes(8, byteorder, signed=False))

        # Append params data
        for param in self.params:
            marshal_float(buffer, float(param), byteorder=byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, binary_data: bytes, byteorder: str = BYTE_ORDER
    ) -> "Transform":
        """
        Deserialize binary data into a Transform object.

        Args:
            binary_data (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for unmarshaling. Defaults to BYTE_ORDER.

        Returns:
            Transform: The deserialized Transform object.
        """
        f = BytesIO(binary_data)

        # Read transform type
        transform_type = TransformType(
            int.from_bytes(f.read(1), byteorder, signed=False)
        )

        # Read params size
        params_size = int.from_bytes(f.read(8), byteorder, signed=False)

        # Read params data
        params = []
        for _ in range(params_size):
            params.append(unmarshal_float(f, byteorder=byteorder))

        return cls(transform_type, params)
