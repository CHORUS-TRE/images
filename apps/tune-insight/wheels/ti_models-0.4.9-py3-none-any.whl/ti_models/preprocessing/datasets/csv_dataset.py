from typing import List, Optional
import torch
from torch.utils.data import Dataset
import pandas as pd

TARGET_COL_NAMES = ["label", "target", "output"]


class CSVDataset(Dataset):
    """A dataset class for loading CSV files or DataFrames into a PyTorch Dataset.

    Args:
        path_or_buffer (Optional[str]): Path to the CSV file or a buffer. Ignored if 'df' is provided.
        df (Optional[pd.DataFrame]): A pandas DataFrame to use directly. If provided, 'path_or_buffer' is ignored.
        features (Optional[List[str]]): List of feature column names. If None, all columns except targets are used.
        targets (Optional[List[str]]): List of target column names.
            If None, defaults to "label", "target" or "output", or the first column if none of these are present.
        is_classification (bool): Whether the task is classification. Defaults to True.
        dropna (bool): Whether to drop rows with missing values. Defaults to True.
        standardize (bool): Whether to standardize the features. Defaults to False.

    Raises:
        ValueError: If there are unmapped labels in the target column.

    Returns:
        A PyTorch Dataset object that can be used with a DataLoader for training models.
    """

    def __init__(
        self,
        path_or_buffer: Optional[str] = None,
        df: Optional[pd.DataFrame] = None,
        features: Optional[List[str]] = None,
        targets: Optional[List[str]] = None,
        is_classification: bool = True,
        dropna: bool = True,
        standardize: bool = False,
    ):
        self.is_classification = is_classification

        if df is not None:
            df = df.copy()
        elif path_or_buffer is not None:
            df = pd.read_csv(path_or_buffer)
        else:
            raise ValueError("Either 'path_or_buffer' or 'df' must be provided.")

        # Drop any columns that are unnamed (e.g., "Unnamed: 0")
        df = df.loc[:, ~df.columns.str.contains("^Unnamed")]

        if dropna:
            df.dropna(inplace=True)

        possible_targets = targets or TARGET_COL_NAMES
        possible_features = features or []

        features = []
        targets = []
        for col in df.columns:
            if col.lower() in possible_targets:
                targets.append(col)
            else:
                if not possible_features or col in possible_features:
                    features.append(col)

        if not targets:
            targets = features[:1]  # Use the first feature as target if none specified
            features = features[1:]  # Remove it from features

        if self.is_classification:
            self.classes = df[targets[0]].unique().tolist()
            self.classes.sort()
            self.class_to_idx = {
                class_name: i for i, class_name in enumerate(self.classes)
            }

        self.n_inputs = len(features)

        df_features = df[features].copy()
        df_features = pd.get_dummies(df_features, drop_first=True)

        # Convert boolean columns to integers (1/0)
        bool_cols = df_features.select_dtypes(include=["bool"]).columns
        df_features[bool_cols] = df_features[bool_cols].astype(int)

        df_target = df[targets[0]]
        if self.is_classification:
            df_target = df_target.map(self.class_to_idx)
            if df_target.isna().any():
                bad = df.loc[df_target.isna(), targets[0]].unique()
                raise ValueError(f"Unmapped labels in target: {bad}")

        if standardize:
            stds = df_features.std()
            safe_stds = stds.replace(0, 1)  # Avoid division by zero
            df_features = (df_features - df_features.mean()) / safe_stds

        self.X = df_features.to_numpy(dtype="float32")
        if self.is_classification:
            self.y = df_target.to_numpy(dtype="int64")
        else:
            self.y = df_target.to_numpy(dtype="float32")

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx: int):
        x = torch.from_numpy(self.X[idx])
        if self.is_classification:
            y = torch.tensor(self.y[idx], dtype=torch.long)
        else:
            y = torch.tensor(self.y[idx], dtype=torch.float32)

        return x, y
