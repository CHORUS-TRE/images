from typing import List
import torch
from torch.utils.data import Dataset
import numpy as np


class GraphDataset(Dataset):
    """Wrapper for graph adjacency matrices

    Fields:
        - adj_matrix (np.ndarray): the adjacency matrix of the graph
        - owned (List[int]): the owned set of nodes
        - num_nodes (int): the number of nodes in the global graph

    Serialization instructions:
        This class supports 2 serialization formats:
        - npz: stores a dictionary of np.ndarray objects and is used when working on a partitioned federated graph.
            In this case the npz file contains 2 np.ndarray objects: "A" for the adjacency matrix and "sub" for the set of nodes owned by the collaborator.
            * The "A" object is a square matrix(n*n where n is total number of nodes in the full graph) representing the adjacency matrix of the subgraph where the collaborator can see only the weights of the edges connecting to nodes in the owned set.
            * The "sub" object is a numpy object containing a set of node indices owned by the collaborator.
        - npy: stores only the adjacency matrix. This format is used when handling the full graph (for testing purposes for example) and the in this case the npy file contains only one np.ndarray object representing the adjacency matrix.

    the community detection algorithm."""

    def __init__(self, adj_matrix_path: str):
        self.data = np.load(adj_matrix_path, allow_pickle=True)

        # check if the data is stored in npy format or npz format, npy format contains only the adjacency matrix while npz format contains the adjacency matrix and the owned set of nodes.
        extension = adj_matrix_path.split(".")[-1]
        if extension == "npy":
            self.adj_matrix = self.data
            self.owned = None
        else:
            self.adj_matrix = self.data["A"]
            self.owned = self.data["sub"]
        self.num_nodes = self.adj_matrix.shape[0]
        assert (
            self.num_nodes == self.adj_matrix.shape[1]
        ), "Adjacency matrix must be square."

    def __len__(self):
        """Return the number of nodes in the graph"""
        return self.num_nodes

    def __getitem__(self, idx):
        """Return a single node's connections"""
        return torch.Tensor(self.adj_matrix[idx])

    def get_adjacency_matrix(self) -> np.ndarray:
        """Return the full adjacency matrix"""
        return self.adj_matrix

    def get_owned(self) -> List[int]:
        """Returns a list of the owned set of nodes"""
        # Given that the owned set is a numpy object wrapping a set, we need to access the set then convert it to a list.
        return list(self.owned.item())
