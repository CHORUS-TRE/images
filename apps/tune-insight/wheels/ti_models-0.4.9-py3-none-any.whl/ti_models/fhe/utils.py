from torch import nn
from torchvision.ops.stochastic_depth import StochasticDepth
from ti_models.models.layers.activations.chebyshev_poly import ChebyshevPoly
from ti_models.models.layers.activations.polynomial import Polynomial

SUPPORTED_ADAPTIVE_LAYERS = {
    nn.AdaptiveAvgPool1d: nn.AvgPool1d,
    nn.AdaptiveAvgPool2d: nn.AvgPool2d,
    nn.AdaptiveAvgPool3d: nn.AvgPool3d,
    nn.AdaptiveMaxPool1d: nn.MaxPool1d,
    nn.AdaptiveMaxPool2d: nn.MaxPool2d,
    nn.AdaptiveMaxPool3d: nn.MaxPool3d,
}

FHE_FRIENDLY_LAYER_CLASSES = [
    nn.Linear,
    nn.Conv1d,
    nn.Conv2d,
    nn.Conv3d,
    nn.BatchNorm1d,
    nn.BatchNorm2d,
    nn.BatchNorm3d,
    nn.AvgPool1d,
    nn.AvgPool2d,
    nn.AvgPool3d,
    nn.MaxPool1d,
    nn.MaxPool2d,
    nn.MaxPool3d,
    nn.Flatten,
    nn.Dropout,
    ChebyshevPoly,
    Polynomial,
    StochasticDepth,
    nn.modules.linear.Identity,
]

DIM_2_LAYERS = [
    nn.Conv2d,
    nn.AvgPool2d,
    nn.MaxPool2d,
]

FUSABLE_CONV_LAYERS = [
    nn.Conv2d,
    nn.AvgPool2d,
]
