from typing import Tuple
import torch
from torch import nn


def get_upscaled_conv(
    conv: torch.nn.Conv2d, upscaling: Tuple[int], drop: Tuple[int]
) -> nn.Conv2d:
    kernel_size = (
        conv.kernel_size[0] * upscaling[0] - drop[0],
        conv.kernel_size[1] * upscaling[1] - drop[1],
    )

    stride = (conv.stride[0] * upscaling[0], conv.stride[1] * upscaling[1])

    has_bias = conv.bias is not None
    upscaled_conv = torch.nn.Conv2d(
        conv.in_channels,
        conv.out_channels,
        kernel_size,
        stride=stride,
        padding=conv.padding,
        bias=has_bias,
    )

    upsampled_weights = torch.zeros(
        (
            upscaled_conv.out_channels,
            upscaled_conv.in_channels,
            kernel_size[0],
            kernel_size[1],
        )
    )
    upsampled_weights[:, :, :: upscaling[0], :: upscaling[1]] = conv.weight.data

    upscaled_conv.weight.data = upsampled_weights
    if has_bias:
        upscaled_conv.bias.data = conv.bias.data

    return upscaled_conv


def fuse_conv_bn(conv: nn.Conv2d, bn: nn.BatchNorm2d) -> nn.Conv2d:
    if bn.running_mean is None or bn.running_var is None:
        raise ValueError(
            """
            To be fused into a convolution, the batch normalization layer must have computed running mean and a running vars.
            `bn.track_running_stats` can be set to True before training.
            """
        )

    conv_bias = (
        conv.bias.data if conv.bias is not None else torch.zeros((conv.out_channels))
    )

    fused_conv = torch.nn.Conv2d(
        conv.in_channels,
        conv.out_channels,
        kernel_size=conv.kernel_size,
        stride=conv.stride,
        padding=conv.padding,
        dilation=conv.dilation,
        bias=True,
    )

    scale = bn.weight.data / torch.sqrt(bn.running_var + bn.eps)

    fused_conv.weight.data = conv.weight.data * scale.view(-1, 1, 1, 1)
    fused_conv.bias.data = bn.bias + (conv_bias - bn.running_mean) * scale

    return fused_conv


def fuse_strided_convs(
    conv1: nn.Conv2d, conv2: nn.Conv2d, input_size: Tuple[int]
) -> nn.Conv2d:
    """Fuse two successive 2D convolutions into one, with arbitrary strides.
    If conv3 represents the fusion of conv1 and conv2, y = conv3(x) = conv2(conv1(x)).

    Args:
        conv1 (nn.Conv2d): First convolution
        conv2 (nn.Conv2d): Second convolution
        input_size (Tuple[int]): Expected input size of the first convolution

    Raises:
        ValueError: If the number of output channels of the first convolution is not
            equal to the number of input channels of the second convolution.
        ValueError: If the padding of one convolution is greater than 0.

    Returns:
        nn.Conv2d: The fused convolution, mathematically equivalent to conv2 ∘ conv1
    """
    if conv1.out_channels != conv2.in_channels:
        raise ValueError("First conv output size must match 2nd conv input size")

    if conv1.padding != (0, 0) or conv2.padding != (0, 0):
        raise ValueError("Both convolutions must have 0 padding to be fused")

    in_channels = conv1.in_channels
    middle_channels = conv1.out_channels

    kernel_size_1 = conv1.kernel_size

    conv1bis = torch.nn.Conv2d(
        in_channels, middle_channels, kernel_size_1, bias=True, stride=1
    )
    conv1bis.weight.data = conv1.weight.data
    conv1bis.bias.data = conv1.bias.data

    upscaling = (conv1.stride[0], conv1.stride[1])

    # If the input size does not permit to apply the kernel more than once,
    # upscaling is not needed
    if (
        input_size[-2]
        + 2 * conv1.padding[0]
        - conv1.dilation[0] * (kernel_size_1[0] - 1)
        - 1 // conv1.stride[0]
        <= 1
    ):
        upscaling = (1, upscaling[1])

    if (
        input_size[-1]
        + 2 * conv1.padding[1]
        - conv1.dilation[1] * (kernel_size_1[1] - 1)
        - 1 // conv1.stride[1]
        <= 1
    ):
        upscaling = (upscaling[0], 1)

    kernel_drop_0 = (
        input_size[-2] + 2 * conv1.padding[0] - (conv1.kernel_size[0] - 1)
    ) % upscaling[0]
    kernel_drop_1 = (
        input_size[-1] + 2 * conv1.padding[1] - (conv1.kernel_size[1] - 1)
    ) % upscaling[1]
    drop = (kernel_drop_0, kernel_drop_1)

    conv2bis = get_upscaled_conv(conv2, upscaling=upscaling, drop=drop)

    fused_conv = fuse_convs(conv1bis, conv2bis)

    return fused_conv


def fuse_convs(conv1: nn.Conv2d, conv2: nn.Conv2d) -> nn.Conv2d:
    """
    Fuse two successive 2D convolutions into one, under the condition
    that the first convolution has a stride equal to 1. If conv3 represents
    the fusion of conv1 and conv2, y = conv3(x) = conv2(conv1(x)).
    Source: https://towardsdatascience.com/how-the-pytorch-convolutions-work-or-how-to-collapse-two-convolutions-into-one-6dc810489d79

    Args:
        conv1 (nn.Conv2d): First convolution
        conv2 (nn.Conv2d): Second convolution

    Raises:
        ValueError: If the number of output channels of the first convolution is not
            equal to the number of input channels of the second convolution.
        ValueError: If the stride of the first convolution is not equal to 1.
        ValueError: If the padding of any convolution is greater than 0.

    Returns:
        nn.Conv2d: The fused convolution, mathematically equivalent to conv2 ∘ conv1
    """
    if conv1.out_channels != conv2.in_channels:
        raise ValueError("First conv output size must match 2nd conv input size")

    if conv1.stride != (1, 1):
        raise ValueError("First convolution must have stride == 1 to be fused")

    if conv1.padding != (0, 0) or conv2.padding != (0, 0):
        raise ValueError("Both convolutions must have 0 padding to be fused")

    in_channels = conv1.in_channels
    middle_channels = conv1.out_channels
    out_channels = conv2.out_channels

    kernel_size_1 = conv1.kernel_size
    kernel_size_2 = conv2.kernel_size
    kernel_size_merged = (
        kernel_size_1[0] + kernel_size_2[0] - 1,
        kernel_size_1[1] + kernel_size_2[1] - 1,
    )

    fused_conv = torch.nn.Conv2d(
        in_channels=in_channels,
        out_channels=out_channels,
        kernel_size=kernel_size_merged,
        stride=conv2.stride,
    )
    kernel_padding = [kernel_size_2[0] - 1, kernel_size_2[1] - 1]
    fused_conv.weight.data = torch.conv2d(
        conv1.weight.data.permute(1, 0, 2, 3),
        conv2.weight.data.flip(-1, -2),
        padding=kernel_padding,
    ).permute(1, 0, 2, 3)

    add_x = (
        torch.ones(1, middle_channels, *kernel_size_2)
        * conv1.bias.data[None, :, None, None]
    )

    fused_conv.bias.data = conv2(add_x).flatten()

    return fused_conv


def pool_to_conv(pool_layer: nn.AvgPool2d, n_channels: int) -> nn.Conv2d:
    """Converts a 2D average pooling layer to a mathematically equivalent 2D conv

    Args:
        pool_layer (nn.AvgPool2d): The 2D average pooling layer to convert
        n_channels (int): The number of input channels of the equivalent convolution

    Returns:
        nn.Conv2d: The mathematically equivalent 2D convolution layer
    """
    conv_layer = torch.nn.Conv2d(
        n_channels,
        n_channels,
        pool_layer.kernel_size,
        pool_layer.stride,
        pool_layer.padding,
    )
    w_shape = conv_layer.weight.data.shape
    b_shape = conv_layer.bias.data.shape

    conv_layer.weight.data = torch.zeros(w_shape)
    conv_layer.bias.data = torch.zeros(b_shape)

    for i in range(w_shape[1]):
        conv_layer.weight.data[i, i, :, :] = 1.0 / (w_shape[2] * w_shape[3])

    return conv_layer
