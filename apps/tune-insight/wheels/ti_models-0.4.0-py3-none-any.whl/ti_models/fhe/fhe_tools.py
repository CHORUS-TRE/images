from typing import Optional, List, Tuple
from os import path
from tqdm import tqdm
import torch
from torchmetrics import MeanMetric, Accuracy, F1Score, AUROC
from torch import nn, Tensor
from torch.utils.data import DataLoader
from torch.nn import functional as F
from ti_models.models.layers.activations.chebyshev_poly import ChebyshevPoly
from ti_models.models.layers.activations.relu_composite_poly import ReluCompositePoly
from ti_models.models.layers.activations.polynomial import (
    SUPPORTED_ACTIVATIONS,
    PolyBasis,
)
from ti_models.models.layers.layer_params import InputStats
from ti_models.fhe.utils import (
    FHE_FRIENDLY_LAYER_CLASSES,
    SUPPORTED_ADAPTIVE_LAYERS,
    DIM_2_LAYERS,
    FUSABLE_CONV_LAYERS,
)
from ti_models.utils.utils import get_device
from ti_models.models.classifiers.classifier import TIClassifier
from ti_models.fhe.conv_tools import fuse_conv_bn, pool_to_conv, fuse_strided_convs


class FHETools:
    """
    FHETools is a toolbox containing methods to adapt a PyTorch model before the conversion
    into a secure version capable of doing encrypted inferences.
    """

    def __init__(
        self,
        model: TIClassifier,
        stat_loader: DataLoader,
        test_loader: Optional[DataLoader] = None,
        loss_criteria=nn.CrossEntropyLoss(),
        merge_activations: bool = False,
    ) -> None:
        """Create a FHETools object.

        Args:
            model (TIClassifier): The TI Classifier model to be adapted
            stat_loader (DataLoader): A dataloader used to derivate the bounds of the approximation functions.
            test_loader (Optional[DataLoader]): An optional dataloader used to evaluate the model.
            loss_criteria (_type_, optional): Optional loss criteria used to evaluate the model. Defaults to nn.CrossEntropyLoss().
            merge_activations (bool, optional): if true, merge each pair of successive activations functions
                into single polynomial approximations. Defaults to False.
        """
        self.model = model
        self.stat_loader = stat_loader
        self.test_loader = test_loader
        self.loss_criteria = loss_criteria
        self.merge_activations = merge_activations
        self.device = get_device()
        self.layers_input_shapes = None
        self.input_shape = next(iter(stat_loader))[0].shape

    def eval(self):
        """Evaluate the model on the test loader.

        Raises:
            ValueError: If no test loader was given to the FHETools object.
        """
        if self.test_loader is None:
            raise ValueError(
                "Evaluation is not possible: no test loader has been passed to the FHETools object."
            )

        test_loss = MeanMetric()

        test_accuracy = Accuracy(
            num_classes=self.model.n_classes, task="multiclass", top_k=1
        )
        test_f1 = F1Score(
            num_classes=self.model.n_classes,
            average="macro",
            task="multiclass",
            top_k=1,
        )
        test_auc = AUROC(
            num_classes=self.model.n_classes, task="multiclass", average="macro"
        )
        n_samples = 0

        with torch.no_grad():
            for data, target in self.test_loader:
                n_samples += len(target)

                # Get the predicted classes for this batch
                output = self.model.eval_graph.module()(data)
                loss = self.loss_criteria(output, target)

                # Metrics
                test_loss.update(loss.detach())
                test_accuracy.update(output, target)
                test_f1.update(output, target)
                test_auc.update(output, target)

        # Calculate the average loss and total accuracy for this epoch
        final_loss = test_loss.compute().item()
        final_accuracy = None
        final_f1 = None
        final_auc = None
        final_accuracy = test_accuracy.compute().item()
        final_f1 = test_f1.compute().item()
        final_auc = test_auc.compute().item()

        print(
            f"Validation set: Average loss: {final_loss:.6f}, "
            f"Accuracy: {final_accuracy * 100.0:.2f}% ({n_samples} samples), "
            f"F1-score: {final_f1:.6f}, AUROC: {final_auc:.6f}"
        )

    def is_valid(self, verbose: bool = True) -> bool:
        """
        Checks if the model is valid for conversion into a secure version, capable of doing secure inference.

        Returns:
            bool: True if the model is valid for conversion into a secure version.
        """
        log = lambda *a, **kw: None
        if verbose:
            log = print

        layers = self.model.get_flatten_named_children().items()
        unsuitable_layers = []
        for name, layer in layers:
            if not layer.__class__ in FHE_FRIENDLY_LAYER_CLASSES:
                unsuitable_layers.append((name, layer))

        if unsuitable_layers:
            log("WARNING: the following layers are not compatible with FHE:")
            for name, layer in unsuitable_layers:
                layer_class = layer.__class__
                log(f"\ttype: {layer_class}, name: {name}")

            return False
        return True

    def adapt(
        self,
        activation_nodes: int = 64,
        act_range_margin_ratio: float = 0.5,
        verbose: bool = True,
    ):
        """
        Adapts the model into a model compatible for secure inference on encrypted data.

        Args:
            activation_nodes (int, optional): Number of approximation nodes for the polynomial
            approximation of activation function. Defaults to 64.
            act_range_margin_ratio (float, optional): _description_. Defaults to 0.5.
        """
        log = lambda *a, **kw: None
        if verbose:
            log = print

        self.get_input_shapes()

        log("Converting adaptive layers...")
        self.convert_adaptive_layers()

        log("Converting classification layers...")
        self.convert_classification_layer()

        log("Fusing convolution and pooling layers...")
        self.fuse_conv_layers()

        log("Approximating activation layers...")
        self.approximate_activations(
            nodes=activation_nodes, act_range_margin_ratio=act_range_margin_ratio
        )

        log("Updating TI Model from torch model...")
        self.model.update_from_torch()

    def get_input_shapes(self):
        layers = self.model.get_flatten_named_children().items()
        hooks = []

        def get_layer_input_shape(layer, input_, _):
            layer.input_shape = input_[0].shape

        for _, layer in layers:
            layer.input_shape = None
            hooks.append(layer.register_forward_hook(get_layer_input_shape))

        sample_input_shape = list(self.input_shape)
        sample_input_shape[0] = 1  # sample batch size
        dummy_input_tensor = torch.rand(sample_input_shape)

        _ = self.model.eval_graph.module()(dummy_input_tensor)
        self.layers_input_shapes = {}

        for i, (name, layer) in enumerate(layers):
            self.layers_input_shapes[name] = layer.input_shape
            hooks[i].remove()

    def convert_adaptive_layers(self):
        """
        Converts the adaptive layers that take input of variable size into fixed-size input layers
        """

        layers = self.model.get_flatten_named_children().items()
        adaptive_layers = []
        for name, layer in layers:
            if layer.__class__ in SUPPORTED_ADAPTIVE_LAYERS:
                adaptive_layers.append((name, layer))

        layer_mapping = {}

        for name, adaptive_layer in adaptive_layers:
            img_input_shape = size_to_tensor(self.layers_input_shapes[name][2:])
            output_shape = size_to_tensor(adaptive_layer.output_size)

            stride = img_input_shape // output_shape
            kernel_size = img_input_shape - (output_shape - 1) * stride
            padding = 0

            valid_layer_class = SUPPORTED_ADAPTIVE_LAYERS[adaptive_layer.__class__]

            layer_mapping[name] = valid_layer_class(
                kernel_size=tuple(kernel_size.tolist()),
                stride=tuple(stride.tolist()),
                padding=padding,
            )

            new_layer = layer_mapping[name]
            if isinstance(new_layer, (nn.AvgPool1d, nn.AvgPool2d, nn.AvgPool3d)):
                new_layer.count_include_pad = False

        self.model.replace_layers(layer_mapping)

    def convert_classification_layer(self):
        """
        Converts the classification layer to remove flattening layer preceding a linear layer before the output
        by applying the linear operation with a Convolution layer.
        [..., Flatten, Linear, Output] -> [..., Conv2d, Flatten, Output]
        or
        [..., Pooling, Linear, Output] -> [..., Pooling, Conv2d, Flatten, Output]
        """
        flatten_named_children = self.model.get_flatten_named_children()
        layers = list(flatten_named_children.values())
        layer_names = list(flatten_named_children.keys())

        # Check that the conditions for replacement are met
        end_with_linear = layers[-1].__class__ == nn.Linear
        has_dimension_change = (
            layers[-2].__class__ == nn.Flatten and layers[-3].__class__ in DIM_2_LAYERS
        )

        # If the classification layer is not convertible, do nothing
        if not (end_with_linear and has_dimension_change):
            return

        flatten_layer = layers[-2]
        flatten_layer_name = layer_names[-2]

        linear_layer = layers[-1]
        linear_layer_name = layer_names[-1]

        def get_classification_input_channels(flatten_layer, input_, _):
            flatten_layer.input_shape = input_[0].shape

        hook = flatten_layer.register_forward_hook(get_classification_input_channels)

        sample_input_shape = list(self.input_shape)
        sample_input_shape[0] = 1  # sample batch size
        dummy_input_tensor = torch.rand(sample_input_shape)

        _ = self.model(dummy_input_tensor)

        in_channels = flatten_layer.input_shape[1]
        out_channels = linear_layer.out_features
        kernel_size = tuple(flatten_layer.input_shape[2:4])

        # Create the replacing Conv2D classification layer and copy the weights of linear layer
        conv_classifier = nn.Conv2d(
            in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size
        )
        conv_classifier.weight.data = linear_layer.weight.data.view(
            out_channels, in_channels, kernel_size[0], kernel_size[1]
        )
        conv_classifier.bias.data = linear_layer.bias.data

        # Create the output flattening layer to convert channel output to vector
        output_flatten = nn.Flatten()

        hook.remove()

        # Replace [Flatten, Linear] by [Conv2D, Flatten]
        layer_mapping = {
            flatten_layer_name: conv_classifier,
            linear_layer_name: output_flatten,
        }

        self.model.replace_layers(layer_mapping)

    def fuse_conv_layers(self):
        flatten_named_children = self.model.get_flatten_named_children()
        layers = list(flatten_named_children.values())
        layer_names = list(flatten_named_children.keys())

        for i in range(len(layers) - 1):
            layer1 = layers[i]
            layer1_name = layer_names[i]
            layer2 = layers[i + 1]
            layer2_name = layer_names[i + 1]

            layer1_input_size = self.layers_input_shapes[layer1_name]
            layer2_input_size = self.layers_input_shapes[layer2_name]

            # Fuse BatchNorm2D to Conv2d
            if layer1.__class__ == nn.Conv2d and layer2.__class__ == nn.BatchNorm2d:
                fused_conv = fuse_conv_bn(layer1, layer2)

                layer_mapping = {
                    layer1_name: nn.Identity(),
                    layer2_name: fused_conv,
                }

                self.model.replace_layers(layer_mapping)
                layers[i] = layer_mapping[layer1_name]
                layers[i + 1] = layer_mapping[layer2_name]

            # Fuse Conv2d or AvgPool to Conv2D or AvgPool
            if (
                layer1.__class__ in FUSABLE_CONV_LAYERS
                and layer2.__class__ in FUSABLE_CONV_LAYERS
            ):
                n_channels_1 = layer1_input_size[1]
                n_channels_2 = layer2_input_size[1]
                if layer1.__class__ == nn.AvgPool2d:
                    # If the dimensions are not compatible, the layers are not Sequential
                    # although the modules are following each other
                    if n_channels_1 != n_channels_2:
                        continue

                    layer1 = pool_to_conv(layer1, n_channels_1)

                if layer2.__class__ == nn.AvgPool2d:
                    # If the dimensions are not compatible, the layers are not Sequential
                    # although the modules are following each other
                    if layer1.out_channels != n_channels_2:
                        continue

                    layer2 = pool_to_conv(layer1, n_channels_2)

                # If the dimensions are not compatible, the layers are not Sequential
                # although the modules are following each other
                if layer1.out_channels != layer2.in_channels:
                    continue

                # Convolution fusing does not work with padding > 0
                if layer1.padding != (0, 0) or layer2.padding != (0, 0):
                    continue

                fused_conv = fuse_strided_convs(
                    layer1, layer2, input_size=layer1_input_size
                )

                layer_mapping = {
                    layer1_name: nn.Identity(),
                    layer2_name: fused_conv,
                }

                self.model.replace_layers(layer_mapping)
                layers[i] = layer_mapping[layer1_name]
                layers[i + 1] = layer_mapping[layer2_name]

    def approximate_activations(
        self, nodes: int = 64, act_range_margin_ratio: float = 0.5
    ):
        """Converts the activation function into polynomial, needed for secure inference.

        Args:
            nodes (int, optional): Number of polynomial approximation nodes. Defaults to 64.
            act_range_margin_ratio (float, optional): The relative size of the margin to add
            to the input range of the activation function. Defaults to 0.5.
        """
        activations: List[Tuple[str, nn.Module]] = []
        activations_indices: List[int] = []
        for i, (name, layer) in enumerate(
            self.model.get_flatten_named_children().items()
        ):
            if layer.__class__ in SUPPORTED_ACTIVATIONS:
                activations.append((name, layer))
                activations_indices.append(i)

        hooks = []

        compute_stats = False
        for act_name, _ in activations:
            if self.model.layers[act_name].privacy_params.input_stats.n == 0:
                compute_stats = True
                break

        if compute_stats:

            def get_activations_ranges(activation, input_, _):
                activation.stats.accumulate_batch(input_[0])

            for _, act in activations:
                act.inplace = False
                act.stats = InputStats()
                hooks.append(act.register_forward_hook(get_activations_ranges))

            # Pass data through model
            with torch.no_grad():
                for data, _ in tqdm(
                    self.stat_loader, desc="Collecting activation stats..."
                ):
                    data = data.to(self.device)
                    self.model.eval_graph.module()(data)

        layer_mapping = {}

        for i, (name, act) in enumerate(activations):
            if self.merge_activations:
                # if the activation is preceded by another activation, it has already been merged
                if activations_indices[i] - 1 in activations_indices:
                    continue

            if compute_stats:
                self.model.layers[name].privacy_params.input_stats = act.stats

            A, B = self.model.layers[name].privacy_params.input_stats.get_safe_bounds(
                act_range_margin_ratio
            )

            func = SUPPORTED_ACTIVATIONS[act.__class__]

            if self.merge_activations:
                # if the activation is immediately followed by another activation
                if activations_indices[i] + 1 in activations_indices:
                    next_name, next_act = activations[i + 1]

                    # create a merged function to replace the first one's function
                    def merged_func(x):
                        # pylint: disable=cell-var-from-loop
                        x1 = SUPPORTED_ACTIVATIONS[act.__class__](x)
                        # pylint: disable=cell-var-from-loop
                        x2 = SUPPORTED_ACTIVATIONS[next_act.__class__](x1)
                        return x2

                    func = merged_func

                    # cancel the 2nd one with identity
                    layer_mapping[next_name] = nn.Identity()

            layer_mapping[name] = (
                ReluCompositePoly(
                    basis=PolyBasis.CHEBYSHEV,
                    A=A,
                    B=B,
                    alpha=7,
                    prec_level=4,
                    debug=False,
                )
                if func is F.relu
                else ChebyshevPoly(A, B, nodes=nodes, func=func, debug=True)
            )

            if compute_stats:
                hooks[i].remove()

        self.model.replace_layers(layer_mapping)

    def export_to_file(self, dst_path: str = "./", model_name: Optional[str] = None):
        """Exports the model to TIM format and save it to the disk.

        Args:
            dst_path (str, optional): Destination path to save the model. Defaults to "./".
            model_name (Optional[str], optional): Name to give to the model during the conversion. Defaults to None.
        """
        marshalled_model = self.model.marshal_binary(fl_only=False)

        filepath = path.join(dst_path, f"{self.model.name}.tim")

        with open(filepath, "wb") as f:
            f.write(marshalled_model)

        print(f"{model_name}.tim successfully exported to {path.abspath(dst_path)}.")


def size_to_tensor(size):
    if isinstance(size, torch.Size):
        return size_to_tensor(tuple(size))
    if isinstance(size, int):
        return Tensor([size]).int()
    if isinstance(size, tuple):
        return Tensor(size).int()

    raise ValueError(
        f"{type(size)} not supported as a size, use int, tuple or torch.Size"
    )
