from typing import Optional
from enum import IntEnum
from io import BytesIO
import torch
from ti_models.models.ti_model import TIModel
from ti_models.utils.utils import BYTE_ORDER, marshal_float, unmarshal_float


class OptimizerType(IntEnum):
    SECURE_SGD = 0


class TIOptimizer:
    """
    Base class for secure TI optimizer that wrap a PyTorch optimizer.

    Attributes:
        optimizer_type (OptimizerType): The type of the optimizer.
        lr (float): The learning rate for the optimizer.
        momentum (Optional[float]): The momentum factor for the optimizer (if applicable).
    """

    def __init__(
        self, optimizer_type: OptimizerType, lr: float, momentum: Optional[float] = None
    ):
        self.optimizer_type = optimizer_type
        self.lr = lr
        self.momentum = momentum
        self._optimizer = None  # Will be initialized in setup with a TIModel

    def setup(self, ti_model: TIModel):
        """
        Setup the optimizer for training.
        """
        if self.optimizer_type == OptimizerType.SECURE_SGD:
            self._optimizer = torch.optim.SGD(
                ti_model.train_graph.module().parameters(),
                lr=self.lr,
                momentum=self.momentum or 0.0,
            )
        else:
            raise ValueError(f"Unsupported optimizer type: {self.optimizer_type}")

    def __str__(self) -> str:
        return (
            f"TIOptimizer(type={self.optimizer_type.value}({self.optimizer_type.name}),"
            f"lr={self.lr},"
            f"momentum={self.momentum})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, TIOptimizer):
            return False

        return (
            self.optimizer_type == other.optimizer_type
            and self.lr == other.lr
            and self.momentum == other.momentum
        )

    def __hash__(self):
        return hash((self.optimizer_type, self.lr, self.momentum))

    def step(self):
        if self._optimizer is None:
            raise ValueError("Optimizer has not been set up. Call setup() first.")
        self._optimizer.step()

    def zero_grad(self):
        if self._optimizer is None:
            raise ValueError("Optimizer has not been set up. Call setup() first.")
        self._optimizer.zero_grad()

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Serialize the TIOptimizer to a binary format.

        Args:
            byteorder (str): The byte order to use for marshaling. Defaults to BYTE_ORDER

        Returns:
            bytes: The serialized binary representation of the TIOptimizer.
        """

        buffer = BytesIO()

        buffer.write(int(self.optimizer_type).to_bytes(1, byteorder, signed=False))

        marshal_float(buffer, self.lr, byteorder=byteorder)

        marshal_float(buffer, self.momentum, byteorder=byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, data: bytes, byteorder: str = BYTE_ORDER
    ) -> "TIOptimizer":
        """
        Deserialize a binary representation of a TIOptimizer.

        Args:
            data (bytes): The binary data to deserialize.
            params: The parameters to be optimized by the optimizer.
            byteorder (str, optional): The byte order used in the binary data. Defaults to BYTE_ORDER.

        Returns:
            TIOptimizer: The deserialized TIOptimizer instance.
        """
        f = BytesIO(data)

        # Read optimizer type
        optimizer_type = OptimizerType(
            int.from_bytes(f.read(1), byteorder, signed=False)
        )

        # Read learning rate
        lr = unmarshal_float(f, byteorder=byteorder)

        # Read momentum
        momentum = unmarshal_float(f, byteorder=byteorder)

        return cls(optimizer_type=optimizer_type, lr=lr, momentum=momentum)
