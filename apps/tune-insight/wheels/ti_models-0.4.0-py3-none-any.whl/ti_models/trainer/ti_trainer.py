from io import BytesIO
import logging
from typing import Optional
import torch
from torch.utils.data import Dataset, DataLoader, sampler as data_sampler
from torch.optim.lr_scheduler import _LRScheduler
from torch.nn.utils import clip_grad_norm_
from packaging.version import Version
from ti_models.models.ti_model import TIModel
from ti_models.trainer.ti_history import HistoryPointType, TIHistory
from ti_models.trainer.ti_loss import LossType, TILoss
from ti_models.utils.utils import (
    SerializableMixin,
    PrettyPrinter,
    get_logger,
    BYTE_ORDER,
    marshal_float,
    unmarshal_float,
    append_marshaled_block,
    unmarshal_size,
    marshal_string_data,
    unmarshal_string,
    marshal_bool,
    unmarshal_bool,
)
from ti_models.preprocessing.preprocessing import Preprocessing
from ti_models.trainer.ti_metrics import Metrics, get_printable_metric_results
from ti_models.trainer.ti_optimizer import TIOptimizer


class TITrainer(SerializableMixin):
    """
    Trainer class for TI models, responsible for training TI models.

    Attributes:
        version (Version): The version of the binary serialization format of the TITrainer.
        model (TIModel): The TI model to train.
        loss (TILoss): The loss function to use during training.
        optimizer (TIOptimizer): The optimizer to use for training.
        batch_size (int): The batch size for training and inference.
        num_workers (int): The number of worker processes for data loading.
        balance_classes (bool): Whether to balance classes during training.
        shuffle (bool): Whether to shuffle the training data at each epoch.
        drop_last_batch (bool): Whether to drop the last batch during training.
            Needed to ensure data privacy DP is applied in secure FL.
        gradient_clipping (Optional[float]): Gradient clipping value to use during training.
        train_preprocessing (Optional[Preprocessing]): Preprocessing steps to apply to training data.
        eval_preprocessing (Optional[Preprocessing]): Preprocessing steps to apply to evaluation data.
        logger (logging.Logger): Logger for logging training and evaluation progress.
        metrics (Optional[Metrics]): Metrics to evaluate the model.
        history (TIHistory): Training and evaluation history.
    """

    # Version of the binary serialization format of the TITrainer
    version = Version("1.0.0")

    def __init__(
        self,
        model: TIModel,
        loss: TILoss,
        optimizer: TIOptimizer,
        batch_size: int,
        num_workers: int = 0,
        balance_classes: bool = False,
        shuffle: bool = True,
        drop_last_batch: bool = True,
        gradient_clipping: Optional[float] = None,
        train_preprocessing: Optional[Preprocessing] = None,
        eval_preprocessing: Optional[Preprocessing] = None,
        logger: logging.Logger = None,
    ):
        """
        Initialize the TITrainer.

        Args:
            model (TIModel): The TI model to train.
            loss (TILoss): The loss function to use during training.
            optimizer (TIOptimizer): The optimizer to use for training.
            batch_size (int): The batch size for training.
            num_workers (int, optional): The number of worker processes for data loading. Defaults to 0.
            balance_classes (bool, optional): Whether to balance classes during training. Defaults to False.
            shuffle (bool, optional): Whether to shuffle the training data at each epoch. Defaults to True.
            drop_last_batch (bool, optional): Whether to drop the last batch during training. Defaults to True.
            gradient_clipping (Optional[float], optional): Gradient clipping value to use during training. Defaults to None.
            train_preprocessing (Optional[Preprocessing], optional): Preprocessing steps to apply to training data. Defaults to None.
            eval_preprocessing (Optional[Preprocessing], optional): Preprocessing steps to apply to evaluation data. Defaults to None.
            logger (logging.Logger, optional): Logger for logging training progress. Defaults to None.
        """

        self.version = TITrainer.version
        self.model = model
        self.loss = loss
        self.optimizer = optimizer
        self.optimizer.setup(model)
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.balance_classes = balance_classes
        self.shuffle = shuffle
        self.drop_last_batch = drop_last_batch
        self.gradient_clipping = gradient_clipping
        self.train_preprocessing = train_preprocessing or model.preprocessing
        self.eval_preprocessing = (
            eval_preprocessing or model.preprocessing or train_preprocessing
        )
        self.logger = logger or get_logger()
        self.setup_metrics(n_classes=model.n_classes)
        self.history = TIHistory()

    def __str__(self) -> str:
        class_name = self.__class__.__name__
        fields = [
            f"version={self.version}",
            f"model={self.model}",
            f"loss={self.loss}",
            f"optimizer={self.optimizer}",
            f"batch_size={self.batch_size}",
            f"num_workers={self.num_workers}",
            f"balance_classes={self.balance_classes}",
            f"shuffle={self.shuffle}",
            f"drop_last_batch={self.drop_last_batch}",
            f"gradient_clipping={self.gradient_clipping}",
            f"train_preprocessing={self.train_preprocessing}",
            f"eval_preprocessing={self.eval_preprocessing}",
            f"history={self.history}",
        ]

        fields_str = ",\n".join(f"{field}" for field in fields)
        return f"{class_name}(\n{PrettyPrinter.indent(fields_str)}\n)"

    def __eq__(self, other: object) -> bool:
        """
        Check if this TITrainer instance is equal to another TITrainer instance.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the TITrainer instances are equal, False otherwise.
        """
        if not isinstance(other, TITrainer):
            return False

        return (
            self.model == other.model
            and self.loss == other.loss
            and self.optimizer == other.optimizer
            and self.batch_size == other.batch_size
            and self.num_workers == other.num_workers
            and self.balance_classes == other.balance_classes
            and self.shuffle == other.shuffle
            and self.drop_last_batch == other.drop_last_batch
            and self.gradient_clipping == other.gradient_clipping
            and self.train_preprocessing == other.train_preprocessing
            and self.eval_preprocessing == other.eval_preprocessing
        )

    def __hash__(self):
        return hash(
            (
                self.model,
                self.loss,
                self.optimizer,
                self.batch_size,
                self.num_workers,
                self.balance_classes,
                self.shuffle,
                self.drop_last_batch,
                self.gradient_clipping,
                self.train_preprocessing,
                self.eval_preprocessing,
            )
        )

    def setup_metrics(self, n_classes: Optional[int] = None):
        """Setup the metrics for the model."""

        if self.loss.loss_type == LossType.MULTICLASS and n_classes is None:
            raise ValueError(
                "n_classes must be provided for multiclass loss functions."
            )

        if (
            self.loss.loss_type == LossType.BINARY
            and n_classes is not None
            and n_classes != 2
        ):
            raise ValueError(
                "n_classes must be None for binary loss functions or equal to 2."
            )

        if self.loss.loss_type == LossType.REGRESSION and n_classes is not None:
            raise ValueError(
                "n_classes cannot be provided for regression loss functions."
            )

        self.metrics = Metrics(
            n_classes=n_classes,
            loss_type=self.loss.loss_type,
        )

    def train(
        self,
        train_dataset: Dataset,
        epochs: int = 1,
        scheduler: Optional[_LRScheduler] = None,
        logging_frequency: Optional[int] = 1,
    ) -> None:
        """Train the TIModel.

        Args:
            train_dataset (Dataset): Dataset for training.
            epochs (int, optional): Number of training epochs. Defaults to 1.
            scheduler (Optional[_LRScheduler], optional): Learning rate scheduler. Defaults to None.
            logging_frequency (int, optional): Frequency of logging training progress. If None or 0, logging is disabled. Defaults to 1.

        Raises:
            ValueError: If no torch model has been set.

        Returns:
            Dict[str, float]: Dictionary containing training metrics.
        """
        if self.model.train_graph is None:
            raise ValueError("No training graph has been set from a torch model")

        self.logger.info("Preparing data loader...")
        train_loader = self.get_loader(train_dataset)

        self.logger.info("Starting training for %d epochs...", epochs)
        for epoch in range(epochs):
            self.metrics.reset()
            n_samples = 0

            for batch_idx, (data, target) in enumerate(train_loader):
                data, target = data.to(self.model.device), target.to(self.model.device)
                n_samples += len(target)

                # Reset optimizer
                self.optimizer.zero_grad()

                # Get the model output for this batch
                output = self.model.train_graph.module()(data)
                if self.loss.loss_type == LossType.BINARY:
                    output = output.view(-1)
                    target = target.float()
                loss_val = self.loss(output, target)
                loss_val.backward()

                if self.gradient_clipping is not None and self.gradient_clipping != 0:
                    for (
                        layer_name,
                        parameters,
                    ) in self.model.train_graph.module().named_parameters():
                        privacy_params = self.model.layers[layer_name].privacy_params
                        if privacy_params is not None:
                            c_factor = privacy_params.clipping_factor
                            clip_grad_norm_(
                                parameters, c_factor * self.gradient_clipping
                            )
                        else:
                            clip_grad_norm_(parameters, self.gradient_clipping)
                self.optimizer.step()

                self.metrics.update(loss_val, output, target)

                # Print metrics to see some progress
                if (
                    logging_frequency is not None
                    and logging_frequency > 0
                    and batch_idx % logging_frequency == 0
                ):
                    self.logger.info(
                        "Training batch %d Loss: %.6f", batch_idx + 1, loss_val.item()
                    )

            if scheduler is not None:
                scheduler.step()

            # Calculate the average loss and other metrics for this epoch
            metric_results = self.metrics.get_results()
            metrics_str = get_printable_metric_results(metric_results, n_samples)

            self.logger.info("Training epoch %d/%d: %s", epoch + 1, epochs, metrics_str)

            self.model.metadata.dataset_size = n_samples

            self.history.add_history_point(
                point_type=HistoryPointType.TRAINING,
                results=metric_results,
            )

        self.model.sync_eval_graph()

    def eval(
        self,
        test_dataset: Dataset,
    ) -> None:
        """Evaluate the PyTorch model.
        Args:
            test_dataset (Dataset): Dataset for evaluation.

        Raises:
            ValueError: If no torch model has been set.

        Returns:
            Dict[str, float]: Dictionary containing evaluation metrics.
        """

        if self.model.eval_graph is None:
            raise ValueError("No evaluation graph has been set from a torch model")

        self.logger.info("Preparing data loader for evaluation...")
        test_loader = self.get_loader(test_dataset, eval_mode=True)

        self.logger.info("Starting evaluation...")

        self.metrics.reset()
        n_samples = 0

        with torch.no_grad():
            for data, target in test_loader:
                data, target = data.to(self.model.device), target.to(self.model.device)
                n_samples += len(target)

                # Get the model output for this batch
                output = self.model.eval_graph.module()(data)
                if self.loss.loss_type == LossType.BINARY:
                    output = output.view(-1)
                    target = target.float()
                loss_val = self.loss(output, target)

                if self.metrics is not None:
                    self.metrics.update(loss_val, output, target)

        # Compute the metrics for this epoch
        metrics_results = self.metrics.get_results()
        metrics_str = get_printable_metric_results(metrics_results, n_samples)

        self.logger.info("Evaluation: %s", metrics_str)

        self.history.add_history_point(
            point_type=HistoryPointType.EVALUATION,
            results=metrics_results,
        )

    def get_loader(self, dataset: Dataset, eval_mode: bool = False) -> DataLoader:
        """Get a DataLoader for the given dataset.

        Args:
            dataset (Dataset): The dataset to load data from.
            eval_mode (bool, optional): Whether to get the loader for evaluation. Defaults to False.

        Returns:
            DataLoader: The DataLoader for the given dataset.
        """

        shuffle = self.shuffle

        # Equivalent to isinstance(dataset, IterableDataset)
        if "IterableDataset" in [base.__name__ for base in type(dataset).__mro__]:
            if self.balance_classes:
                raise ValueError("S3IterableDataset does not support class balancing.")

            # IterableDataset is shuffled by defaut, use this to unshuffle only
            shuffle = False if not self.shuffle else None

        if shuffle is False and self.balance_classes:
            raise ValueError("Cannot balance classes without shuffling.")

        sampler = None
        if self.balance_classes:
            if self.model.n_classes is None or self.model.n_classes < 2:
                raise ValueError(
                    f"Class balancing is only supported for classification tasks. n_classes is invalid ({self.model.n_classes})"
                )
            n_classes = self.model.n_classes
            shuffle = None
            weights = self.get_sample_weights(dataset, n_classes)
            sampler = data_sampler.WeightedRandomSampler(weights, len(weights))

        drop_last = self.drop_last_batch
        if eval_mode:
            shuffle = False
            sampler = None
            drop_last = False

        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=shuffle,
            sampler=sampler,
            num_workers=self.num_workers,
            drop_last=drop_last,
        )

    def get_sample_weights(self, dataset, n_classes: int) -> torch.DoubleTensor:
        """Return sample weights to balance classes"""

        # Equivalent to isinstance(dataset, IterableDataset)
        if "IterableDataset" in [base.__name__ for base in type(dataset).__mro__]:
            raise ValueError("Cannot generate balanced weights with IterableDataset")

        self.logger.info("Browsing the dataset to balance classes...")
        class_count = [0] * n_classes

        for sample in dataset:
            target = sample[1]
            class_count[target] += 1

        class_weights = [0.0] * n_classes
        n_samples = len(dataset)

        for i in range(n_classes):
            class_weights[i] = n_samples / float(class_count[i])

        weights = [0] * n_samples
        for idx, val in enumerate(dataset):
            weights[idx] = class_weights[val[1]]

        return torch.DoubleTensor(weights)

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Serializes the trainer into binary format for the backend.

        Marshalling order:
            1. version
            2. model
            3. loss
            4. optimizer
            5. batch_size
            6. num_workers
            7. balance_classes
            8. shuffle
            9. drop_last_batch
            10. gradient_clipping
            11. train_preprocessing
            12. eval_preprocessing

        Args:
            byteorder (str): The byte order to use for serialization. Defaults to BYTE_ORDER.

        Returns:
            bytes: A binary representation of the TITrainer.
        """
        buffer = BytesIO()

        marshal_string_data(buffer, str(self.version), byteorder)

        model_data = self.model.marshal_binary(
            fl_only=False, include_arch=True, include_circuit=False, byteorder=byteorder
        )
        append_marshaled_block(buffer, model_data, byteorder)

        loss_data = self.loss.marshal_binary(byteorder)
        append_marshaled_block(buffer, loss_data, byteorder)

        optimizer_data = self.optimizer.marshal_binary(byteorder)
        append_marshaled_block(buffer, optimizer_data, byteorder)

        buffer.write(self.batch_size.to_bytes(8, byteorder, signed=False))

        buffer.write(self.num_workers.to_bytes(4, byteorder, signed=False))

        for bool_value in [self.balance_classes, self.shuffle, self.drop_last_batch]:
            marshal_bool(buffer, bool_value, byteorder)

        gradient_clipping = self.gradient_clipping or 0.0
        marshal_float(buffer, gradient_clipping, byteorder=byteorder)

        train_preprocessing_data = bytearray()
        if self.train_preprocessing is not None:
            train_preprocessing_data = self.train_preprocessing.marshal_binary(
                byteorder
            )
        append_marshaled_block(buffer, train_preprocessing_data, byteorder)

        eval_preprocessing_data = bytearray()
        if self.eval_preprocessing is not None:
            eval_preprocessing_data = self.eval_preprocessing.marshal_binary(byteorder)
        append_marshaled_block(buffer, eval_preprocessing_data, byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, binary_trainer: bytes, byteorder: str = BYTE_ORDER
    ) -> "TITrainer":
        """
        Deserialize binary data into a TITrainer object.

        Args:
            binary_trainer (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for unmarshaling.

        Returns:
            TITrainer: The deserialized TITrainer object.
        """
        f = BytesIO(binary_trainer)

        version = Version(unmarshal_string(f, byteorder))
        if not cls.is_serialization_compatible(version):
            raise ValueError(
                f"Incompatible trainer version: {version}. Expected version: {cls.version}"
            )

        model_size = unmarshal_size(f, byteorder)
        model_data = f.read(model_size)
        model = TIModel.unmarshal_binary(model_data, byteorder)

        loss_size = unmarshal_size(f, byteorder)
        loss_data = f.read(loss_size)
        loss = TILoss.unmarshal_binary(loss_data, byteorder)

        optimizer_size = unmarshal_size(f, byteorder)
        optimizer_data = f.read(optimizer_size)
        optimizer = TIOptimizer.unmarshal_binary(optimizer_data, byteorder)

        batch_size = int.from_bytes(f.read(8), byteorder, signed=False)

        num_workers = int.from_bytes(f.read(4), byteorder, signed=False)

        balance_classes = unmarshal_bool(f, byteorder)
        shuffle = unmarshal_bool(f, byteorder)
        drop_last_batch = unmarshal_bool(f, byteorder)

        gradient_clipping = unmarshal_float(f, byteorder=byteorder)
        if gradient_clipping == 0.0:
            gradient_clipping = None

        train_preprocessing_size = unmarshal_size(f, byteorder)
        train_preprocessing = None
        if train_preprocessing_size > 0:
            train_preprocessing_data = f.read(train_preprocessing_size)
            train_preprocessing = Preprocessing.unmarshal_binary(
                train_preprocessing_data, byteorder
            )

        eval_preprocessing_size = unmarshal_size(f, byteorder)
        eval_preprocessing = None
        if eval_preprocessing_size > 0:
            eval_preprocessing_data = f.read(eval_preprocessing_size)
            eval_preprocessing = Preprocessing.unmarshal_binary(
                eval_preprocessing_data, byteorder
            )

        return cls(
            model=model,
            loss=loss,
            optimizer=optimizer,
            batch_size=batch_size,
            num_workers=num_workers,
            balance_classes=balance_classes,
            shuffle=shuffle,
            drop_last_batch=drop_last_batch,
            gradient_clipping=gradient_clipping,
            train_preprocessing=train_preprocessing,
            eval_preprocessing=eval_preprocessing,
        )
