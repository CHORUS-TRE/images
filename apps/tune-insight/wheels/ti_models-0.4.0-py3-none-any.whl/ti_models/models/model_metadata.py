from io import BytesIO
from typing import Optional
from ti_models.utils.utils import BYTE_ORDER
from ti_models.utils.utils import marshal_string_data, unmarshal_string


class ModelMetadata:
    """
    Class containing training metadata for TI models.

    Attributes:
        source_path (Optional[str]): Path to the source used for training
        dataset_id (Optional[str]): Identifier of the dataset used for training
        dataset_size (Optional[int]): Size of the dataset used for training
    """

    def __init__(
        self,
        source_path: Optional[str] = None,
        dataset_id: Optional[str] = None,
        dataset_size: Optional[int] = None,
    ):
        """
        Initialize ModelMetadata.
        """
        self.source_path = source_path
        self.dataset_id = dataset_id
        self.dataset_size = dataset_size

    def __eq__(self, other: object) -> bool:
        """
        Check if this ModelMetadata is equal to another ModelMetadata.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the objects are equal, False otherwise.
        """
        if not isinstance(other, ModelMetadata):
            return False
        return (
            self.source_path == other.source_path
            and self.dataset_id == other.dataset_id
            and self.dataset_size == other.dataset_size
        )

    def __hash__(self):
        return hash((self.source_path, self.dataset_id, self.dataset_size))

    def __str__(self) -> str:
        """
        Returns:
            str: A string representation of the ModelMetadata object
        """

        return f"source_path={self.source_path}, dataset_id={self.dataset_id}, dataset_size={self.dataset_size}"

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> None:
        """
        Serializes the ModelMetadata into a binary format.

        Args:
            byteorder (str): The byte order to use for marshaling.
        """

        buffer = BytesIO()

        source_path = self.source_path or ""
        marshal_string_data(buffer, source_path, byteorder)

        dataset_id = self.dataset_id or ""
        marshal_string_data(buffer, dataset_id, byteorder)

        dataset_size = self.dataset_size or 0
        buffer.write(dataset_size.to_bytes(8, byteorder, signed=False))

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, binary_data: bytes, byteorder: str = BYTE_ORDER
    ) -> "ModelMetadata":
        """
        Deserialize binary data into a ModelMetadata object.

        Args:
            binary_data (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for unmarshaling. Defaults to BYTE_ORDER.

        Returns:
            ModelMetadata: The deserialized ModelMetadata object.
        """

        f = BytesIO(binary_data)

        source_path = unmarshal_string(f, byteorder)
        if source_path == "":
            source_path = None

        dataset_id = unmarshal_string(f, byteorder)
        if dataset_id == "":
            dataset_id = None

        dataset_size = int.from_bytes(f.read(8), byteorder, signed=False)
        if dataset_size == 0:
            dataset_size = None

        return cls(
            source_path=source_path,
            dataset_id=dataset_id,
            dataset_size=dataset_size,
        )
