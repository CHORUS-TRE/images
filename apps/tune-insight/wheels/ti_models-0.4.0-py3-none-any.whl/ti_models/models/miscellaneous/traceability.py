from typing import List, Tuple
from os import path
from torch import Tensor
from torch import nn


class TraceableSequential(nn.Module):
    """
    A Sequential model with the ability to write
    intermediate output tensors to the disk for testing purpose.
    """

    def __init__(
        self,
        layers: List[Tuple[str, nn.Module]],
        export_tensors: bool = False,
        export_path: str = "./",
    ) -> None:
        super().__init__()

        self.inner_model = nn.ModuleDict(layers)
        self.export_path = export_path
        self.export_tensors = export_tensors

    def forward(self, x: Tensor) -> Tensor:
        outputs = [x]
        layer_names = ["input"]

        for name, layer in self.inner_model.items():
            outputs.append(layer(outputs[-1]))
            layer_names.append(name)

        if self.export_tensors and not self.training:
            for i, output in enumerate(outputs):
                write_tensor(output, [self.export_path, f"{layer_names[i]}.csv"])

        return outputs[-1]


def write_tensor(tensor: Tensor, path_names: List[str]) -> None:
    """Write a tensor to a CSV file.

    Args:
        tensor (Tensor): The tensor to write to disk
        path_names (List[str]): List of path components that will be joined to form the output path
    """
    flatten = True

    if flatten:
        string_tensor = ""

        flat_tensor = tensor.flatten()

        for val in flat_tensor:
            string_tensor += f"{val:.9f},"

        string_tensor = string_tensor[:-1] + "\n"
    else:
        string_tensor = str(tensor)

    with open(path.join(*path_names), "a+", encoding="utf8") as f:
        f.write(string_tensor)
