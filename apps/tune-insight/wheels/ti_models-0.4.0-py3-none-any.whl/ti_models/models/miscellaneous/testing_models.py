from typing import Tuple, Optional
from collections import OrderedDict
from torch import Tensor, nn
from torchvision import transforms
from ti_models.models.classifiers.classifier import TIClassifier
from ti_models.models.miscellaneous.traceability import TraceableSequential
from ti_models.models.miscellaneous.traceability import write_tensor
from ti_models.preprocessing.preprocessing import Preprocessing, InputType
from ti_models.preprocessing.transform import Transform


class TestModelAdvanced(TIClassifier):
    """A CNN model used for testing Model-as-a-Service (MaaS) functionality.

    Attributes:
        img_size (Tuple[int]): Size of the input image. Defaults to (16, 16).
        out_channels_conv (int): Number of output channels for convolutional layers. Defaults to 5.
        pool_kernel_size (int): Kernel size for average pooling. Defaults to 8.
        num_classes (int): Number of output classes. Defaults to 2.
        export_tensors (bool): Whether to export tensors. Defaults to False.
        export_path (str): Path to export tensors. Defaults to "./".
        layers (OrderedDict[str, TILayer]): OrderedDict of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        torch_model (Optional[nn.Module]): The underlying PyTorch model, used to redefine the forward function. Defaults to None.
    """

    def __init__(
        self,
        img_size: Tuple[int] = (16, 16),
        out_channels_conv: int = 5,
        pool_kernel_size: int = 8,
        num_classes: int = 2,
        export_tensors: bool = False,
        export_path: str = "./",
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        secure_inference_enabled: bool = False,
    ) -> None:

        in_channels_conv = 3

        conv1 = nn.Conv2d(
            in_channels=in_channels_conv,
            out_channels=out_channels_conv,
            kernel_size=3,
            stride=1,
            padding=1,
        )  # 3x16x16 -> 5x16x16

        bn1 = nn.BatchNorm2d(num_features=out_channels_conv)

        activation1 = nn.SiLU()

        conv2 = nn.Conv2d(
            in_channels=out_channels_conv,
            out_channels=out_channels_conv,
            kernel_size=3,
            stride=1,
            padding=1,
        )  # 5x16x16 -> 5x16x16

        bn2 = nn.BatchNorm2d(num_features=out_channels_conv)

        activation2 = nn.SiLU()

        avgPool = nn.AvgPool2d(
            kernel_size=pool_kernel_size,
        )  # 5x16x16 -> 5x2x2

        flatten = nn.Flatten()  # 5x2x2 -> 20

        dense = nn.Linear(
            in_features=img_size[0]
            * img_size[1]
            * out_channels_conv
            // (pool_kernel_size**2),
            out_features=num_classes,
        )

        activation3 = nn.SiLU()

        self.torch_model = nn.Sequential(
            conv1,
            bn1,
            activation1,
            conv2,
            bn2,
            activation2,
            avgPool,
            flatten,
            dense,
            activation3,
        )

        super().__init__(
            name="MaaS_Test_Model",
            n_classes=num_classes,
            torch_model=self.torch_model,
            description="A simple CNN model used for testing Model-as-a-Service (MaaS) functionality.",
            preprocessing=Preprocessing(
                input_type=InputType.IMAGE,
                input_shape=None,
                transforms=[
                    Transform.from_tv_transform(
                        transforms.Resize((img_size[0], img_size[1]))
                    ),
                    Transform.from_tv_transform(transforms.ToTensor()),
                ],
            ),
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )

        self.export_tensors = export_tensors
        self.export_path = export_path

    def enable_export_tensors(self) -> None:
        self.export_tensors = True

    def disable_export_tensors(self) -> None:
        self.export_tensors = False

    def set_export_path(self, path: str) -> None:
        self.export_path = path

    def forward(self, x: Tensor) -> Tensor:
        x1 = self.torch_model[0](x)
        x2 = self.torch_model[1](x1)
        x3 = self.torch_model[2](x2)
        x4 = self.torch_model[3](x3)
        x5 = self.torch_model[4](x4)
        x6 = x3 + x5
        x7 = self.torch_model[5](x6)
        x8 = self.torch_model[6](x7)
        x9 = self.torch_model[7](x8)
        x10 = self.torch_model[8](x9)
        x11 = self.torch_model[9](x10)

        if self.export_tensors and not self.torch_model.training:
            write_tensor(x, [self.export_path, "input.csv"])
            write_tensor(x1, [self.export_path, "conv1.csv"])
            write_tensor(x2, [self.export_path, "bn1.csv"])
            write_tensor(x3, [self.export_path, "silu1.csv"])
            write_tensor(x4, [self.export_path, "conv2.csv"])
            write_tensor(x5, [self.export_path, "bn2.csv"])
            write_tensor(x6, [self.export_path, "add.csv"])
            write_tensor(x7, [self.export_path, "silu2.csv"])
            write_tensor(x8, [self.export_path, "avgPool.csv"])
            write_tensor(x10, [self.export_path, "dense.csv"])
            write_tensor(x11, [self.export_path, "silu3.csv"])

        return x11


class TestModelSimple(TIClassifier):
    """A simple model used for testing Model-as-a-Service (MaaS) functionality.

    Attributes:
        img_size (Tuple[int]): The size of the input image as a tuple (channels, height, width). Defaults to (3, 2).
        num_classes (int): The number of output classes for classification. Defaults to 2.
        traceable (bool): Indicates if the model should export intermediate tensors for tracing. Defaults to False.
        export_path (str): The path where exported tensors will be saved. Defaults to "./".
        layers (OrderedDict[str, TILayer]): OrderedDict of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        torch_model (Optional[nn.Module]): The underlying PyTorch model, used for combining the TestModelSimple as a head for other models. Defaults to None.
    """

    def __init__(
        self,
        img_size: Tuple[int] = (3, 2),
        num_classes: int = 2,
        traceable: bool = False,
        export_path: str = "./",
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        secure_inference_enabled: bool = False,
    ) -> None:
        self.torch_model = TraceableSequential(
            layers=[
                ("flatten", nn.Flatten()),
                (
                    "linear",
                    nn.Linear(3 * img_size[0] * img_size[1], out_features=num_classes),
                ),
            ],
            export_tensors=traceable,
            export_path=export_path,
        )

        super().__init__(
            name="simple_test",
            n_classes=num_classes,
            torch_model=self.torch_model,
            description="A simple model used for testing Model-as-a-Service (MaaS) functionality.",
            preprocessing=Preprocessing(
                input_type=InputType.IMAGE,
                input_shape=None,
                transforms=[
                    Transform.from_tv_transform(
                        transforms.Resize((img_size[0], img_size[1]))
                    ),
                    Transform.from_tv_transform(transforms.ToTensor()),
                ],
            ),
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )

    def enable_export_tensors(self) -> None:
        self.torch_model.export_tensors = True

    def disable_export_tensors(self) -> None:
        self.torch_model.export_tensors = False

    def set_export_path(self, path: str) -> None:
        self.torch_model.export_path = path

    def forward(self, x: Tensor) -> Tensor:
        x1 = self.torch_model[0](x)
        x2 = self.torch_model[1](x1)

        if self.torch_model.export_tensors and not self.torch_model.training:
            write_tensor(x, [self.torch_model.export_path, "input.csv"])
            write_tensor(x1, [self.torch_model.export_path, "flatten.csv"])
            write_tensor(x2, [self.torch_model.export_path, "dense.csv"])

        return x2
