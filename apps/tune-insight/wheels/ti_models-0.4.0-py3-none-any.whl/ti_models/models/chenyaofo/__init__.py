"""
Optimized model for cifar, by Chenyaofo
Source: https://github.com/chenyaofo/pytorch-cifar-models/tree/master
"""
