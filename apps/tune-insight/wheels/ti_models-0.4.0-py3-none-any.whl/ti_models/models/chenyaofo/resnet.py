"""
Modified from https://raw.githubusercontent.com/pytorch/vision/v0.9.1/torchvision/models/resnet.py

BSD 3-Clause License

Copyright (c) Soumith Chintala 2016,
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

* Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""

from typing import Any, List
from torch import nn

try:
    from torch.hub import load_state_dict_from_url
except ImportError:
    from torch.utils.model_zoo import load_url as load_state_dict_from_url

from ti_models.models.miscellaneous.traceability import write_tensor

cifar10_pretrained_weight_urls = {
    "resnet20": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar10_resnet20-4118986f.pt",
    "resnet32": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar10_resnet32-ef93fc4d.pt",
    "resnet44": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar10_resnet44-2a3cabcb.pt",
    "resnet56": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar10_resnet56-187c023a.pt",
}

cifar100_pretrained_weight_urls = {
    "resnet20": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar100_resnet20-23dac2f1.pt",
    "resnet32": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar100_resnet32-84213ce6.pt",
    "resnet44": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar100_resnet44-ffe32858.pt",
    "resnet56": "https://github.com/chenyaofo/pytorch-cifar-models/releases/download/resnet/cifar100_resnet56-f2eff4c8.pt",
}


def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(
        in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False
    )


def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(
        self,
        activation: nn.Module,
        inplanes,
        planes,
        stride=1,
        downsample=None,
        prefix_name: str = 1,
        export_tensors=False,
        export_path="./",
    ):
        super().__init__()

        self.export_tensors = export_tensors
        self.export_path = export_path
        self.prefix_name = prefix_name

        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn1 = nn.BatchNorm2d(planes)
        self.activation1 = activation(inplace=True)
        self.conv2 = conv3x3(planes, planes)
        self.bn2 = nn.BatchNorm2d(planes)
        self.downsample = downsample
        self.activation2 = activation(inplace=True)
        self.stride = stride

    def forward(self, x):
        identity = x

        x1 = self.conv1(x)
        x2 = self.bn1(x1)
        x3 = self.activation1(x2)

        x4 = self.conv2(x3)
        x5 = self.bn2(x4)

        if self.downsample is not None:
            identity = self.downsample(x)

        x6 = x5 + identity

        x7 = self.activation2(x6)

        if self.export_tensors and not self.training:
            write_tensor(x2, [self.export_path, f"{self.prefix_name}.bn1.output_3.csv"])

            write_tensor(
                x3,
                [self.export_path, f"{self.prefix_name}.activation1.output_0.csv"],
            )

            write_tensor(x5, [self.export_path, f"{self.prefix_name}.bn2.output_3.csv"])

            if self.downsample is not None:
                write_tensor(
                    identity,
                    [
                        self.export_path,
                        f"{self.prefix_name}.downsample.1.output_3.csv",
                    ],
                )

            write_tensor(x6, [self.export_path, f"{self.prefix_name}.add.output_0.csv"])

            write_tensor(
                x7,
                [self.export_path, f"{self.prefix_name}.activation2.output_0.csv"],
            )

        return x7


class CifarResNet(nn.Module):
    def __init__(
        self,
        block,
        layers,
        num_classes,
        activation: nn.Module,
        export_tensors: bool = False,
        export_path: str = "./",
    ):
        super().__init__()

        self.export_tensors = export_tensors
        self.export_path = export_path

        self.inplanes = 16
        self.conv1 = conv3x3(3, 16)
        self.bn1 = nn.BatchNorm2d(16)
        self.activation = activation(inplace=True)

        self.layer1 = self._make_layer(
            activation=activation,
            block=block,
            planes=16,
            blocks=layers[0],
            layer_count=1,
        )
        self.layer2 = self._make_layer(
            activation=activation,
            block=block,
            planes=32,
            blocks=layers[1],
            stride=2,
            layer_count=2,
        )
        self.layer3 = self._make_layer(
            activation=activation,
            block=block,
            planes=64,
            blocks=layers[2],
            stride=2,
            layer_count=3,
        )

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.flatten = nn.Flatten()
        self.fc = nn.Linear(64 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def _make_layer(
        self, activation, block, planes, blocks, stride=1, layer_count: int = 0
    ):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                conv1x1(self.inplanes, planes * block.expansion, stride),
                nn.BatchNorm2d(planes * block.expansion),
            )

        inner_count = 0

        layers = []
        layers.append(
            block(
                activation,
                self.inplanes,
                planes,
                stride,
                downsample,
                prefix_name=f"layer{layer_count}.{inner_count}",
                export_tensors=self.export_tensors,
                export_path=self.export_path,
            )
        )
        inner_count += 1
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(
                block(
                    activation,
                    self.inplanes,
                    planes,
                    prefix_name=f"layer{layer_count}.{inner_count}",
                    export_tensors=self.export_tensors,
                    export_path=self.export_path,
                )
            )
            inner_count += 1

        return nn.Sequential(*layers)

    def set_export_tensors_to(self, export_tensors: bool = False):
        self.export_tensors = export_tensors
        for block in self.layer1:
            block.export_tensors = export_tensors
        for block in self.layer2:
            block.export_tensors = export_tensors
        for block in self.layer3:
            block.export_tensors = export_tensors

    def set_export_path_to(self, export_path: str = "./"):
        self.export_path = export_path
        for block in self.layer1:
            block.export_path = export_path
        for block in self.layer2:
            block.export_path = export_path
        for block in self.layer3:
            block.export_path = export_path

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.bn1(x1)
        x3 = self.activation(x2)

        x4 = self.layer1(x3)
        x5 = self.layer2(x4)
        x6 = self.layer3(x5)

        x7 = self.avgpool(x6)
        x8 = self.flatten(x7)
        x9 = self.fc(x8)

        if self.export_tensors and not self.training:
            write_tensor(x, [self.export_path, "input_0.csv"])
            write_tensor(x2, [self.export_path, "bn1.output_3.csv"])
            write_tensor(x3, [self.export_path, "activation.output_0.csv"])
            write_tensor(
                x7,
                [self.export_path, "avgpool.output_0.csv"],
            )
            write_tensor(
                x8,
                [self.export_path, "flatten.output_0.csv"],
            )
            write_tensor(x9, [self.export_path, "fc.output_0.csv"])

        return x9


def create_resnet20(
    arch: str,
    layers: List[int],
    progress: bool = True,
    pretrained: bool = False,
    num_classes: int = 10,
    activation: nn.Module = nn.SiLU,
    **kwargs: Any,
) -> CifarResNet:
    model = CifarResNet(
        block=BasicBlock,
        layers=layers,
        num_classes=num_classes,
        activation=activation,
        **kwargs,
    )

    if pretrained and num_classes not in (10, 100):
        raise ValueError(
            f"No pretrained model available for Chenyaofo Cifar with {num_classes} classes."
        )
    if pretrained:
        model_urls = cifar10_pretrained_weight_urls
        if num_classes == 100:
            model_urls = cifar100_pretrained_weight_urls

        state_dict = load_state_dict_from_url(model_urls[arch], progress=progress)
        model.load_state_dict(state_dict)
    return model
