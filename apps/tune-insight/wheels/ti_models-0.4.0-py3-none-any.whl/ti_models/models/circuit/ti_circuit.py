from io import BytesIO
from typing import Dict, List, Optional
from ti_models.utils.utils import BYTE_ORDER
from ti_models.utils.utils import (
    marshal_string_data,
    unmarshal_size,
    unmarshal_string,
)


class TICircuit:
    """
    Class representing a TI Circuit, which define the order to apply the layers of a model

    Attributes:
        circuit_steps (Optional[List[CircuitStep]]): A sequence of steps that define the
            execution order of the circuit. Defaults to an empty list.
    """

    def __init__(
        self,
        circuit_steps: Optional[List["CircuitStep"]] = None,
    ):
        self.circuit_steps = circuit_steps or []

    def __str__(self) -> str:
        """
        Returns:
            str: A string representation of the TICircuit including
                details of each circuit step.
        """
        steps_details = "\n".join(str(step) for step in self.circuit_steps)
        return f"TICircuit(Steps: [\n{steps_details}\n])"

    def __eq__(self, other: object) -> bool:
        """
        Check if this TICircuit is equal to another TICircuit.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the circuits are equal, False otherwise.
        """
        if not isinstance(other, TICircuit):
            return False

        return self.circuit_steps == other.circuit_steps

    def __hash__(self):
        return hash(self.circuit_steps)

    def add_circuit_step(self, circuit_step: "CircuitStep"):
        self.circuit_steps.append(circuit_step)

    def find_input(self, output_prefix: str, skipped_nodes: Dict[str, str]) -> str:
        """
        Find the output name of the circuitStep that comes immediately before the step whose
        output prefix is specified. A Dict of skipped nodes with inputs as key and outputs as
        values is passed to ignore certain steps and recursively look for inputs until an input
        that is not contained in skipped_nodes is found.

        Args:
            output_prefix (str): The prefix of the output to find the corresponding input for.
            skipped_nodes (Dict[str, str]): A dictionary of skipped nodes with their ONNX names
                as keys and corresponding torch names as values.

        Returns:
            Optional[str]: The name of the input corresponding to the given output prefix,
                or None if no matching input is found.
        """
        found_input = None

        # If the input is found in a skipped node, jumps till we find a non-skipped node
        for input_, output in skipped_nodes.items():
            if output.startswith(output_prefix):
                found_input = self.find_input(input_, {})

                return found_input

        for circuit_step in self.circuit_steps:
            output_name = circuit_step.output
            if output_name.startswith(f"{output_prefix}."):
                found_input = output_name

        return found_input

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Serialize the circuit representation into a binary format.

        Args:
            byteorder (str, optional): The byte order to use for marshaling. Defaults to BYTE_ORDER.

        Returns:
            bytes: The serialized binary representation of the TICircuit.
        """
        buffer = BytesIO()

        # append the number of steps in the circuit
        n_steps: int = len(self.circuit_steps)
        buffer.write(bytearray(n_steps.to_bytes(8, byteorder, signed=False)))

        # append preprocessing transforms
        for circuit_step in self.circuit_steps:
            # Append layer name
            marshal_string_data(buffer, circuit_step.layer, byteorder)

            # append size of inputs
            n_inputs: int = len(circuit_step.inputs)
            buffer.write(n_inputs.to_bytes(8, byteorder, signed=False))

            # append inputs data
            for value in circuit_step.inputs:
                # append input
                marshal_string_data(buffer, value, byteorder)

            # Get output size and output name
            marshal_string_data(buffer, circuit_step.output, byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(cls, data: bytes, byteorder: str = BYTE_ORDER) -> "TICircuit":
        """
        Deserialize binary data into the circuit representation.

        Args:
            data (bytearray): The binary data to unmarshal.
            byteorder (str, optional): The byte order to use for reading integers. Defaults to BYTE_ORDER.

        Returns:
            TICircuit: The deserialized TICircuit object.
        """
        f = BytesIO(data)

        n_steps = int.from_bytes(f.read(8), byteorder, signed=False)

        circuit_steps: List[CircuitStep] = []

        for _ in range(n_steps):
            layer_name = unmarshal_string(f, byteorder)

            inputs = []
            n_inputs = unmarshal_size(f, byteorder)
            for _ in range(n_inputs):
                input_name = unmarshal_string(f, byteorder)
                inputs.append(input_name)

            output_name = unmarshal_string(f, byteorder)

            circuit_steps.append(
                CircuitStep(layer=layer_name, inputs=inputs, output=output_name)
            )

        return cls(circuit_steps=circuit_steps)


class CircuitStep:
    """
    Class representing a step in a machine learning circuit, structuring
    an operation referring to the layers of a model.

    Attributes:
        layer (str): The name of the layer.
        inputs (List[str]): A list of input names for the layer.
        output (str): The name of the output produced by the layer.
    """

    def __init__(self, layer: str, inputs: List[str], output: str):
        self.layer = layer
        self.inputs = inputs
        self.output = output

    def __str__(self) -> str:
        """
        Returns:
            str: A string representation of the CircuitStep including
                the layer name, inputs, and output.
        """
        return f"CircuitStep(layer={self.layer}, inputs={self.inputs}, output={self.output})"

    def __eq__(self, other: object) -> bool:
        """
        Check if this CircuitStep is equal to another CircuitStep.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the CircuitSteps are equal, False otherwise.
        """
        if not isinstance(other, CircuitStep):
            return False

        return (
            self.layer == other.layer
            and self.inputs == other.inputs
            and self.output == other.output
        )

    def __hash__(self):
        return hash((self.layer, tuple(self.inputs), self.output))


def create_steps(
    layer_name: str,
    input_names: List[str],
    output_prefix: Optional[str] = None,
    add_weights: Optional[bool] = False,
    add_bias: Optional[bool] = False,
    add_bn_track_running_stats: Optional[bool] = False,
    add_generic: Optional[bool] = True,
) -> List[CircuitStep]:

    circuit_steps: List[CircuitStep] = []
    step = 0

    output_prefix = output_prefix or "output"

    if add_bn_track_running_stats:
        output_name = f"{output_prefix}_{step}"

        circuit_steps.append(
            CircuitStep(
                layer=f"{layer_name}.running_mean",
                inputs=input_names,
                output=output_name,
            )
        )
        step += 1
        input_names = [output_name]

        output_name = f"{output_prefix}_{step}"
        circuit_steps.append(
            CircuitStep(
                layer=f"{layer_name}.running_var",
                inputs=input_names,
                output=output_name,
            )
        )
        step += 1
        input_names = [output_name]

    if add_weights:
        output_name = f"{output_prefix}_{step}"

        circuit_steps.append(
            CircuitStep(
                layer=f"{layer_name}.weight",
                inputs=input_names,
                output=output_name,
            )
        )
        step += 1
        input_names = [output_name]

    if add_bias:
        output_name = f"{output_prefix}_{step}"
        circuit_steps.append(
            CircuitStep(
                layer=f"{layer_name}.bias",
                inputs=input_names,
                output=output_name,
            )
        )
        step += 1
        input_names = [output_name]

    if add_generic:
        output_name = f"{output_prefix}_{step}"
        circuit_steps.append(
            CircuitStep(
                layer=f"{layer_name}",
                inputs=input_names,
                output=output_name,
            )
        )
        step += 1
        input_names = [output_name]

    return circuit_steps
