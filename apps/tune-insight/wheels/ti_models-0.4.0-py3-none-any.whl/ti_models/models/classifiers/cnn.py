from typing import Optional
from collections import OrderedDict
from torch import nn
from ti_models.models.classifiers.classifier import TIClassifier
from ti_models.models.classifiers.mlp import MLPClassifier
from ti_models.models.miscellaneous.traceability import TraceableSequential


class MnistCNN(TIClassifier):
    """
    Convolutional Neural Network designed for the MNIST dataset,
    inspired by LeNet-5 and adapted for FHE compatibility.

    Ref: Y. LeCun, L. Bottou, Y. Bengio and P. Haffner,
    Gradient-Based Learning Applied to Document Recognition, 1998

    Attributes:
        name (str): Name identifier for the model. Defaults to "MNIST_Classifier".
        description (Optional[str]): Description of the model's purpose and architecture. Defaults to None.
        dropout (float): Dropout probability. Defaults to 0.0.
        batch_norm (bool): Whether to use batch normalization. Defaults to False.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        traceable (bool): Whether to use traceable sequential layers. Defaults to False.
        export_path (str): Path to export the model. Defaults to "./".
        layers (OrderedDict()[str, TILayer]): OrderedDict() of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        head (MLPClassifier): Classification head of the model.
    """

    def __init__(
        self,
        name: str = "MNIST_Classifier",
        description: Optional[str] = None,
        dropout: float = 0.0,
        batch_norm: bool = False,
        preprocessing: Optional["Preprocessing"] = None,
        traceable: bool = False,
        export_path: str = "./",
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        secure_inference_enabled: bool = False,
    ):
        """
        Initialize the MnistCNN model.

        Args:
            name (str): Name identifier for the model. Defaults to "MNIST_Classifier".
            description (Optional[str]): Description of the model's purpose and architecture. Defaults to None.
            dropout (float): Dropout probability. Defaults to 0.0.
            batch_norm (bool): Whether to use batch normalization. Defaults to False.
            preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
            traceable (bool): Whether to use traceable sequential layers. Defaults to False.
            export_path (str): Path to export the model. Defaults to "./".
            layers (Optional[OrderedDict[str, TILayer]]): OrderedDict of layers indexed by their names in the model. Defaults to None.
            secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        """
        torch_layers = []

        torch_layers.append(
            (
                "conv_1",
                nn.Conv2d(
                    in_channels=1, out_channels=6, kernel_size=5, stride=1, padding=2
                ),
            )
        )  # 28*28 -> 32*32 -> 28*28

        if batch_norm:
            torch_layers.append(("batch_norm_1", nn.BatchNorm2d(6)))

        torch_layers.append(("tanh_1", nn.Tanh()))

        torch_layers.append(
            ("avg_pool_1", nn.AvgPool2d(kernel_size=2, stride=2))
        )  # 28*28 -> 14*14

        if dropout != 0:
            torch_layers.append(("dropout_1", nn.Dropout(dropout)))

        torch_layers.append(
            (
                "conv_2",
                nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1),
            )
        )  # 14*14 -> 10*10

        if batch_norm:
            torch_layers.append(("batch_norm_2", nn.BatchNorm2d(16)))

        torch_layers.append(("tanh_2", nn.Tanh()))

        torch_layers.append(
            ("avg_pool_2", nn.AvgPool2d(kernel_size=2, stride=2))
        )  # 10*10 -> 5*5

        # Classification head
        head = MLPClassifier(
            input_dim=16 * 5 * 5,
            n_classes=10,  # MNIST has 10 classes
            hidden_dims=(),
            dropout=dropout,
            batch_norm=batch_norm,
            activation=nn.Tanh,
            prob_output=False,
            standardize=False,
            name="MNIST_Classifier_Head",
            description="MLP head of MNIST CNN classifier",
        )
        torch_layers.append(("head", head.torch_model))

        # Initialize parent class with combined model
        model = TraceableSequential(
            layers=torch_layers,
            export_tensors=traceable,
            export_path=export_path,
        )

        super().__init__(
            name=name,
            n_classes=10,
            torch_model=model,
            description=description,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )
        self.head = head
