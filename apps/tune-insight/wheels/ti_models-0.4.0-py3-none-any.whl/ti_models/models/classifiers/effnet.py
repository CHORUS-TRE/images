from typing import Optional, Tuple, Union
from collections import OrderedDict
from torch import nn
from torchvision import models as tvmodels
from ti_models.models.classifiers.classifier import TIClassifier
from ti_models.models.classifiers.mlp import MLPClassifier


class EfficientNet(TIClassifier):
    """
    EfficientNet and EfficientNetV2 as introduced in:
    "EfficientNet: Rethinking Model Scaling for Convolutional Neural Networks",
        ref: https://arxiv.org/abs/1905.11946
    and
    "EfficientNetV2: Smaller Models and Faster Training",
        ref: https://arxiv.org/abs/2104.00298

    The encoding part of the model is obtained in various sizes (see effnet_cat
    attribute) from torchvizion library and its classification head is adapted
    to fit the task.

    Attributes:
        effnet_cat (int|str): The EfficientNet category of the model, e.g. 2 for EfficientNetB2.
            Available categories are: 0 to 7 for B-category of EfficientNet and "S", "M" and "L" for EfficientNetV2.
        n_classes (int): Number of classes for classification.
        name (str): Name identifier for the model. Defaults to "ResNet{resnet_cat}".
        description (Optional[str]): Description of the model's purpose and architecture. Defaults to None.
        hidden_dims (Tuple[int]): Hidden layer dimensions of the classification head. Defaults to ().
        dropout (float): Dropout probability. Defaults to 0.0.
        batch_norm (bool): Whether to use batch normalization in classification head. Defaults to False.
        preprocessing (Optional[Preprocessing]): Optional preprocessing transforms to apply to inputs. Defaults to None.
        layers (OrderedDict()[str, TILayer]): OrderedDict() of layers indexed by their names in the model. Defaults to None.
        secure_inference_enabled (bool): Whether secure inference (MaaS) is enabled for this model. Defaults to False.
        freeze_encoders (bool): Whether to freeze the encoding part applied before the final classification. Default to False.
    """

    def __init__(
        self,
        effnet_cat: Union[int, str],
        n_classes: int,
        name: str = None,
        description: Optional[str] = None,
        hidden_dims: Tuple[int] = (200,),
        dropout: float = 0.5,
        batch_norm: bool = False,
        pretrained: bool = True,
        preprocessing: Optional["Preprocessing"] = None,
        layers: Optional[OrderedDict[str, "TILayer"]] = None,
        secure_inference_enabled: bool = False,
        freeze_encoders: bool = False,
    ):
        name = name or f"EfficientNet_B{effnet_cat}"
        model = self._get_model(effnet_cat=effnet_cat, pretrained=pretrained)

        classifier_inputs = model.classifier[1].in_features

        if freeze_encoders:
            for param in model.parameters():
                param.requires_grad = False

        # Classification head
        head = MLPClassifier(
            input_dim=classifier_inputs,
            n_classes=n_classes,
            name="EffNet_Classifier_Head",
            description="MLP head of EffNet classifier",
            hidden_dims=hidden_dims,
            dropout=dropout,
            batch_norm=batch_norm,
            activation=nn.SiLU,
            prob_output=False,
            standardize=False,
        )
        model.classifier = head.torch_model

        super().__init__(
            name=name,
            n_classes=n_classes,
            torch_model=model,
            description=description,
            pretrained=pretrained,
            preprocessing=preprocessing,
            layers=layers or OrderedDict(),
            secure_inference_enabled=secure_inference_enabled,
        )
        self.head = head

    def _get_model(self, effnet_cat: Union[int, str], pretrained: bool):
        """Retrieve the appropriate EfficientNet model."""
        weight_map = {
            0: tvmodels.EfficientNet_B0_Weights,
            1: tvmodels.EfficientNet_B1_Weights,
            2: tvmodels.EfficientNet_B2_Weights,
            3: tvmodels.EfficientNet_B3_Weights,
            4: tvmodels.EfficientNet_B4_Weights,
            5: tvmodels.EfficientNet_B5_Weights,
            6: tvmodels.EfficientNet_B6_Weights,
            7: tvmodels.EfficientNet_B7_Weights,
            "s": tvmodels.EfficientNet_V2_S_Weights,
            "S": tvmodels.EfficientNet_V2_S_Weights,
            "m": tvmodels.EfficientNet_V2_M_Weights,
            "M": tvmodels.EfficientNet_V2_M_Weights,
            "l": tvmodels.EfficientNet_V2_L_Weights,
            "L": tvmodels.EfficientNet_V2_L_Weights,
        }

        model_map = {
            0: tvmodels.efficientnet_b0,
            1: tvmodels.efficientnet_b1,
            2: tvmodels.efficientnet_b2,
            3: tvmodels.efficientnet_b3,
            4: tvmodels.efficientnet_b4,
            5: tvmodels.efficientnet_b5,
            6: tvmodels.efficientnet_b6,
            7: tvmodels.efficientnet_b7,
            "s": tvmodels.efficientnet_v2_s,
            "S": tvmodels.efficientnet_v2_s,
            "m": tvmodels.efficientnet_v2_m,
            "M": tvmodels.efficientnet_v2_m,
            "l": tvmodels.efficientnet_v2_l,
            "L": tvmodels.efficientnet_v2_l,
        }

        if effnet_cat not in model_map:
            raise ValueError(
                f"Invalid EfficientNet category: {effnet_cat}. Supported categories are"
                "0 to 7 or 'S', 'M' and 'L' (v2)."
            )

        weights = weight_map.get(effnet_cat).DEFAULT if pretrained else None
        return model_map[effnet_cat](weights=weights)
