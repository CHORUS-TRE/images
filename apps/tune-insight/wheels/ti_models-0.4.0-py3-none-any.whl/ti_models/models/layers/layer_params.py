from typing import List, Dict
import torch
from torch import nn, Tensor
from ti_models.models.layers.activations.polynomial import Polynomial
from ti_models.models.utils import format_size


class InputStats:
    """InputStats regroups statistics about the values of a set of tensors."""

    def __init__(self):
        self.max_max = None
        self.min_min = None

        self.reset()

    def reset(self):
        """Reset the statistics"""
        self.sum = Tensor([0])
        self.squared_sum = Tensor([0])

        self.max_sum = Tensor([0])
        self.max_squared_sum = Tensor([0])
        self.max_max = None

        self.min_sum = Tensor([0])
        self.min_squared_sum = Tensor([0])
        self.min_min = None

        self.n = 0
        self.n_channels = 0

    def accumulate_batch(self, x: Tensor):
        """Update the statistics by accumulating a new tensor batch. It saves global statistics as well as statistics aggregated by sample.

        Args:
            x (Tensor): The batch to update the stats from.
        """
        self.sum += x.sum()
        self.squared_sum += x.square().sum()

        mins = x.amin(dim=tuple(range(x.dim())[1:]))
        maxs = x.amax(dim=tuple(range(x.dim())[1:]))

        self.min_sum += mins.sum()
        self.min_squared_sum += mins.square().sum()
        min_ = mins.min()
        self.min_min = min_ if self.min_min is None else min(min_, self.min_min)

        self.max_sum += maxs.sum()
        self.max_squared_sum += maxs.square().sum()
        max_ = maxs.max()
        self.max_max = max_ if self.max_max is None else max(max_, self.max_max)

        self.n += x.numel()
        self.n_channels += len(maxs)

    def get_stats_dict(self) -> Dict[str, float]:
        """Returns the statistics as a dict

        Raises:
            ValueError: If no batch if inputs was yet accumulated for the statistics.

        Returns:
            Dict[str, float]: A dict of various statistics.
        """
        if self.is_empty():
            raise ValueError("No value accumulated")

        min_min, max_max = self.get_bounds()
        mean, min_mean, max_mean = self.get_mean()
        stddev, min_stddev, max_stddev = self.get_stddev()
        range_ = max_max - min_min

        stats = {
            "global_mean": mean,
            "global_stddev": stddev,
            "min_min": min_min,
            "min_mean": min_mean,
            "min_stddev": min_stddev,
            "max_max": max_max,
            "max_mean": max_mean,
            "range": range_,
            "max_stddev": max_stddev,
            "n_channels": self.n_channels,
            "n": self.n,
        }

        return stats

    def get_safe_bounds(self, margin_ratio):
        if self.is_empty():
            raise ValueError("No value accumulated")

        min_min, max_max = self.get_bounds()

        amplitude = max_max - min_min
        A = min_min - abs(amplitude) * margin_ratio / 2
        B = max_max + abs(amplitude) * margin_ratio / 2

        # A = min_min - abs(min_min) * margin_ratio
        # B = max_max + abs(max_max) * margin_ratio

        return A, B

    def get_bounds(self):
        """Returns the bounds of values that have been accumulated.

        Raises:
            ValueError: If no value was accumulated yet.

        Returns:
            Tuple[float]: A tuple containing the min and max values.
        """
        if self.is_empty():
            raise ValueError("No value accumulated")

        return self.min_min.item(), self.max_max.item()

    def get_range(self):
        """Return the range of values that have been accumulated.

        Raises:
            ValueError: If no value was accumulated yet.

        Returns:
            float: The range of values accumulated
        """
        if self.is_empty():
            raise ValueError("No value accumulated")

        return self.max_max.item() - self.min_min.item()

    def get_mean(self):
        """Return 3 different means of values accumulated: the global mean, the mean of
            minimum values per sample and the mean of maximum value per sample.

        Raises:
            ValueError: If no value was accumulated yet.

        Returns:
            Tuple[float]: The means of values accumulated
        """
        if self.is_empty():
            raise ValueError("No value accumulated")

        mean = self.sum / self.n

        min_mean = self.min_sum / self.n_channels
        max_mean = self.max_sum / self.n_channels

        return mean.item(), min_mean.item(), max_mean.item()

    def get_stddev(self):
        """Return 3 different standard deviation values (stddev) from values accumulated: the global stddev,
        the stddev of minimum values per sample and the stddev of maximum value per sample.

        Raises:
            ValueError: If no value was accumulated yet.

        Returns:
            Tuple[float]: The stddev of values accumulated
        """
        if self.is_empty():
            raise ValueError("No value accumulated")

        stddev = torch.sqrt((self.squared_sum - self.sum.square() / self.n) / self.n)

        min_stddev = torch.sqrt(
            (self.min_squared_sum - self.min_sum.square() / self.n_channels)
            / self.n_channels
        )
        max_stddev = torch.sqrt(
            (self.max_squared_sum - self.max_sum.square() / self.n_channels)
            / self.n_channels
        )

        return stddev.item(), min_stddev.item(), max_stddev.item()

    def is_empty(self) -> bool:
        """Return True if some tensors have been accumulated to the statistics.

        Returns:
            bool: True if some value has been accumulated to the statistics.
        """
        return self.max_max is None


class PrivacyParams:
    """
    Class containing privacy-related parameters for a layer.

    Attributes:
        clipping_factor (float): The gradient clipping multiplicative factor used for training.
            It is set to the norm() of the weights of the layer in pretrained models.
    """

    def __init__(self, clipping_factor: float = 0.0):
        self.clipping_factor = clipping_factor
        self.input_stats = InputStats()

    def __str__(self) -> str:
        """
        Returns:
            str: A string representation of the PrivacyParams including
                the clipping factor.
        """
        return f"PrivacyParams(clipping_factor={self.clipping_factor}, input_stats.n={self.input_stats.n})"

    def __eq__(self, other: object) -> bool:
        """
        Check if this PrivacyParams is equal to another PrivacyParams.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the objects are equal, False otherwise.
        """
        if not isinstance(other, PrivacyParams):
            return False

        return (
            self.clipping_factor == other.clipping_factor
            and self.input_stats == other.input_stats
        )

    def __hash__(self):
        return hash((self.clipping_factor, self.input_stats))


def get_layer_meta_params(layer_name: str, module: "nn.Module") -> List[float]:
    """
    Get the meta-parameters of a specific layer in a PyTorch module, according to the TI convention.
    For nested modules, recursively traverses the module hierarchy to find the target layer.

    TI Conventions for TILayers meta-parameters per TILayer type:
    - CONV_WEIGHT, CONV_BIAS, MAX_POOL, AVG_POOL:
        meta_parameters: [kernel_size[0], ..., kernel_size[d], stride[0], ..., stride[d], padding[0], ..., padding[d]]
            Where d is the dimension of the layer input.
    - BATCH_NORM_RUNNING_VAR:
        meta_parameters: [epsilon]
    - DROPOUT:
        meta_parameters: [prob]
    - POLY_RELU, POLY_SILU, POLY_SIGMOID, POLY_TANH, POLY_GENERIC:
        meta_parameters: [min, max, a0, a1, a2, ...]
            Where min and max are the interval bounds of the polynormal approximation, and a0, a1, ..., a_n are the polynomial coefficients.

    Args:
        layer_name (str): Name of the layer in the module hierarchy (dot-separated)
        module (nn.Module): PyTorch module containing the layer

    Returns:
        List[float]: List of meta-parameter values specific to the layer type
    """
    parsed_name = layer_name.split(".")

    meta_params = []

    if isinstance(
        module,
        (
            nn.Conv1d,
            nn.Conv2d,
            nn.Conv3d,
            nn.MaxPool1d,
            nn.MaxPool2d,
            nn.MaxPool3d,
            nn.AvgPool1d,
            nn.AvgPool2d,
            nn.AvgPool3d,
        ),
    ):
        dim = 1
        if isinstance(module, (nn.Conv2d, nn.MaxPool2d, nn.AvgPool2d)):
            dim = 2
        if isinstance(module, (nn.Conv3d, nn.MaxPool3d, nn.AvgPool3d)):
            dim = 3

        kernel_size = module.kernel_size
        meta_params.extend(format_size(kernel_size, dim))

        stride = module.stride
        meta_params.extend(format_size(stride, dim))

        padding = module.padding
        meta_params.extend(format_size(padding, dim))

    elif isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
        if parsed_name[0] == "running_var":
            meta_params.append(module.eps)

    elif isinstance(module, Polynomial):
        meta_params.extend(module.get_interval())
        meta_params.extend(module.get_coeffs())

    elif isinstance(module, nn.Dropout):
        meta_params.append(module.p)

    # Browse children recursively
    elif len(parsed_name) > 1:
        child_name = parsed_name[0]
        if hasattr(module, parsed_name[0]):
            return get_layer_meta_params(
                ".".join(parsed_name[1:]), getattr(module, parsed_name[0])
            )
        if hasattr(module, "__getitem__"):
            return get_layer_meta_params(
                ".".join(parsed_name[1:]), module.get(child_name, module)
            )

    return meta_params
