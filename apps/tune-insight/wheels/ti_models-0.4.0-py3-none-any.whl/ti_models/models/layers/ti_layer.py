from io import BytesIO
from typing import List
from collections import OrderedDict

from ti_models.models.layers.layer_types import (
    LayerType,
    get_layer_type,
    is_trainable_type,
    AGGREGATABLE_LAYER_TYPES,
)
from ti_models.models.layers.layer_params import PrivacyParams, get_layer_meta_params
from ti_models.models.layers.utils import model_layer_requires_grad
from ti_models.utils.utils import BYTE_ORDER, marshal_float, unmarshal_float


class TILayer:
    """
    Class representing a layer in a TI model.

    Attributes:
        layer_type (LayerType): The type of layer
        shape (List[int]): The shape of the layer's parameters (weights)
        data (List[float]): The layer's parameters values (weights)
        meta_params (List[float]): Additional parameters specific to the layer type
        privacy_params (PrivacyParams): Privacy-related parameters for the layer
        trainable (bool): Whether the layer's parameters (weights) can be updated during training
    """

    def __init__(
        self,
        layer_type: LayerType,
        shape: List[int],
        data: List[float],
        meta_params: List[float],
        privacy_params: PrivacyParams = None,
        trainable: bool = False,
    ):
        """
        Initialize a TILayer.
        """
        self.layer_type = layer_type
        self.shape = shape
        self.data = data
        self.meta_params = meta_params
        self.privacy_params = privacy_params or PrivacyParams()
        self.trainable = trainable

    def __str__(self) -> str:
        """
        Returns:
            str: A string representation of the TILayer including its type, shape,
                data length, meta-parameters, privacy parameters and trainable status.
        """
        return (
            f"TILayer(type={self.layer_type.value}({self.layer_type.name}),"
            f"shape={self.shape},"
            f"len(data)={len(self.data)},"
            f"meta_params={self.meta_params},"
            f"privacy_params={self.privacy_params},"
            f"trainable={self.trainable})"
        )

    def __eq__(self, other: object) -> bool:
        """
        Check if this TILayer is equal to another TILayer.

        Args:
            other (object): The object to compare with.

        Returns:
            bool: True if the layers are equal, False otherwise.
        """
        if not isinstance(other, TILayer):
            return False

        return (
            self.layer_type == other.layer_type
            and self.shape == other.shape
            and self.data == other.data
            and self.meta_params == other.meta_params
            and self.trainable == other.trainable
        )

    def __hash__(self):
        return hash(
            (
                self.layer_type,
                tuple(self.shape),
                tuple(self.data),
                tuple(self.meta_params),
                self.trainable,
            )
        )

    @classmethod
    def from_torch_module(
        cls, name: str, module: "nn.Module", pretrained: bool
    ) -> OrderedDict[str, "TILayer"]:
        """
        Create a list of TILayers from a state dict item.

        Args:
            name (str): Name of the layer
            module (nn.Module): The torch module this layer belongs to

        Returns:
            OrderedDict[str, "TILayer"]: An OrderedDict of new TILayer
                instances identified by their names
        """

        ti_layers = OrderedDict()

        # Possible names of torch layer sublayers if it is a layer that
        # contains data (weights), such as Conv, BatchNorm, Linear, ...
        layer_data_names = [
            "weight",
            "bias",
            "running_mean",
            "running_var",
            "num_batches_tracked",
        ]

        for layer_data_name in layer_data_names:
            layer_data_full_name = f"{name}.{layer_data_name}"

            layer_data = module.state_dict().get(layer_data_name, None)
            if layer_data is None:
                continue

            layer_type = get_layer_type(layer_data_name, module)
            meta_params = get_layer_meta_params(layer_data_name, module)
            trainable = is_trainable_type(layer_type) and model_layer_requires_grad(
                layer_data_name, module
            )
            shape = list(layer_data.shape)
            data = layer_data.flatten().tolist()

            c_factor = 1.0
            if pretrained and layer_type in AGGREGATABLE_LAYER_TYPES:
                c_factor = layer_data.norm().item()

            privacy_params = PrivacyParams(c_factor)

            ti_layer = cls(
                layer_type=layer_type,
                shape=shape,
                data=data,
                meta_params=meta_params,
                privacy_params=privacy_params,
                trainable=trainable,
            )
            ti_layers[layer_data_full_name] = ti_layer

        # If the layer does not contain data (weights)
        if len(ti_layers) == 0:
            layer_type = get_layer_type(name, module)
            meta_params = get_layer_meta_params(name, module)
            trainable = is_trainable_type(layer_type) and model_layer_requires_grad(
                layer_data_name, module
            )

            ti_layer = cls(
                layer_type=layer_type,
                shape=[],
                data=[],
                meta_params=meta_params,
                privacy_params=None,
                trainable=trainable,
            )
            ti_layers[name] = ti_layer

        return ti_layers

    def is_fl_layer(self) -> bool:
        """
        Determine if the layer is used for FL aggregations.
        A layer is needed in FL if it is trainable
            or if its type is DATA_STATS

        Returns:
            bool: True if the layer is used for FL aggregations, False otherwise.
        """
        return self.trainable or self.layer_type is LayerType.DATA_STATS

    def marshal_binary(self, byteorder: str = BYTE_ORDER) -> bytes:
        """
        Serialize the TILayer to a binary format.

        Args:
            byteorder (str): The byte order to use for marshaling. Defaults to BYTE_ORDER.

        Returns:
            bytes: The serialized TILayer.
        """
        buffer = BytesIO()

        # append layer type
        buffer.write(int(self.layer_type).to_bytes(1, byteorder, signed=False))

        # append size of shape
        shape_size: int = len(self.shape)
        buffer.write(shape_size.to_bytes(8, byteorder, signed=False))

        # append shape
        for dim in self.shape:
            buffer.write(int(dim).to_bytes(4, byteorder, signed=False))

        # append size of content data
        data_size: int = len(self.data)
        buffer.write(data_size.to_bytes(8, byteorder, signed=False))

        # append content data
        for value in self.data:
            marshal_float(buffer, float(value), byteorder=byteorder)

        # append size of params
        params_size: int = len(self.meta_params)
        buffer.write(params_size.to_bytes(8, byteorder, signed=False))

        # append params data
        for value in self.meta_params:
            marshal_float(buffer, float(value), byteorder=byteorder)

        # append c_factor
        c_factor = self.privacy_params.clipping_factor
        marshal_float(buffer, c_factor, byteorder=byteorder)

        return buffer.getvalue()

    @classmethod
    def unmarshal_binary(
        cls, binary_layer: bytes, byteorder: str = BYTE_ORDER
    ) -> "TILayer":
        """
        Deserialize binary data to a TILayer object.

        Args:
            binary_layer (bytes): The binary data to unmarshal.
            byteorder (str): The byte order used for serialization. Defaults to BYTE_ORDER.

        Returns:
            TILayer: The unmarshaled TILayer object.
        """
        f = BytesIO(binary_layer)

        layer_type = LayerType(int.from_bytes(f.read(1), byteorder, signed=False))

        shape = []
        data = []
        meta_params = []

        shape_size = int.from_bytes(f.read(8), byteorder, signed=False)

        for _ in range(shape_size):
            shape.append(int.from_bytes(f.read(4), byteorder, signed=False))

        data_size = int.from_bytes(f.read(8), byteorder, signed=False)

        for _ in range(data_size):
            data.append(unmarshal_float(f, byteorder=byteorder))

        meta_params_size = int.from_bytes(f.read(8), byteorder, signed=False)

        for _ in range(meta_params_size):
            meta_params.append(unmarshal_float(f, byteorder=byteorder))

        c_factor = unmarshal_float(f, byteorder=byteorder)
        privacy_params = None
        if c_factor != 0.0:
            privacy_params = PrivacyParams(clipping_factor=c_factor)

        ti_layer = cls(
            layer_type=layer_type,
            shape=shape,
            data=data,
            meta_params=meta_params,
            privacy_params=privacy_params,
        )

        return ti_layer
