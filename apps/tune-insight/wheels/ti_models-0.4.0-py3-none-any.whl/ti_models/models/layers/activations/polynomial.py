from typing import Tuple, List
from enum import IntEnum
import torch
from torch import Tensor, nn
from torch.nn import functional as F

SUPPORTED_ACTIVATIONS = {
    nn.SiLU: F.silu,
    nn.ReLU: F.relu,
    nn.Sigmoid: torch.sigmoid,
    nn.Tanh: torch.tanh,
}


class PolyBasis(IntEnum):
    CHEBYSHEV = 1
    MONOMIAL = 2


class Polynomial(nn.Module):
    def __init__(
        self,
        basis: PolyBasis,
        A: float,
        B: float,
        coeffs: List[float],
        func,
        debug: bool = True,
    ):
        super().__init__()

        self.basis = basis
        self.A = Tensor([A])
        self.B = Tensor([B])
        self.coeffs = coeffs
        if self.basis == PolyBasis.CHEBYSHEV:
            # Chebyshev's coeffs[0] is doubled internally for fast evaluation
            self.coeffs[0] *= 2
        self.func = func
        self.eval_fast = (
            self.eval_fast_chebyshev
            if self.basis == PolyBasis.CHEBYSHEV
            else self.eval_fast_monomial
        )
        self.set_debug(debug=debug)

    def set_debug(self, debug: bool):
        self.debug = debug
        self.eval = self.eval_debug if debug else self.eval_fast

    def extra_repr(self):
        s = f"func={self.func.__name__}, A={self.A.item()}, B={self.B.item()}, degree={self.get_degree()}"

        return s

    def forward(self, x: Tensor) -> Tensor:
        return self.eval(x)

    def get_degree(self) -> int:
        return len(self.coeffs) - 1

    def get_interval(self) -> Tuple[int, int]:
        return self.A, self.B

    def get_coeffs(self) -> List[float]:
        if self.basis == PolyBasis.CHEBYSHEV:
            c_list = self.coeffs
            # Chebyshev's coeffs[0] is doubled internally for fast evaluation
            coeffs = [c_list[0] / 2] + c_list[1:]
        else:
            coeffs = self.coeffs

        return coeffs

    def eval_fast_monomial(self, x: Tensor):
        output = torch.zeros_like(x)

        for coeff in reversed(self.coeffs):
            output = output * x + coeff

        return output

    def eval_fast_chebyshev(self, x: Tensor):
        y = (2.0 * x - self.A - self.B) * (1.0 / (self.B - self.A))
        y2 = 2.0 * y
        (d, dd) = (self.coeffs[-1], 0)  # Special case first step for efficiency
        for cj in self.coeffs[-2:0:-1]:  # Clenshaw's recurrence
            (d, dd) = (y2 * d - dd + cj, d)

        output = y * d - dd + 0.5 * self.coeffs[0]  # Last step is different

        return output

    def eval_debug(self, x: Tensor):
        if not isinstance(x, Tensor):
            x = Tensor([x])

        valid_input = torch.all(self.A <= x) and torch.all(x <= self.B)
        if not valid_input:
            raise ValueError(
                f"A value was outside the approximated polynomial activation bounds [{self.A.item()}; {self.B.item()}]. Value min: {x.min()}, value max: {x.max()}"
            )

        return self.eval_fast(x)

    def get_func(self):
        return self.func
