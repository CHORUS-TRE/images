from typing import List, Tuple
import os
import json
import torch
from torch import nn
from ti_models.models.layers.activations.polynomial import (
    Polynomial,
    PolyBasis,
)
from ti_models.models.layers.activations.composite_poly_sign_coeffs import (
    SIGN_COEFFS_MONO_FILENAME,
    SIGN_COEFFS_CHEBY,
)


class CompositePoly(nn.Module):
    def __init__(self, activations: List[Polynomial], debug: bool = True):
        super().__init__()

        self.activations = nn.Sequential(*activations)
        self.A = activations[0].A
        self.B = activations[0].B

        self.names = list(
            map(lambda act: act.get_func().__name__, reversed(self.activations))
        )
        self.degrees = list(map(lambda act: str(act.get_degree()), self.activations))

        self.set_debug(debug=debug)

    @classmethod
    def sign_composite_monomial(cls, alpha: int, debug: bool = True) -> "CompositePoly":
        """
        Create a CompositePoly based on the given alpha value (precision),
        as defined in
        `Precise Approximation of Convolutional NeuralNetworks for Homomorphically Encrypted Data`
        source: https://ieeexplore.ieee.org/document/10155408

        The optimal coefficients are coming from the paper and stored in a json.

        Args:
            alpha (int): The precision used to select the polynomial coefficients
                from the JSON file, between alpha=7 and alpha=14 which represents a good practical
                precision range in practice.
            debug (bool, optional): If True, enables debug mode for the CompositeActivation
                        instance. Defaults to True.
        Returns:
            CompositePoly: An instance of CompositePoly initialized with
                     the specified polynomial activations.
        """

        if alpha not in [7, 8, 9, 10, 11, 12, 13, 14]:
            raise ValueError("alpha must be one between 7 and 14")

        current_dir = os.path.dirname(__file__)
        coeffs_path = os.path.join(current_dir, SIGN_COEFFS_MONO_FILENAME)

        with open(coeffs_path, "r", encoding="utf-8") as f:
            coeffs = json.load(f)

        activations: List[Polynomial] = []
        a = -1
        b = 1
        for coeff in coeffs[str(alpha)]:
            poly_activation = Polynomial(
                basis=PolyBasis.MONOMIAL, A=a, B=b, coeffs=coeff, func=torch.sign
            )
            activations.append(poly_activation)

            # Set the bounds to 2 the activations applied after the 1st one
            # to avoid errors.
            a = -2
            b = 2

        return cls(activations, debug)

    @classmethod
    def sign_composite_chebyshev(
        cls, prec_level: int, debug: bool = True
    ) -> "CompositePoly":
        """
        Create a CompositeActivation instance based on generated coefficients from Lattigo for various
        arbitrarily chosen precision levels. The coefficients were generated with
        `GenMinimaxCompositePolynomialForSign` with the following parameters:
            precision level 1:
                bit-precision = 256
                logalpha = 1
                logErr = 100000
                degree: [13]
            precision level 2:
                bit-precision = 256
                logalpha = 3
                logErr = 100000
                degree: [7, 7]
            precision level 3:
                bit-precision = 256
                logalpha = 5
                logErr = 100000
                degree: [15, 15]
            precision level 4:
                bit-precision = 256
                logalpha = 6
                logErr = 100000
                degree: [7, 7, 13]
            precision level 5:
                bit-precision = 256
                logalpha = 10
                logErr = 100000
                degree: [15, 27, 29]

        source: https://github.com/tuneinsight/lattigo/blob/e9e04b14451a8dc1fdd2f5f414f311a9707866b3/circuits/ckks/minimax/minimax_composite_polynomial.go

        Args:
            prec_level (int): bit-precision level, from 1 to 5.
            debug (bool, optional): If True, enables debug mode for the CompositeActivation
                        instance. Defaults to True.
        Returns:
            CompositeActivation: An instance of CompositeActivation initialized with
                     the specified polynomial activations.
        """

        if prec_level not in [1, 2, 3, 4, 5]:
            raise ValueError("prec_level must be one between 1 and 5")

        activations: List[Polynomial] = []
        a = -1
        b = 1
        for coeff in SIGN_COEFFS_CHEBY[prec_level]:
            poly_activation = Polynomial(
                basis=PolyBasis.CHEBYSHEV, A=a, B=b, coeffs=coeff, func=torch.sign
            )
            activations.append(poly_activation)

        return cls(activations, debug)

    def forward(self, x):
        return self.activations(x)

    def set_debug(self, debug: bool):
        self.debug = debug
        for act in self.activations:
            act.set_debug(debug)

    def extra_repr(self) -> str:
        func_descr = "◦".join(self.names)
        degrees_str = ",".join(self.degrees)
        s = f"func={func_descr}, A={self.A.item()}, B={self.B.item()}, degrees={degrees_str}"

        return s

    def get_interval(self) -> Tuple[int, int]:
        return self.A, self.B
