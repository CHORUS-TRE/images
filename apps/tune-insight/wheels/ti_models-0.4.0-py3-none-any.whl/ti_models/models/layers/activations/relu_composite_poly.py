from typing import Tuple, Optional
from torch import nn, Tensor
from ti_models.models.layers.activations.composite_poly import CompositePoly
from ti_models.models.layers.activations.polynomial import PolyBasis


class ReluCompositePoly(nn.Module):
    """
    A composite polynomial approximation of the ReLU activation function.

    Args:
        basis (PolyBasis): The polynomial basis to use (either MONOMIAL or CHEBYSHEV).
        A (float): The lower bound of the interval for the approximation.
        B (float): The upper bound of the interval for the approximation.
        alpha (Optional[int]): The alpha-precision used to select the predefined polynomial
            coefficients, between alpha=7 and alpha=14 which represents a good practical
            precision range in practice. Must be provided if basis is MONOMIAL.
        prec_level (Optional[int]): The precision level for the Chebyshev basis, between
            1 and 5. Must be provided if basis is CHEBYSHEV.
        debug (bool): If True, enables debug mode for the composite polynomial.

    Attributes:
        sign_composite (CompositePoly): The composite polynomial used for the sign function.
        A (float): The lower bound of the interval for the approximation.
        B (float): The upper bound of the interval for the approximation.
        scale (float): The scaling factor, which is the maximum of A and B.

    Raises:
        ValueError: If `alpha` is not provided for the monomial basis.
        ValueError: If `prec_level` is not provided for the Chebyshev basis.

    """

    def __init__(
        self,
        basis: PolyBasis,
        A: float,
        B: float,
        alpha: Optional[int] = None,
        prec_level: Optional[int] = None,
        debug: bool = True,
    ):
        super().__init__()

        self.sign_composite = None
        if basis == PolyBasis.MONOMIAL:
            if alpha is None:
                raise ValueError("alpha must be provided for monomial basis")
            self.sign_composite = CompositePoly.sign_composite_monomial(
                alpha=alpha, debug=debug
            )
        else:
            if prec_level is None:
                raise ValueError("prec_level must be provided for chebyshev basis")
            self.sign_composite = CompositePoly.sign_composite_chebyshev(
                prec_level=prec_level,
                debug=debug,
            )

        self.A = A
        self.B = B
        self.scale = max(self.A, self.B)
        self.degrees = list(
            map(lambda act: str(act.get_degree()), self.sign_composite.activations)
        )

    def set_debug(self, debug: bool):
        self.sign_composite.set_debug(debug=debug)

    def extra_repr(self):
        degrees = ",".join(self.degrees)
        s = f"func=ReLU, A={self.A}, B={self.B}, scale={self.scale}, degrees={degrees}"

        return s

    def get_interval(self) -> Tuple[int, int]:
        return self.sign_composite.A, self.sign_composite.B

    def forward(self, x: Tensor) -> Tensor:
        x = x / self.scale
        sign = self.sign_composite(x)
        relu_unscaled = (x + x * sign) / 2
        relu = self.scale * relu_unscaled

        return relu
