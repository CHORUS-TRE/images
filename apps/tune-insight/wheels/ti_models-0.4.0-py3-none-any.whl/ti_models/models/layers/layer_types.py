from enum import IntEnum
from torch import nn
from ti_models.models.layers.activations.chebyshev_poly import ChebyshevPoly
from ti_models.models.layers.activations.polynomial import Polynomial
from ti_models.models.layers.activations.polynomial import SUPPORTED_ACTIVATIONS

from ti_models.models.layers.utils import get_child_from_name


class LayerType(IntEnum):
    OTHER = 0
    LINEAR_WEIGHTS = 1
    LINEAR_BIAS = 2
    CONV_WEIGHT = 3  # (meta_params: [kernel_size[0], kernel_size[1], ..., stride[0], stride[1], ..., padding[0], padding[1], ...])
    CONV_BIAS = 4  # (meta_params: [kernel_size[0], kernel_size[1], ..., stride[0], stride[1], ..., padding[0], padding[1], ...])
    BATCH_NORM_WEIGHTS = 5
    BATCH_NORM_BIAS = 6
    BATCH_NORM_RUNNING_MEAN = 7
    BATCH_NORM_RUNNING_VAR = 8  # (meta_params: [epsilon])
    BATCH_NORM_NUM_BATCHES_TRACKED = 9
    GENERIC_AGG_LAYER = 10  # generic aggregatable layer
    MAX_POOL = 11  # (meta_params: [kernel_size[0], kernel_size[1], ..., stride[0], stride[1], ..., padding[0], padding[1], ...])
    AVG_POOL = 12  # (meta_params: [kernel_size[0], kernel_size[1], ..., stride[0], stride[1], ..., padding[0], padding[1], ...])
    FLATTEN = 20
    ADD = 21
    MUL = 22
    DIV = 23
    CONCATENATE = 24
    DROPOUT = 25  # (meta_params: [prob])
    RELU = 30
    SILU = 31
    SIGMOID = 32
    TANH = 33
    POLY_RELU = 35
    POLY_SILU = 36
    POLY_SIGMOID = 37
    POLY_TANH = 38
    POLY_GENERIC = 39
    DATA_STATS = 40


AGGREGATABLE_LAYER_TYPES = [
    LayerType.LINEAR_WEIGHTS,
    LayerType.LINEAR_BIAS,
    LayerType.CONV_WEIGHT,
    LayerType.CONV_BIAS,
    LayerType.BATCH_NORM_WEIGHTS,
    LayerType.BATCH_NORM_BIAS,
    LayerType.GENERIC_AGG_LAYER,
]

LAYER_TYPE_MAP = {
    "flatten": LayerType.FLATTEN,
    "dropout": LayerType.DROPOUT,
    "relu": LayerType.RELU,
    "silu": LayerType.SILU,
    "sigmoid": LayerType.SIGMOID,
    "tanh": LayerType.TANH,
}

LINEAR_LAYER_TYPE_MAP = {
    "weight": LayerType.LINEAR_WEIGHTS,
    "bias": LayerType.LINEAR_BIAS,
}

CONV_LAYER_TYPE_MAP = {
    "weight": LayerType.CONV_WEIGHT,
    "bias": LayerType.CONV_BIAS,
}

BN_LAYER_TYPE_MAP = {
    "weight": LayerType.BATCH_NORM_WEIGHTS,
    "bias": LayerType.BATCH_NORM_BIAS,
    "running_mean": LayerType.BATCH_NORM_RUNNING_MEAN,
    "running_var": LayerType.BATCH_NORM_RUNNING_VAR,
    "num_batches_tracked": LayerType.BATCH_NORM_NUM_BATCHES_TRACKED,
}


def get_layer_type(layer_name: str, module: "nn.Module") -> LayerType:
    """
    Get the layer type for a given layer name in a torch module.

    Args:
        layer_name (str): Name of the layer
        module (nn.Module): PyTorch module being or containing the layer.

    Returns:
        LayerType: The determined layer type enum value
    """

    # Recursively get the leaf module from the given name
    layer_obj = get_child_from_name(module, layer_name)
    layer_key = layer_name.split(".")[-1]

    layer_type = None

    match layer_obj:
        case nn.Linear():
            layer_type = LINEAR_LAYER_TYPE_MAP.get(layer_key)
        case nn.Conv1d() | nn.Conv2d() | nn.Conv3d():
            layer_type = CONV_LAYER_TYPE_MAP.get(layer_key)
        case nn.BatchNorm1d() | nn.BatchNorm2d() | nn.BatchNorm3d():
            layer_type = BN_LAYER_TYPE_MAP.get(layer_key)
        case nn.MaxPool1d() | nn.MaxPool2d() | nn.MaxPool3d():
            layer_type = LayerType.MAX_POOL
        case nn.AvgPool1d() | nn.AvgPool2d() | nn.AvgPool3d():
            layer_type = LayerType.AVG_POOL
        case nn.Flatten():
            layer_type = LayerType.FLATTEN
        case nn.Dropout():
            layer_type = LayerType.DROPOUT
        case ChebyshevPoly():
            layer_type = get_poly_layer_type(layer_obj.get_func())
        case Polynomial():
            layer_type = LayerType.POLY_GENERIC
        case nn.ReLU():
            layer_type = LayerType.RELU
        case nn.SiLU():
            layer_type = LayerType.SILU
        case nn.Sigmoid():
            layer_type = LayerType.SIGMOID
        case nn.Tanh():
            layer_type = LayerType.TANH
        case nn.Identity():
            layer_type = LayerType.OTHER

    if layer_type is not None:
        return layer_type

    # Get layer type from its name
    return get_layer_type_from_name(layer_name)


def get_layer_type_from_name(layer_name: str) -> LayerType:
    """
    Get the layer type from a given layer name following PyTorch naming conventions

    Args:
        layer_name (str): Name of the layer

    Returns:
        LayerType: The determined layer type enum value
    """

    # Keep at most to elements from the name
    parsed_name = layer_name.split(".")

    if len(parsed_name) > 2:
        parsed_name = parsed_name[-2:]

    # return the type if the layer is recognized from the layer_type_map
    for key, layer_type in LAYER_TYPE_MAP.items():
        if parsed_name[-1].startswith(key):
            return layer_type

    # otherwise try to recognize the type from pytorch or TI naming conventions
    if parsed_name[0].startswith("conv"):
        if parsed_name[1] in CONV_LAYER_TYPE_MAP:
            layer_type = CONV_LAYER_TYPE_MAP[parsed_name[1]]
    elif parsed_name[0].startswith("bn"):
        if parsed_name[1] in BN_LAYER_TYPE_MAP:
            layer_type = BN_LAYER_TYPE_MAP[parsed_name[1]]
    elif parsed_name[-1] in ["weight", "bias"] or parsed_name[-1].startswith("agg"):
        layer_type = LayerType.GENERIC_AGG_LAYER
    elif parsed_name[0].startswith("data_stats") and parsed_name[1] == "dataset_size":
        layer_type = LayerType.DATA_STATS
    else:
        layer_type = LayerType.OTHER

    return layer_type


def get_poly_layer_type(func):
    if func in SUPPORTED_ACTIVATIONS.values():
        exact_activation_class = list(SUPPORTED_ACTIVATIONS.keys())[
            list(SUPPORTED_ACTIVATIONS.values()).index(func)
        ]
        if exact_activation_class == nn.ReLU:
            return LayerType.POLY_RELU
        if exact_activation_class == nn.SiLU:
            return LayerType.POLY_SILU
        if exact_activation_class == nn.Sigmoid:
            return LayerType.POLY_SIGMOID
        if exact_activation_class == nn.Tanh:
            return LayerType.POLY_TANH

    return LayerType.POLY_GENERIC


def is_trainable_type(layer_type: LayerType) -> bool:
    return layer_type <= LayerType.GENERIC_AGG_LAYER
