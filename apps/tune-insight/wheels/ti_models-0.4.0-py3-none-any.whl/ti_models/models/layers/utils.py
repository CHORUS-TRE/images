def get_child_from_name(model: "nn.Module", name: str) -> "nn.Module":
    parsed_name = name.split(".")

    child = model
    for child_name in parsed_name:
        if list(child.children()):
            if child_name.isdigit():
                child = child[int(child_name)]
            else:
                child = getattr(child, child_name)
        else:
            return child

    return child


def model_layer_requires_grad(layer_name: str, module: "nn.Module") -> bool:
    """Returns true if a layer named `layer_name` exists and it requires gradient update (trainable).

    Returns:
        bool: Whether the layer exists and requires grad (trainable).
    """
    param_dict = dict(module.named_parameters())
    has_grad = layer_name in param_dict and param_dict[layer_name].requires_grad

    return has_grad
